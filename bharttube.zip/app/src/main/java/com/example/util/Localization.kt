package com.example.util

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    HINDI("hi", "Hindi", "हिन्दी"),
    HINGLISH("hinglish", "Hinglish", "हिंग्लिश (Hindi+English)");

    companion object {
        fun fromCode(code: String): AppLanguage {
            return entries.find { it.code.equals(code, ignoreCase = true) } ?: ENGLISH
        }
    }
}

data class AppStrings(
    // Bottom Nav
    val navHome: String,
    val navShorts: String,
    val navCreate: String,
    val navSubscriptions: String,
    val navYou: String,

    // Top Bar & Headers
    val searchPlaceholder: String,
    val premiumBadge: String,
    val ownerRevenue: String,

    // Ads & Premium
    val adSponsored: String,
    val adSkipIn: String,
    val adSkipButton: String,
    val adOwnerEarningAlert: String,
    val getPremiumTitle: String,
    val getPremiumSubtitle: String,
    val getPremiumButton: String,
    val premiumActiveBanner: String,
    val subscriptionPrice: String,
    val subscriptionPeriod: String,
    val noAdsFeature: String,
    val bgPlaybackFeature: String,
    val hdStreamingFeature: String,

    // Settings
    val settingsTitle: String,
    val languageSettingTitle: String,
    val languageSettingSubtitle: String,
    val ownerStatsTitle: String,
    val ownerStatsSubtitle: String,
    val videoQualitySetting: String,
    val historySetting: String,
    val clearHistoryConfirm: String,
    val cancel: String,
    val apply: String
)

object LocalizationManager {
    fun getStrings(language: AppLanguage): AppStrings {
        return when (language) {
            AppLanguage.ENGLISH -> AppStrings(
                navHome = "Home",
                navShorts = "Shorts",
                navCreate = "Upload",
                navSubscriptions = "Subscriptions",
                navYou = "You",
                searchPlaceholder = "Search BhartTube...",
                premiumBadge = "Premium 👑",
                ownerRevenue = "Owner Earnings",
                adSponsored = "Sponsored • Ad",
                adSkipIn = "Skip in %ds",
                adSkipButton = "Skip Ad ⏩",
                adOwnerEarningAlert = "App Owner Earned +₹1.25 on this Ad view",
                getPremiumTitle = "BhartTube Premium (Ad-Free)",
                getPremiumSubtitle = "Watch unlimited videos without any ads for 1 month",
                getPremiumButton = "Subscribe for ₹99/month",
                premiumActiveBanner = "👑 Premium Member: Ad-Free Experience Active",
                subscriptionPrice = "₹99",
                subscriptionPeriod = "1 Month (30 Days)",
                noAdsFeature = "Zero Ads on any video or shorts",
                bgPlaybackFeature = "Background Playback & PiP mode",
                hdStreamingFeature = "Ultra HD 1080p high bitrate streaming",
                settingsTitle = "Settings",
                languageSettingTitle = "App Language",
                languageSettingSubtitle = "Select your preferred language",
                ownerStatsTitle = "App Owner Monetization & Earnings",
                ownerStatsSubtitle = "Track ad revenue and premium subscription income",
                videoQualitySetting = "Video Playback Quality",
                historySetting = "Watch History & Privacy",
                clearHistoryConfirm = "Clear All Watch History",
                cancel = "Cancel",
                apply = "Apply"
            )

            AppLanguage.HINDI -> AppStrings(
                navHome = "होम",
                navShorts = "शॉर्ट्स",
                navCreate = "अपलोड",
                navSubscriptions = "सब्सक्रिप्शन",
                navYou = "प्रोफ़ाइल",
                searchPlaceholder = "भारतट्यूब में खोजें...",
                premiumBadge = "प्रीमियम 👑",
                ownerRevenue = "ऐप ओनर कमाई",
                adSponsored = "प्रायोजित • विज्ञापन",
                adSkipIn = "%d सेकंड में छोड़ें",
                adSkipButton = "विज्ञापन छोड़ें ⏩",
                adOwnerEarningAlert = "इस विज्ञापन से ऐप ओनर ने कमाए +₹1.25",
                getPremiumTitle = "भारतट्यूब प्रीमियम (ऐड-मुक्त)",
                getPremiumSubtitle = "1 महीने तक बिना किसी विज्ञापन के वीडियो देखें",
                getPremiumButton = "₹99/माह में सब्सक्राइब करें",
                premiumActiveBanner = "👑 प्रीमियम सदस्य: ऐड-मुक्त अनुभव सक्रिय है",
                subscriptionPrice = "₹99",
                subscriptionPeriod = "1 महीना (30 दिन)",
                noAdsFeature = "किसी भी वीडियो या शॉर्ट्स पर कोई ऐड नहीं",
                bgPlaybackFeature = "बैकग्राउंड प्लेबैक और पिक्चर-इन-पिक्चर",
                hdStreamingFeature = "अल्ट्रा एचडी 1080p हाई बिटरेट स्ट्रीमिंग",
                settingsTitle = "सेटिंग्स",
                languageSettingTitle = "ऐप की भाषा",
                languageSettingSubtitle = "अपनी पसंदीदा भाषा चुनें",
                ownerStatsTitle = "ऐप ओनर कमाई व रेवेन्यू",
                ownerStatsSubtitle = "ऐड रेवेन्यू व ₹99 सब्सक्रिप्शन आय का विवरण",
                videoQualitySetting = "वीडियो प्लेबैक क्वालिटी",
                historySetting = "देखे गए वीडियो व गोपनीयता",
                clearHistoryConfirm = "सभी वीडियो इतिहास साफ़ करें",
                cancel = "रद्द करें",
                apply = "लागू करें"
            )

            AppLanguage.HINGLISH -> AppStrings(
                navHome = "Home (होम)",
                navShorts = "Shorts (शॉर्ट्स)",
                navCreate = "Upload (अपलोड)",
                navSubscriptions = "Subscriptions",
                navYou = "You (प्रोफ़ाइल)",
                searchPlaceholder = "Search video, creator...",
                premiumBadge = "Premium Pass 👑",
                ownerRevenue = "Owner Ki Earning",
                adSponsored = "Sponsored • Ad",
                adSkipIn = "Skip in %ds",
                adSkipButton = "Skip Ad ⏩",
                adOwnerEarningAlert = "Is Ad se App Owner ki earning hui +₹1.25",
                getPremiumTitle = "BhartTube Premium (No Ads)",
                getPremiumSubtitle = "1 month ke liye koi bhi ad nahi chalegi",
                getPremiumButton = "Get Subscription for ₹99/mo",
                premiumActiveBanner = "👑 Premium Active: Koi Ad nahi aayegi",
                subscriptionPrice = "₹99",
                subscriptionPeriod = "1 Month (30 Days)",
                noAdsFeature = "Video par koi ad nahi chalegi",
                bgPlaybackFeature = "Background Playback support",
                hdStreamingFeature = "Full HD 1080p video streaming",
                settingsTitle = "Settings (सेटिंग्स)",
                languageSettingTitle = "Language (भाषा)",
                languageSettingSubtitle = "Apni language select karein",
                ownerStatsTitle = "App Owner Earning Dashboard",
                ownerStatsSubtitle = "Ads aur ₹99 subscriptions se total earning",
                videoQualitySetting = "Video Quality (क्वालिटी)",
                historySetting = "Watch History (इतिहास)",
                clearHistoryConfirm = "History Clear Karein",
                cancel = "Cancel",
                apply = "Save Language"
            )
        }
    }
}
