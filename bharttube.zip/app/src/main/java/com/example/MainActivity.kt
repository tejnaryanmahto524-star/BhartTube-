package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.BhartTubeDatabase
import com.example.data.model.VideoEntity
import com.example.data.repository.BhartTubeRepository
import com.example.ui.components.BhartTubeBottomBar
import com.example.ui.components.BhartTubeTopBar
import com.example.ui.screens.AllSubscriptionsScreen
import com.example.ui.screens.ChannelPageScreen
import com.example.ui.screens.EarnMoneyScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.ShortsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.SubscriptionsScreen
import com.example.ui.screens.UploadVideoScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.screens.WatchHistoryScreen
import com.example.ui.screens.YouProfileScreen
import com.example.ui.theme.BhartTubeTheme
import com.example.ui.viewmodel.BhartTubeViewModel
import com.example.ui.viewmodel.BhartTubeViewModelFactory
import com.example.ui.viewmodel.ScreenDestination

class MainActivity : ComponentActivity() {

    private val viewModel: BhartTubeViewModel by viewModels {
        val database = BhartTubeDatabase.getDatabase(applicationContext)
        val repository = BhartTubeRepository(database)
        BhartTubeViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BhartTubeTheme(darkTheme = true) {
                BhartTubeApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun BhartTubeApp(viewModel: BhartTubeViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val activeVideo by viewModel.activeVideo.collectAsStateWithLifecycle()
    val userFeedback by viewModel.userFeedback.collectAsStateWithLifecycle()
    val uploadMessage by viewModel.uploadMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userFeedback) {
        userFeedback?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearFeedback()
        }
    }

    LaunchedEffect(uploadMessage) {
        uploadMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearFeedback()
        }
    }

    fun shareVideo(video: VideoEntity) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "Watch '${video.title}' on BhartTube! https://bharttube.app/watch?v=${video.id}")
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share video via")
        context.startActivity(shareIntent)
    }

    fun shareApp() {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "Watch trending Indian videos, Shorts, and monetize content on BhartTube! https://bharttube.app")
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share BhartTube via")
        context.startActivity(shareIntent)
    }

    // Handle System Back Button
    BackHandler(enabled = activeVideo != null || currentScreen !is ScreenDestination.Home) {
        if (activeVideo != null) {
            viewModel.closePlayer()
        } else if (currentScreen is ScreenDestination.ChannelPage || currentScreen is ScreenDestination.AllSubscriptions) {
            viewModel.navigateTo(ScreenDestination.Subscriptions)
        } else if (currentScreen is ScreenDestination.WatchHistory || currentScreen is ScreenDestination.CreatorStudio) {
            viewModel.navigateTo(ScreenDestination.You)
        } else {
            viewModel.navigateTo(ScreenDestination.Home)
        }
    }

    var showSplash by rememberSaveable { mutableStateOf(true) }

    Crossfade(
        targetState = showSplash,
        animationSpec = tween(400),
        label = "splash_crossfade"
    ) { isSplash ->
        if (isSplash) {
            SplashScreen(
                onSplashFinished = { showSplash = false }
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                Scaffold(
            topBar = {
                // Show TopBar on main browsing tabs when not playing video
                if (activeVideo == null &&
                    currentScreen !is ScreenDestination.Search &&
                    currentScreen !is ScreenDestination.Upload &&
                    currentScreen !is ScreenDestination.CreatorStudio &&
                    currentScreen !is ScreenDestination.ChannelPage &&
                    currentScreen !is ScreenDestination.AllSubscriptions &&
                    currentScreen !is ScreenDestination.WatchHistory
                ) {
                    BhartTubeTopBar(
                        onSearchClick = { viewModel.navigateTo(ScreenDestination.Search) },
                        onNotificationsClick = { viewModel.navigateTo(ScreenDestination.Subscriptions) },
                        onProfileClick = { viewModel.navigateTo(ScreenDestination.You) },
                        onShareClick = { shareApp() }
                    )
                }
            },
            bottomBar = {
                // Show BottomBar on standard destinations when not playing fullscreen video
                if (activeVideo == null &&
                    currentScreen !is ScreenDestination.Upload &&
                    currentScreen !is ScreenDestination.CreatorStudio &&
                    currentScreen !is ScreenDestination.ChannelPage
                ) {
                    BhartTubeBottomBar(
                        currentScreen = currentScreen,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }
            },
            snackbarHost = { SnackbarHost(snackbarHostState) },
            modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    is ScreenDestination.Home -> {
                        HomeScreen(
                            viewModel = viewModel,
                            onVideoClick = { viewModel.playVideo(it) },
                            onShortClick = { viewModel.playVideo(it) },
                            onShare = { shareVideo(it) },
                            onChannelClick = { viewModel.openChannelPage(it) }
                        )
                    }

                    is ScreenDestination.Shorts -> {
                        ShortsScreen(
                            viewModel = viewModel,
                            onShare = { shareVideo(it) }
                        )
                    }

                    is ScreenDestination.Upload -> {
                        UploadVideoScreen(
                            viewModel = viewModel,
                            onBack = { viewModel.navigateTo(ScreenDestination.Home) }
                        )
                    }

                    is ScreenDestination.Subscriptions -> {
                        SubscriptionsScreen(
                            viewModel = viewModel,
                            onVideoClick = { viewModel.playVideo(it) },
                            onShare = { shareVideo(it) },
                            onChannelClick = { viewModel.openChannelPage(it) },
                            onOpenAllSubscriptions = { viewModel.openAllSubscriptions() }
                        )
                    }

                    is ScreenDestination.AllSubscriptions -> {
                        AllSubscriptionsScreen(
                            viewModel = viewModel,
                            onBack = { viewModel.navigateTo(ScreenDestination.Subscriptions) },
                            onChannelClick = { viewModel.openChannelPage(it) }
                        )
                    }

                    is ScreenDestination.ChannelPage -> {
                        val page = currentScreen as ScreenDestination.ChannelPage
                        ChannelPageScreen(
                            channelName = page.channelName,
                            viewModel = viewModel,
                            onBack = { viewModel.navigateTo(ScreenDestination.Subscriptions) },
                            onVideoClick = { viewModel.playVideo(it) },
                            onShare = { shareVideo(it) }
                        )
                    }

                    is ScreenDestination.You -> {
                        YouProfileScreen(
                            viewModel = viewModel,
                            onVideoClick = { viewModel.playVideo(it) },
                            onNavigateToEarn = { viewModel.navigateTo(ScreenDestination.CreatorStudio) },
                            onChannelClick = { viewModel.openChannelPage(it) },
                            onOpenAllSubscriptions = { viewModel.openAllSubscriptions() },
                            onNavigateToHistory = { viewModel.navigateTo(ScreenDestination.WatchHistory) }
                        )
                    }

                    is ScreenDestination.WatchHistory -> {
                        WatchHistoryScreen(
                            viewModel = viewModel,
                            onBack = { viewModel.navigateTo(ScreenDestination.You) },
                            onVideoClick = { viewModel.playVideo(it) },
                            onShare = { shareVideo(it) },
                            onChannelClick = { viewModel.openChannelPage(it) }
                        )
                    }

                    is ScreenDestination.Search -> {
                        SearchScreen(
                            viewModel = viewModel,
                            onVideoClick = { viewModel.playVideo(it) },
                            onBack = { viewModel.navigateTo(ScreenDestination.Home) },
                            onShare = { shareVideo(it) }
                        )
                    }

                    is ScreenDestination.CreatorStudio -> {
                        EarnMoneyScreen(
                            viewModel = viewModel,
                            onBack = { viewModel.navigateTo(ScreenDestination.You) }
                        )
                    }

                    else -> {
                        HomeScreen(
                            viewModel = viewModel,
                            onVideoClick = { viewModel.playVideo(it) },
                            onShortClick = { viewModel.playVideo(it) },
                            onShare = { shareVideo(it) },
                            onChannelClick = { viewModel.openChannelPage(it) }
                        )
                    }
                }
            }
        }

        // Active Full Video Player Screen Overlay
        activeVideo?.let { currentVideo ->
            VideoPlayerScreen(
                video = currentVideo,
                viewModel = viewModel,
                onClose = { viewModel.closePlayer() },
                onShare = { shareVideo(it) },
                onChannelClick = { channelName ->
                    viewModel.closePlayer()
                    viewModel.openChannelPage(channelName)
                },
                modifier = Modifier.fillMaxSize()
            )
        }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    androidx.compose.material3.Text(text = "Hello $name!", modifier = modifier)
}
