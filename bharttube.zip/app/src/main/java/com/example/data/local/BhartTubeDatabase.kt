package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.AppOwnerStatsEntity
import com.example.data.model.CommentEntity
import com.example.data.model.CreatorStatsEntity
import com.example.data.model.SubscriptionEntity
import com.example.data.model.VideoEntity
import com.example.data.model.WatchHistoryEntity

@Database(
    entities = [
        VideoEntity::class,
        CommentEntity::class,
        CreatorStatsEntity::class,
        WatchHistoryEntity::class,
        SubscriptionEntity::class,
        AppOwnerStatsEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class BhartTubeDatabase : RoomDatabase() {
    abstract fun videoDao(): VideoDao
    abstract fun commentDao(): CommentDao
    abstract fun creatorStatsDao(): CreatorStatsDao
    abstract fun watchHistoryDao(): WatchHistoryDao
    abstract fun subscriptionDao(): SubscriptionDao
    abstract fun appOwnerStatsDao(): AppOwnerStatsDao

    companion object {
        @Volatile
        private var INSTANCE: BhartTubeDatabase? = null

        fun getDatabase(context: Context): BhartTubeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BhartTubeDatabase::class.java,
                    "bharttube_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
