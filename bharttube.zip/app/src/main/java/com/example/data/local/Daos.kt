package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppOwnerStatsEntity
import com.example.data.model.CommentEntity
import com.example.data.model.CreatorStatsEntity
import com.example.data.model.SubscriptionEntity
import com.example.data.model.VideoEntity
import com.example.data.model.WatchHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {
    @Query("SELECT * FROM videos WHERE isShort = 0 ORDER BY timestamp DESC")
    fun getAllLongVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isShort = 1 ORDER BY timestamp DESC")
    fun getAllShorts(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos ORDER BY timestamp DESC")
    fun getAllVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE id = :id LIMIT 1")
    fun getVideoById(id: String): Flow<VideoEntity?>

    @Query("SELECT * FROM videos WHERE id = :id LIMIT 1")
    suspend fun getVideoByIdSync(id: String): VideoEntity?

    @Query("SELECT * FROM videos WHERE category = :category AND isShort = 0 ORDER BY timestamp DESC")
    fun getVideosByCategory(category: String): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isShort = 0 ORDER BY views DESC")
    fun getTrendingVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE category = :category AND isShort = 1 ORDER BY timestamp DESC")
    fun getShortsByCategory(category: String): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isLiked = 1 ORDER BY timestamp DESC")
    fun getLikedVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isSavedWatchLater = 1 ORDER BY timestamp DESC")
    fun getWatchLaterVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isDownloaded = 1 ORDER BY timestamp DESC")
    fun getDownloadedVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isUserUpload = 1 ORDER BY timestamp DESC")
    fun getUserUploadedVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%' OR channelName LIKE '%' || :query || '%'")
    fun searchVideos(query: String): Flow<List<VideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideo(video: VideoEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideos(videos: List<VideoEntity>)

    @Update
    suspend fun updateVideo(video: VideoEntity)

    @Query("UPDATE videos SET views = views + 1 WHERE id = :id")
    suspend fun incrementViews(id: String)

    @Query("UPDATE videos SET likes = likes + 1, isLiked = 1, isDisliked = 0 WHERE id = :id")
    suspend fun likeVideo(id: String)

    @Query("UPDATE videos SET likes = CASE WHEN likes > 0 THEN likes - 1 ELSE 0 END, isLiked = 0 WHERE id = :id")
    suspend fun unlikeVideo(id: String)

    @Query("UPDATE videos SET dislikes = dislikes + 1, isDisliked = 1, isLiked = 0 WHERE id = :id")
    suspend fun dislikeVideo(id: String)

    @Query("UPDATE videos SET isSavedWatchLater = :saved WHERE id = :id")
    suspend fun toggleWatchLater(id: String, saved: Boolean)

    @Query("UPDATE videos SET isDownloaded = :downloaded WHERE id = :id")
    suspend fun toggleDownload(id: String, downloaded: Boolean)

    @Query("SELECT COUNT(*) FROM videos")
    suspend fun getVideoCount(): Int

    @Query("SELECT * FROM videos WHERE channelName = :channelName ORDER BY timestamp DESC")
    fun getVideosByChannel(channelName: String): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE channelName = :channelName AND isShort = 0 ORDER BY timestamp DESC")
    fun getLongVideosByChannel(channelName: String): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE channelName = :channelName AND isShort = 1 ORDER BY timestamp DESC")
    fun getShortsByChannel(channelName: String): Flow<List<VideoEntity>>

    @Query("UPDATE videos SET isSubscribed = :subscribed WHERE channelName = :channelName")
    suspend fun updateChannelSubscriptionStatus(channelName: String, subscribed: Boolean)

    @Query("DELETE FROM videos WHERE id = :id")
    suspend fun deleteVideoById(id: String)

    @Query("SELECT * FROM videos")
    suspend fun getAllVideosSync(): List<VideoEntity>
}

@Dao
interface CommentDao {
    @Query("SELECT * FROM comments WHERE videoId = :videoId AND parentCommentId IS NULL ORDER BY isPinned DESC, timestamp DESC")
    fun getCommentsForVideo(videoId: String): Flow<List<CommentEntity>>

    @Query("SELECT * FROM comments WHERE videoId = :videoId AND parentCommentId IS NULL ORDER BY isPinned DESC, likes DESC, timestamp DESC")
    fun getTopCommentsForVideo(videoId: String): Flow<List<CommentEntity>>

    @Query("SELECT * FROM comments WHERE parentCommentId = :parentId ORDER BY timestamp ASC")
    fun getRepliesForComment(parentId: Long): Flow<List<CommentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity)

    @Query("UPDATE comments SET likes = likes + 1, isLiked = 1 WHERE id = :id")
    suspend fun likeComment(id: Long)

    @Query("UPDATE comments SET likes = CASE WHEN likes > 0 THEN likes - 1 ELSE 0 END, isLiked = 0 WHERE id = :id")
    suspend fun unlikeComment(id: Long)

    @Query("UPDATE comments SET replyCount = replyCount + 1 WHERE id = :parentId")
    suspend fun incrementReplyCount(parentId: Long)

    @Query("DELETE FROM comments WHERE id = :id OR parentCommentId = :id")
    suspend fun deleteComment(id: Long)

    @Query("SELECT COUNT(*) FROM comments WHERE videoId = :videoId")
    fun getCommentCount(videoId: String): Flow<Int>
}

@Dao
interface CreatorStatsDao {
    @Query("SELECT * FROM creator_stats WHERE id = 1 LIMIT 1")
    fun getStats(): Flow<CreatorStatsEntity?>

    @Query("SELECT * FROM creator_stats WHERE id = 1 LIMIT 1")
    suspend fun getStatsSync(): CreatorStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(stats: CreatorStatsEntity)

    @Query("UPDATE creator_stats SET watchHours = watchHours + :hours WHERE id = 1")
    suspend fun addWatchHours(hours: Double)

    @Query("UPDATE creator_stats SET shortsViews = shortsViews + :views WHERE id = 1")
    suspend fun addShortsViews(views: Long)

    @Query("UPDATE creator_stats SET subscribers = subscribers + :count WHERE id = 1")
    suspend fun addSubscribers(count: Int)

    @Query("UPDATE creator_stats SET isMonetized = 1, hasApplied = 1, estimatedRevenueInr = CASE WHEN estimatedRevenueInr = 0 THEN 1240.0 ELSE estimatedRevenueInr END WHERE id = 1")
    suspend fun approveMonetization()

    @Query("UPDATE creator_stats SET hasApplied = 1 WHERE id = 1")
    suspend fun applyForMonetization()

    @Query("UPDATE creator_stats SET bankAccountLinked = 1, bankAccountHolder = :holder, bankAccountNumber = :acc, ifscCode = :ifsc, bankName = :bankName, upiId = :upiId WHERE id = 1")
    suspend fun linkBankAccountFull(holder: String, acc: String, ifsc: String, bankName: String, upiId: String)

    @Query("UPDATE creator_stats SET bankAccountLinked = 1, bankAccountHolder = :holder, bankAccountNumber = :acc, ifscCode = :ifsc WHERE id = 1")
    suspend fun linkBankAccount(holder: String, acc: String, ifsc: String)

    @Query("UPDATE creator_stats SET estimatedRevenueInr = estimatedRevenueInr + :amount, superThanksInr = superThanksInr + :amount WHERE id = 1 AND isMonetized = 1")
    suspend fun addSuperChatEarnings(amount: Double)

    @Query("UPDATE creator_stats SET estimatedRevenueInr = estimatedRevenueInr + :amount, adWatchPageRevenueInr = adWatchPageRevenueInr + :amount WHERE id = 1 AND isMonetized = 1")
    suspend fun addAdRevenue(amount: Double)
}

@Dao
interface WatchHistoryDao {
    @Query("SELECT v.* FROM videos v INNER JOIN (SELECT videoId, MAX(watchedAt) as maxWatchedAt FROM watch_history GROUP BY videoId) w ON v.id = w.videoId ORDER BY w.maxWatchedAt DESC")
    fun getWatchHistoryVideos(): Flow<List<VideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: WatchHistoryEntity)

    @Query("DELETE FROM watch_history WHERE videoId = :videoId")
    suspend fun deleteHistoryForVideo(videoId: String)

    @Query("DELETE FROM watch_history")
    suspend fun clearHistory()

    @Query("SELECT COUNT(*) FROM watch_history")
    suspend fun getHistoryCount(): Int
}

@Dao
interface SubscriptionDao {
    @Query("SELECT * FROM subscriptions WHERE isSubscribed = 1")
    fun getAllSubscriptions(): Flow<List<SubscriptionEntity>>

    @Query("SELECT * FROM subscriptions WHERE channelName = :channelName LIMIT 1")
    fun getSubscriptionForChannel(channelName: String): Flow<SubscriptionEntity?>

    @Query("SELECT * FROM subscriptions WHERE channelName = :channelName LIMIT 1")
    suspend fun getSubscriptionForChannelSync(channelName: String): SubscriptionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscription(sub: SubscriptionEntity)

    @Query("UPDATE subscriptions SET isSubscribed = :subscribed WHERE channelName = :name")
    suspend fun toggleSubscription(name: String, subscribed: Boolean)

    @Query("UPDATE subscriptions SET hasBellNotification = :hasBell WHERE channelName = :name")
    suspend fun updateBellNotification(name: String, hasBell: Boolean)

    @Query("SELECT COUNT(*) FROM subscriptions WHERE isSubscribed = 1")
    suspend fun getSubCount(): Int
}

@Dao
interface AppOwnerStatsDao {
    @Query("SELECT * FROM app_owner_stats WHERE id = 1 LIMIT 1")
    fun getAppOwnerStats(): Flow<AppOwnerStatsEntity?>

    @Query("SELECT * FROM app_owner_stats WHERE id = 1 LIMIT 1")
    suspend fun getAppOwnerStatsSync(): AppOwnerStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(stats: AppOwnerStatsEntity)

    @Query("UPDATE app_owner_stats SET totalAdViews = totalAdViews + 1, adRevenueInr = adRevenueInr + :revenue, totalRevenueInr = totalRevenueInr + :revenue WHERE id = 1")
    suspend fun recordAdImpression(revenue: Double)

    @Query("UPDATE app_owner_stats SET isUserPremiumActive = 1, premiumActivatedAt = :activatedAt, premiumExpiresAt = :expiresAt, totalSubscribersCount = totalSubscribersCount + 1, subscriptionRevenueInr = subscriptionRevenueInr + :price, totalRevenueInr = totalRevenueInr + :price WHERE id = 1")
    suspend fun activateSubscription(activatedAt: Long, expiresAt: Long, price: Double)

    @Query("UPDATE app_owner_stats SET isUserPremiumActive = 0 WHERE id = 1")
    suspend fun cancelSubscription()

    @Query("UPDATE app_owner_stats SET selectedLanguage = :lang WHERE id = 1")
    suspend fun updateSelectedLanguage(lang: String)
}
