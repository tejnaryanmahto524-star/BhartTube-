package com.example.data.repository

import com.example.data.local.BhartTubeDatabase
import com.example.data.model.AppOwnerStatsEntity
import com.example.data.model.CommentEntity
import com.example.data.model.CreatorStatsEntity
import com.example.data.model.SubscriptionEntity
import com.example.data.model.VideoEntity
import com.example.data.model.WatchHistoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class BhartTubeRepository(private val database: BhartTubeDatabase) {

    private val videoDao = database.videoDao()
    private val commentDao = database.commentDao()
    private val creatorStatsDao = database.creatorStatsDao()
    private val watchHistoryDao = database.watchHistoryDao()
    private val subscriptionDao = database.subscriptionDao()
    private val appOwnerStatsDao = database.appOwnerStatsDao()

    val allVideos: Flow<List<VideoEntity>> = videoDao.getAllLongVideos()
    val allShorts: Flow<List<VideoEntity>> = videoDao.getAllShorts()
    val likedVideos: Flow<List<VideoEntity>> = videoDao.getLikedVideos()
    val watchLaterVideos: Flow<List<VideoEntity>> = videoDao.getWatchLaterVideos()
    val downloadedVideos: Flow<List<VideoEntity>> = videoDao.getDownloadedVideos()
    val userUploadedVideos: Flow<List<VideoEntity>> = videoDao.getUserUploadedVideos()
    val creatorStats: Flow<CreatorStatsEntity?> = creatorStatsDao.getStats()
    val watchHistory: Flow<List<VideoEntity>> = watchHistoryDao.getWatchHistoryVideos()
    val subscriptions: Flow<List<SubscriptionEntity>> = subscriptionDao.getAllSubscriptions()
    val appOwnerStats: Flow<AppOwnerStatsEntity?> = appOwnerStatsDao.getAppOwnerStats()

    fun getVideosByCategory(category: String): Flow<List<VideoEntity>> {
        return when (category) {
            "All" -> videoDao.getAllLongVideos()
            "Trending" -> videoDao.getTrendingVideos()
            else -> videoDao.getVideosByCategory(category)
        }
    }

    fun getShortsByCategory(category: String): Flow<List<VideoEntity>> {
        return if (category == "All" || category == "Trending") {
            videoDao.getAllShorts()
        } else {
            videoDao.getShortsByCategory(category)
        }
    }

    fun getVideoById(id: String): Flow<VideoEntity?> = videoDao.getVideoById(id)

    fun getCommentsForVideo(videoId: String, sortByTop: Boolean = false): Flow<List<CommentEntity>> {
        return if (sortByTop) {
            commentDao.getTopCommentsForVideo(videoId)
        } else {
            commentDao.getCommentsForVideo(videoId)
        }
    }

    fun getRepliesForComment(parentId: Long): Flow<List<CommentEntity>> = commentDao.getRepliesForComment(parentId)

    fun searchVideos(query: String): Flow<List<VideoEntity>> = videoDao.searchVideos(query)

    suspend fun seedInitialDataIfEmpty() = withContext(Dispatchers.IO) {
        if (videoDao.getVideoCount() == 0) {
            val initialVideos = listOf(
                VideoEntity(
                    id = "v1",
                    title = "Chandrayaan 3 Moon Landing Mission - The Historic Moment of Bharat",
                    description = "Watch the full documentary of ISRO's historic Chandrayaan 3 lunar touchdown at the moon's South Pole. A proud milestone for Indian space research and technology.\n\n#Chandrayaan3 #ISRO #BharatTube #SpaceScience",
                    channelName = "Bharat Science & Tech",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1541185933-ef5d8ed016c2?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "3.4M subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=800&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFF1A237E,0xFF0D47A1",
                    durationText = "18:42",
                    durationSeconds = 1122,
                    views = 4850000,
                    likes = 340000,
                    dislikes = 1200,
                    uploadDateText = "3 months ago",
                    category = "Tech",
                    isShort = false
                ),
                VideoEntity(
                    id = "v2",
                    title = "Top 10 Street Foods of Old Delhi | Chandni Chowk Food Tour",
                    description = "Join our food journey tasting authentic parathas, jalebi, chole bhature and rabri falooda at historic Old Delhi lanes! Don't forget to like and subscribe for more foodie vlogs.",
                    channelName = "Desi Food Express",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "1.8M subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFFE65100,0xFFFF6F00",
                    durationText = "14:15",
                    durationSeconds = 855,
                    views = 1250000,
                    likes = 98000,
                    dislikes = 450,
                    uploadDateText = "1 week ago",
                    category = "Cooking",
                    isShort = false
                ),
                VideoEntity(
                    id = "v3",
                    title = "Learn Android App Development in Kotlin & Jetpack Compose 2026",
                    description = "Complete masterclass for building modern Android apps with Jetpack Compose, Material 3, Coroutines, Flow, and Room Database. Zero to hero in Hindi & English.",
                    channelName = "Code with Bharat",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "750K subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFF1B5E20,0xFF2E7D32",
                    durationText = "45:30",
                    durationSeconds = 2730,
                    views = 680000,
                    likes = 54000,
                    dislikes = 210,
                    uploadDateText = "2 weeks ago",
                    category = "Education",
                    isShort = false
                ),
                VideoEntity(
                    id = "v4",
                    title = "Himalayan Road Trip Vlog - Spiti Valley Winter Adventure",
                    description = "Traveling through treacherous roads, frozen rivers, snow-covered valleys, and ancient monasteries at 12,000 feet altitude. Pure adrenaline and raw beauty of Himalayas.",
                    channelName = "Wanderlust India",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "920K subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFF37474F,0xFF263238",
                    durationText = "22:10",
                    durationSeconds = 1330,
                    views = 940000,
                    likes = 82000,
                    dislikes = 300,
                    uploadDateText = "4 days ago",
                    category = "Vlogs",
                    isShort = false
                ),
                VideoEntity(
                    id = "v5",
                    title = "Best Comedy Standup: Family WhatsApp Groups & Indian Weddings",
                    description = "Hilarious observations on joint families, rishta aunties, awkward uncle dances, and unending WhatsApp forwards! Live show recorded in Mumbai.",
                    channelName = "Laugh Out Bharat",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "2.1M subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFF4A148C,0xFF6A1B9A",
                    durationText = "16:48",
                    durationSeconds = 1008,
                    views = 3100000,
                    likes = 290000,
                    dislikes = 800,
                    uploadDateText = "1 month ago",
                    category = "Comedy",
                    isShort = false
                ),
                VideoEntity(
                    id = "v6",
                    title = "Soulful Sitar & Tabla Jugalbandi - Raag Yaman Live Concert",
                    description = "Immerse yourself into peaceful Indian classical music melodies. Featuring maestro sitar and tabla performance that calms your mind and soul.",
                    channelName = "Sangeet Bharat",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "1.1M subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFF880E4F,0xFFAD1457",
                    durationText = "28:12",
                    durationSeconds = 1692,
                    views = 820000,
                    likes = 71000,
                    dislikes = 150,
                    uploadDateText = "3 weeks ago",
                    category = "Music",
                    isShort = false
                ),
                VideoEntity(
                    id = "v7",
                    title = "India vs Australia T20 Thriller Match Highlights & Analysis",
                    description = "Last over nail-biting finish, 6s and wickets compilation, expert commentary and match breakdown.",
                    channelName = "Cricket Zone Bharat",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "4.5M subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1531415074868-036b1c57e3ce?w=800&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFF004D40,0xFF00695C",
                    durationText = "11:05",
                    durationSeconds = 665,
                    views = 5200000,
                    likes = 420000,
                    dislikes = 1400,
                    uploadDateText = "1 day ago",
                    category = "Gaming",
                    isShort = false
                ),
                // SHORTS:
                VideoEntity(
                    id = "s1",
                    title = "Top 3 Hidden Android Features You Must Try! 🔥 #Shorts #Tech",
                    description = "Did you know your phone has these secret gestures? Quick hack for developer options and screen split!",
                    channelName = "Tech Gyan Hindi",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "1.5M subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFFD50000,0xFFFF1744",
                    durationText = "0:38",
                    durationSeconds = 38,
                    views = 1200000,
                    likes = 94000,
                    dislikes = 320,
                    uploadDateText = "1 day ago",
                    category = "Tech",
                    isShort = true
                ),
                VideoEntity(
                    id = "s2",
                    title = "Instant 2-Minute Garlic Butter Naan Recipe on Tawa! 🫓🤤 #Shorts #Food",
                    description = "Restaurant style crispy soft garlic naan at home in 2 minutes without tandoor!",
                    channelName = "Swadisht Rasoi",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "2.8M subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=600&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFFFF6D00,0xFFFF9100",
                    durationText = "0:45",
                    durationSeconds = 45,
                    views = 2800000,
                    likes = 210000,
                    dislikes = 540,
                    uploadDateText = "3 days ago",
                    category = "Cooking",
                    isShort = true
                ),
                VideoEntity(
                    id = "s3",
                    title = "When Mom Catches You Ordering Food Late at Night 😂🤦‍♂️ #Shorts #Comedy",
                    description = "Zomato delivery boy arrived at 2 AM and mom opened the door! Relatable desi family humor.",
                    channelName = "Desi Vines",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "3.2M subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=600&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFF6200EA,0xFF651FFF",
                    durationText = "0:52",
                    durationSeconds = 52,
                    views = 4100000,
                    likes = 380000,
                    dislikes = 900,
                    uploadDateText = "5 days ago",
                    category = "Comedy",
                    isShort = true
                ),
                VideoEntity(
                    id = "s4",
                    title = "Unreal Goal in Football Extra Time! ⚽🔥 #Shorts #Sports",
                    description = "Incredible bicycle kick in the 94th minute! Crowd went absolutely wild!",
                    channelName = "Sports Arena Bharat",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "890K subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFF0091EA,0xFF00B0FF",
                    durationText = "0:25",
                    durationSeconds = 25,
                    views = 1950000,
                    likes = 175000,
                    dislikes = 400,
                    uploadDateText = "2 days ago",
                    category = "Gaming",
                    isShort = true
                ),
                VideoEntity(
                    id = "s5",
                    title = "Quick Meditation Sound to Calm Your Mind in 30 Seconds 🧘‍♂️✨ #Shorts",
                    description = "Breathe in, breathe out. Healing 432Hz binaural frequencies for stress relief.",
                    channelName = "Peace & Soul",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "600K subscribers",
                    thumbnailUrl = "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=600&auto=format&fit=crop&q=80",
                    videoGradientColors = "0xFF00BFA5,0xFF1DE9B6",
                    durationText = "0:30",
                    durationSeconds = 30,
                    views = 850000,
                    likes = 78000,
                    dislikes = 110,
                    uploadDateText = "1 week ago",
                    category = "Music",
                    isShort = true
                )
            )

            videoDao.insertVideos(initialVideos)

            // Initial Comments with Pinned Creator Comments & Discussions
            val initialComments = listOf(
                CommentEntity(
                    id = 1,
                    videoId = "v1",
                    authorName = "Bharat Science & Tech",
                    authorAvatarUrl = "https://images.unsplash.com/photo-1541185933-ef5d8ed016c2?w=150&auto=format&fit=crop&q=80",
                    text = "Welcome to BhartTube! 🚀 Drop your questions regarding Chandrayaan's lunar orbital maneuvers and telemetry below. We are answering as many as possible! Jai Hind 🇮🇳",
                    timeAgo = "1 month ago",
                    likes = 5420,
                    isPinned = true,
                    isHeartedByCreator = true,
                    replyCount = 2
                ),
                CommentEntity(
                    id = 2,
                    videoId = "v1",
                    authorName = "Aman Sharma",
                    authorAvatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80",
                    text = "Proud Indian moment! ISRO scientists truly proved that dedication can conquer space. Jai Hind 🇮🇳",
                    timeAgo = "1 month ago",
                    likes = 4200,
                    isHeartedByCreator = true,
                    replyCount = 1
                ),
                CommentEntity(
                    id = 3,
                    videoId = "v1",
                    authorName = "Priya Verma",
                    authorAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80",
                    text = "The cinematography and explanation in this BhartTube documentary is world-class. Shared with all my school students! 🌟",
                    timeAgo = "2 weeks ago",
                    likes = 1850,
                    replyCount = 0
                ),
                CommentEntity(
                    id = 4,
                    videoId = "v1",
                    authorName = "Vikram Singh",
                    authorAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80",
                    text = "BhartTube is so smooth! The video streaming and audio clarity is top notch.",
                    timeAgo = "3 days ago",
                    likes = 310,
                    replyCount = 0
                ),
                // Discussion replies under comment 1
                CommentEntity(
                    id = 5,
                    videoId = "v1",
                    authorName = "Rajesh Pilot",
                    text = "What was the exact velocity during soft landing initiation phase?",
                    timeAgo = "3 weeks ago",
                    likes = 85,
                    parentCommentId = 1L
                ),
                CommentEntity(
                    id = 6,
                    videoId = "v1",
                    authorName = "Bharat Science & Tech",
                    text = "Rough braking started around 1.68 km/sec at 30km altitude! Amazing physics at play.",
                    timeAgo = "3 weeks ago",
                    likes = 192,
                    isHeartedByCreator = true,
                    parentCommentId = 1L
                ),
                // Discussion reply under comment 2
                CommentEntity(
                    id = 7,
                    videoId = "v1",
                    authorName = "Ananya Roy",
                    text = "True pride for 1.4 billion people! Proud to watch this on BhartTube.",
                    timeAgo = "3 weeks ago",
                    likes = 64,
                    parentCommentId = 2L
                ),
                // Comments for v2
                CommentEntity(
                    id = 8,
                    videoId = "v2",
                    authorName = "Desi Food Express",
                    text = "Which shop in Old Delhi is your personal favorite? Let us know in comments for our next episode! 🥘🍛",
                    timeAgo = "1 week ago",
                    likes = 890,
                    isPinned = true,
                    isHeartedByCreator = true,
                    replyCount = 1
                ),
                CommentEntity(
                    id = 9,
                    videoId = "v2",
                    authorName = "Rohan Malhotra",
                    authorAvatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80",
                    text = "Chandni Chowk parathas with rabri falooda is pure bliss! Best food video on BhartTube.",
                    timeAgo = "5 days ago",
                    likes = 540
                ),
                CommentEntity(
                    id = 10,
                    videoId = "v2",
                    authorName = "Kavita Sen",
                    text = "Natraj Dahi Bhalle is a must visit near Paranthe Wali Gali!",
                    timeAgo = "4 days ago",
                    likes = 120,
                    parentCommentId = 8L
                )
            )

            initialComments.forEach { commentDao.insertComment(it) }

            // Subscriptions
            val initialSubs = listOf(
                SubscriptionEntity(
                    channelName = "Bharat Science & Tech",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1541185933-ef5d8ed016c2?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "3.4M subscribers",
                    isSubscribed = true,
                    hasBellNotification = true,
                    channelDescription = "Exploring space missions, ISRO breakthroughs, artificial intelligence, and incredible innovations from Bharat to the world!",
                    handle = "@bharat_science_tech",
                    bannerGradient = "0xFF000428,0xFF004E92",
                    totalVideos = 184,
                    joinedDate = "Joined Aug 2021"
                ),
                SubscriptionEntity(
                    channelName = "Desi Food Express",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "1.8M subscribers",
                    isSubscribed = true,
                    hasBellNotification = true,
                    channelDescription = "Authentic street food, traditional royal recipes, secret spices, and food trail vlogs across Indian cities and towns.",
                    handle = "@desi_food_express",
                    bannerGradient = "0xFFFF512F,0xFFDD2476",
                    totalVideos = 290,
                    joinedDate = "Joined Mar 2020"
                ),
                SubscriptionEntity(
                    channelName = "Code with Bharat",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "750K subscribers",
                    isSubscribed = true,
                    hasBellNotification = false,
                    channelDescription = "Master modern Android, Kotlin, Jetpack Compose, Full Stack, and Cloud. Coding tutorials in simple Hindi!",
                    handle = "@code_with_bharat",
                    bannerGradient = "0xFF141E30,0xFF243B55",
                    totalVideos = 145,
                    joinedDate = "Joined Feb 2022"
                ),
                SubscriptionEntity(
                    channelName = "Wanderlust India",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "920K subscribers",
                    isSubscribed = true,
                    hasBellNotification = true,
                    channelDescription = "Breathtaking travel documentaries, bike trips across Himalayas, backpacking guides, and hidden gems of India.",
                    handle = "@wanderlust_india",
                    bannerGradient = "0xFF1D976C,0xFF93F9B9",
                    totalVideos = 98,
                    joinedDate = "Joined Jul 2021"
                ),
                SubscriptionEntity(
                    channelName = "Laugh Out Bharat",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "2.1M subscribers",
                    isSubscribed = true,
                    hasBellNotification = true,
                    channelDescription = "Non-stop comedy sketches, stand-up specials, hilarious parodies, and relatable desi moments guaranteed to make you laugh!",
                    handle = "@laugh_out_bharat",
                    bannerGradient = "0xFFFF8008,0xFFFFC837",
                    totalVideos = 210,
                    joinedDate = "Joined Nov 2019"
                ),
                SubscriptionEntity(
                    channelName = "Sangeet Bharat",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "1.1M subscribers",
                    isSubscribed = true,
                    hasBellNotification = true,
                    channelDescription = "Classical ragas, sitar and flute melodies, devotional bhajan recitals, and fusion sounds of ancient and modern India.",
                    handle = "@sangeet_bharat",
                    bannerGradient = "0xFF8E2DE2,0xFF4A00E0",
                    totalVideos = 160,
                    joinedDate = "Joined Apr 2021"
                ),
                SubscriptionEntity(
                    channelName = "Cricket Zone Bharat",
                    channelAvatarUrl = "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80",
                    subscriberCount = "4.5M subscribers",
                    isSubscribed = false,
                    hasBellNotification = false,
                    channelDescription = "Live match discussions, pitch reports, player stats, commentary, and match highlights from the cricket world.",
                    handle = "@cricket_zone_bharat",
                    bannerGradient = "0xFF0052D4,0xFF4364F7",
                    totalVideos = 420,
                    joinedDate = "Joined Oct 2018"
                )
            )
            initialSubs.forEach { subscriptionDao.insertSubscription(it) }

            // Creator Stats (Monetization Hub)
            if (creatorStatsDao.getStatsSync() == null) {
                creatorStatsDao.insertOrUpdate(
                    CreatorStatsEntity(
                        id = 1,
                        channelName = "My BhartTube Channel",
                        handle = "@my_bharttube_channel",
                        subscribers = 860,
                        targetSubscribers = 1000,
                        watchHours = 1140.0,
                        targetWatchHours = 1500.0,
                        shortsViews = 3850000L,
                        targetShortsViews = 5000000L,
                        totalVideosUploaded = 8,
                        isMonetized = false,
                        hasApplied = false,
                        estimatedRevenueInr = 0.0, // Strictly 0.0 before monetization
                        adWatchPageRevenueInr = 0.0,
                        shortsFeedRevenueInr = 0.0,
                        superThanksInr = 0.0
                    )
                )
            }

            // Seed rich Gaming, Music, and Tech videos for category filtering
            if (videoDao.getVideoByIdSync("v_gaming1") == null) {
                val categoryVideos = listOf(
                    VideoEntity(
                        id = "v_gaming1",
                        title = "BGMI Pro Invitational 2026 Grand Finals - Epic 1v4 Final Circle Clutch!",
                        description = "Unbelievable moments from the BGMI National Championship! Watch the insane sniper shots, smoke plays, and high-adrenaline victory dinner. Don't forget to subscribe for more esports tournaments.",
                        channelName = "Desi Esports Hub",
                        channelAvatarUrl = "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80",
                        subscriberCount = "3.1M subscribers",
                        thumbnailUrl = "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80",
                        videoGradientColors = "0xFF1B0000,0xFFB71C1C",
                        durationText = "15:20",
                        durationSeconds = 920,
                        views = 2340000,
                        likes = 210000,
                        dislikes = 450,
                        uploadDateText = "2 days ago",
                        category = "Gaming",
                        isShort = false
                    ),
                    VideoEntity(
                        id = "v_gaming2",
                        title = "GTA 6 Gameplay Walkthrough - Ultra Realistic RTX 5090 Graphics & First Mission",
                        description = "First 20 minutes of gameplay with max settings, ray-tracing, and Hindi commentary. Exploring the dynamic open world, car chases, and physics engine in 4K 60FPS.",
                        channelName = "Gamer Bharat Live",
                        channelAvatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
                        subscriberCount = "1.9M subscribers",
                        thumbnailUrl = "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop&q=80",
                        videoGradientColors = "0xFF0D47A1,0xFF1565C0",
                        durationText = "24:45",
                        durationSeconds = 1485,
                        views = 3100000,
                        likes = 290000,
                        dislikes = 800,
                        uploadDateText = "5 days ago",
                        category = "Gaming",
                        isShort = false
                    ),
                    VideoEntity(
                        id = "v_music1",
                        title = "Midnight Bollywood Lo-Fi Chill Beats • Rain Sound Hindi Study Mix [Slowed + Reverb]",
                        description = "Relax, study, or sleep with peaceful lo-fi Indian beats and soulful acoustic melodies. Pure serenity for your mind and soul. Headphones recommended.",
                        channelName = "Lo-Fi Bharat Beats",
                        channelAvatarUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&auto=format&fit=crop&q=80",
                        subscriberCount = "1.4M subscribers",
                        thumbnailUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=80",
                        videoGradientColors = "0xFF263238,0xFF37474F",
                        durationText = "32:10",
                        durationSeconds = 1930,
                        views = 1750000,
                        likes = 145000,
                        dislikes = 230,
                        uploadDateText = "1 week ago",
                        category = "Music",
                        isShort = false
                    ),
                    VideoEntity(
                        id = "v_music2",
                        title = "Acoustic Unplugged Bollywood Medley 2026 • Live Rooftop Sunset Jam",
                        description = "Soulful guitar chords and melodic vocals singing the most heartfelt indie and Bollywood songs under the Mumbai evening sky.",
                        channelName = "Sangeet Bharat",
                        channelAvatarUrl = "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80",
                        subscriberCount = "1.1M subscribers",
                        thumbnailUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=80",
                        videoGradientColors = "0xFF4A148C,0xFF7B1FA2",
                        durationText = "19:40",
                        durationSeconds = 1180,
                        views = 1420000,
                        likes = 118000,
                        dislikes = 190,
                        uploadDateText = "3 days ago",
                        category = "Music",
                        isShort = false
                    ),
                    VideoEntity(
                        id = "v_tech2",
                        title = "AI in 2026: Top 10 Futuristic Breakthroughs That Change Everything!",
                        description = "From autonomous humanoid robots to next-gen quantum chips and AI personal agents. Discover how technology is transforming our daily lives in India and globally.",
                        channelName = "Bharat Science & Tech",
                        channelAvatarUrl = "https://images.unsplash.com/photo-1541185933-ef5d8ed016c2?w=150&auto=format&fit=crop&q=80",
                        subscriberCount = "3.4M subscribers",
                        thumbnailUrl = "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&auto=format&fit=crop&q=80",
                        videoGradientColors = "0xFF004D40,0xFF00796B",
                        durationText = "17:35",
                        durationSeconds = 1055,
                        views = 1950000,
                        likes = 160000,
                        dislikes = 310,
                        uploadDateText = "3 days ago",
                        category = "Tech",
                        isShort = false
                    )
                )
                videoDao.insertVideos(categoryVideos)
            }

            // Initial seed watch history so user has immediate history videos to test and re-watch
            if (watchHistoryDao.getHistoryCount() == 0) {
                val now = System.currentTimeMillis()
                watchHistoryDao.insertHistory(
                    WatchHistoryEntity(
                        videoId = "v1",
                        watchedAt = now - 1000 * 60 * 35,
                        watchDurationSeconds = 1120
                    )
                )
                watchHistoryDao.insertHistory(
                    WatchHistoryEntity(
                        videoId = "v2",
                        watchedAt = now - 1000 * 60 * 90,
                        watchDurationSeconds = 480
                    )
                )
                watchHistoryDao.insertHistory(
                    WatchHistoryEntity(
                        videoId = "v7",
                        watchedAt = now - 1000 * 60 * 240,
                        watchDurationSeconds = 600
                    )
                )
            }

            if (appOwnerStatsDao.getAppOwnerStatsSync() == null) {
                appOwnerStatsDao.insertOrUpdate(
                    com.example.data.model.AppOwnerStatsEntity(
                        id = 1,
                        ownerName = "BhartTube Platform Owner",
                        totalRevenueInr = 14250.00,
                        totalAdViews = 8400L,
                        adRevenueInr = 10500.00,
                        subscriptionRevenueInr = 3750.00,
                        totalSubscribersCount = 38,
                        isUserPremiumActive = false,
                        selectedLanguage = "en"
                    )
                )
            }

            // Auto-scan and purge any prohibited content if found
            val existing = videoDao.getAllVideosSync()
            for (v in existing) {
                val scan = com.example.safety.BhartTubeSafetyShield.scanContent(v.title, v.description, v.category)
                if (scan.isViolation) {
                    videoDao.deleteVideoById(v.id)
                }
            }
        }
    }

    var isWatchHistoryPaused: Boolean = false

    suspend fun recordVideoWatch(videoId: String, watchedSeconds: Int) = withContext(Dispatchers.IO) {
        videoDao.incrementViews(videoId)
        if (!isWatchHistoryPaused) {
            watchHistoryDao.deleteHistoryForVideo(videoId)
            watchHistoryDao.insertHistory(
                WatchHistoryEntity(
                    videoId = videoId,
                    watchedAt = System.currentTimeMillis(),
                    watchDurationSeconds = watchedSeconds
                )
            )
        }
        // Add watch hours to creator stats (realistic accumulation: 1 watch contributes hours)
        val addedHours = (watchedSeconds / 3600.0).coerceAtLeast(0.1)
        creatorStatsDao.addWatchHours(addedHours)
    }

    suspend fun recordShortsWatch(shortId: String) = withContext(Dispatchers.IO) {
        videoDao.incrementViews(shortId)
        if (!isWatchHistoryPaused) {
            watchHistoryDao.deleteHistoryForVideo(shortId)
            watchHistoryDao.insertHistory(
                WatchHistoryEntity(
                    videoId = shortId,
                    watchedAt = System.currentTimeMillis(),
                    watchDurationSeconds = 15
                )
            )
        }
        creatorStatsDao.addShortsViews(1L)
    }

    suspend fun removeFromWatchHistory(videoId: String) = withContext(Dispatchers.IO) {
        watchHistoryDao.deleteHistoryForVideo(videoId)
    }

    suspend fun toggleLike(videoId: String, currentLiked: Boolean) = withContext(Dispatchers.IO) {
        if (currentLiked) {
            videoDao.unlikeVideo(videoId)
        } else {
            videoDao.likeVideo(videoId)
        }
    }

    suspend fun dislikeVideo(videoId: String) = withContext(Dispatchers.IO) {
        videoDao.dislikeVideo(videoId)
    }

    suspend fun toggleWatchLater(videoId: String, saved: Boolean) = withContext(Dispatchers.IO) {
        videoDao.toggleWatchLater(videoId, saved)
    }

    suspend fun toggleDownload(videoId: String, downloaded: Boolean) = withContext(Dispatchers.IO) {
        videoDao.toggleDownload(videoId, downloaded)
    }

    suspend fun addComment(
        videoId: String,
        author: String,
        text: String,
        parentId: Long? = null,
        isPinned: Boolean = false,
        isHearted: Boolean = false
    ) = withContext(Dispatchers.IO) {
        commentDao.insertComment(
            CommentEntity(
                videoId = videoId,
                authorName = author,
                authorAvatarUrl = "",
                text = text,
                timeAgo = "Just now",
                likes = 0,
                parentCommentId = parentId,
                isPinned = isPinned,
                isHeartedByCreator = isHearted
            )
        )
        if (parentId != null) {
            commentDao.incrementReplyCount(parentId)
        }
    }

    suspend fun toggleLikeComment(commentId: Long, currentLiked: Boolean) = withContext(Dispatchers.IO) {
        if (currentLiked) {
            commentDao.unlikeComment(commentId)
        } else {
            commentDao.likeComment(commentId)
        }
    }

    suspend fun deleteComment(commentId: Long) = withContext(Dispatchers.IO) {
        commentDao.deleteComment(commentId)
    }

    suspend fun uploadVideo(
        title: String,
        description: String,
        category: String,
        isShort: Boolean,
        durationSeconds: Int,
        thumbnailGradient: String
    ): VideoEntity = withContext(Dispatchers.IO) {
        val id = "user_" + UUID.randomUUID().toString().take(8)
        val minutes = durationSeconds / 60
        val seconds = durationSeconds % 60
        val durationFormatted = String.format("%d:%02d", minutes, seconds)

        val newVideo = VideoEntity(
            id = id,
            title = title,
            description = description,
            channelName = "My BhartTube Channel",
            channelAvatarUrl = "",
            subscriberCount = "860 subscribers",
            thumbnailUrl = "",
            videoGradientColors = thumbnailGradient,
            durationText = durationFormatted,
            durationSeconds = durationSeconds,
            views = 1,
            likes = 0,
            dislikes = 0,
            uploadDateText = "Just now",
            category = category,
            isShort = isShort,
            isUserUpload = true
        )

        videoDao.insertVideo(newVideo)
        val currentStats = creatorStatsDao.getStatsSync()
        if (currentStats != null) {
            creatorStatsDao.insertOrUpdate(
                currentStats.copy(
                    totalVideosUploaded = currentStats.totalVideosUploaded + 1
                )
            )
        }
        newVideo
    }

    fun getVideosByChannel(channelName: String): Flow<List<VideoEntity>> {
        return videoDao.getVideosByChannel(channelName)
    }

    fun getLongVideosByChannel(channelName: String): Flow<List<VideoEntity>> {
        return videoDao.getLongVideosByChannel(channelName)
    }

    fun getShortsByChannel(channelName: String): Flow<List<VideoEntity>> {
        return videoDao.getShortsByChannel(channelName)
    }

    fun getSubscription(channelName: String): Flow<SubscriptionEntity?> {
        return subscriptionDao.getSubscriptionForChannel(channelName)
    }

    suspend fun toggleSubscription(
        channelName: String,
        subscribed: Boolean,
        avatarUrl: String = "",
        subscriberCount: String = "1M subscribers",
        description: String = "",
        handle: String = ""
    ) = withContext(Dispatchers.IO) {
        val existing = subscriptionDao.getSubscriptionForChannelSync(channelName)
        if (existing == null) {
            subscriptionDao.insertSubscription(
                SubscriptionEntity(
                    channelName = channelName,
                    channelAvatarUrl = avatarUrl,
                    subscriberCount = subscriberCount,
                    isSubscribed = subscribed,
                    hasBellNotification = true,
                    channelDescription = description.ifBlank { "Official channel for $channelName on BhartTube." },
                    handle = handle.ifBlank { "@" + channelName.lowercase().replace(" ", "_") }
                )
            )
        } else {
            subscriptionDao.toggleSubscription(channelName, subscribed)
        }
        videoDao.updateChannelSubscriptionStatus(channelName, subscribed)
    }

    suspend fun updateBellNotification(channelName: String, hasBell: Boolean) = withContext(Dispatchers.IO) {
        subscriptionDao.updateBellNotification(channelName, hasBell)
    }

    suspend fun applyForMonetization() = withContext(Dispatchers.IO) {
        creatorStatsDao.applyForMonetization()
    }

    suspend fun approveMonetization() = withContext(Dispatchers.IO) {
        creatorStatsDao.approveMonetization()
    }

    suspend fun linkBankAccount(holder: String, acc: String, ifsc: String) = withContext(Dispatchers.IO) {
        creatorStatsDao.linkBankAccount(holder, acc, ifsc)
    }

    suspend fun linkBankAccountFull(
        holder: String,
        acc: String,
        ifsc: String,
        bankName: String,
        upiId: String
    ) = withContext(Dispatchers.IO) {
        creatorStatsDao.linkBankAccountFull(holder, acc, ifsc, bankName, upiId)
    }

    suspend fun deleteVideo(videoId: String) = withContext(Dispatchers.IO) {
        videoDao.deleteVideoById(videoId)
    }

    suspend fun addSuperChatEarnings(amount: Double) = withContext(Dispatchers.IO) {
        creatorStatsDao.addSuperChatEarnings(amount)
    }

    suspend fun autoScanAndPurgeProhibitedVideos(): Int = withContext(Dispatchers.IO) {
        val allVideos = videoDao.getAllVideosSync()
        var deletedCount = 0
        for (v in allVideos) {
            val scan = com.example.safety.BhartTubeSafetyShield.scanContent(v.title, v.description, v.category)
            if (scan.isViolation) {
                videoDao.deleteVideoById(v.id)
                deletedCount++
            }
        }
        deletedCount
    }

    // Helper functions for testing & user growth simulation
    suspend fun simulateTrafficGrowth(addSubs: Int, addHours: Double, addShortsViews: Long) = withContext(Dispatchers.IO) {
        if (addSubs > 0) creatorStatsDao.addSubscribers(addSubs)
        if (addHours > 0) creatorStatsDao.addWatchHours(addHours)
        if (addShortsViews > 0) creatorStatsDao.addShortsViews(addShortsViews)
    }

    suspend fun clearWatchHistory() = withContext(Dispatchers.IO) {
        watchHistoryDao.clearHistory()
    }

    suspend fun recordAdImpression(revenue: Double = 1.25) = withContext(Dispatchers.IO) {
        appOwnerStatsDao.recordAdImpression(revenue)
    }

    suspend fun activateMonthlySubscription(price: Double = 99.0): Boolean = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val expiry = now + (30L * 24 * 60 * 60 * 1000L) // 30 days
        appOwnerStatsDao.activateSubscription(activatedAt = now, expiresAt = expiry, price = price)
        true
    }

    suspend fun cancelPremiumSubscription() = withContext(Dispatchers.IO) {
        appOwnerStatsDao.cancelSubscription()
    }

    suspend fun setAppLanguage(langCode: String) = withContext(Dispatchers.IO) {
        appOwnerStatsDao.updateSelectedLanguage(langCode)
    }
}
