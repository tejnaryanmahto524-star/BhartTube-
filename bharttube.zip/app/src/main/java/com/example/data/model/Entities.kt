package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val channelName: String,
    val channelAvatarUrl: String,
    val subscriberCount: String = "1.2M subscribers",
    val thumbnailUrl: String,
    val videoGradientColors: String = "0xFFFF0055,0xFF003366", // fallback visual presentation for simulated player
    val durationText: String = "10:24",
    val durationSeconds: Int = 624,
    val views: Long = 124000,
    val likes: Long = 8500,
    val dislikes: Long = 120,
    val uploadDateText: String = "2 days ago",
    val category: String = "All",
    val isShort: Boolean = false,
    val isLiked: Boolean = false,
    val isDisliked: Boolean = false,
    val isSavedWatchLater: Boolean = false,
    val isDownloaded: Boolean = false,
    val isUserUpload: Boolean = false,
    val isSubscribed: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val videoId: String,
    val authorName: String,
    val authorAvatarUrl: String = "",
    val text: String,
    val timeAgo: String = "Just now",
    val likes: Int = 0,
    val isLiked: Boolean = false,
    val parentCommentId: Long? = null,
    val replyCount: Int = 0,
    val isHeartedByCreator: Boolean = false,
    val isPinned: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "creator_stats")
data class CreatorStatsEntity(
    @PrimaryKey val id: Int = 1,
    val channelName: String = "BhartTube Official Creator",
    val handle: String = "@bhart_creator_official",
    val subscribers: Int = 840,
    val targetSubscribers: Int = 1000,
    val watchHours: Double = 1120.0,
    val targetWatchHours: Double = 1500.0,
    val shortsViews: Long = 3450000L,
    val targetShortsViews: Long = 5000000L, // 5 Million shorts views
    val totalVideosUploaded: Int = 14,
    val isMonetized: Boolean = false,
    val hasApplied: Boolean = false,
    val estimatedRevenueInr: Double = 0.0, // Strictly 0.0 before monetization
    val adWatchPageRevenueInr: Double = 0.0,
    val shortsFeedRevenueInr: Double = 0.0,
    val superThanksInr: Double = 0.0,
    val channelMembershipsCount: Int = 0,
    val bankAccountLinked: Boolean = false,
    val bankAccountHolder: String = "Tinku Kumar",
    val bankAccountNumber: String = "",
    val ifscCode: String = "",
    val bankName: String = "State Bank of India",
    val upiId: String = ""
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val videoId: String,
    val watchedAt: Long = System.currentTimeMillis(),
    val watchDurationSeconds: Int = 30
)

@Entity(tableName = "subscriptions")
data class SubscriptionEntity(
    @PrimaryKey val channelName: String,
    val channelAvatarUrl: String = "",
    val subscriberCount: String = "1M subscribers",
    val isSubscribed: Boolean = true,
    val hasBellNotification: Boolean = true,
    val channelDescription: String = "Welcome to the official BhartTube channel! Watch high-quality videos, tutorials, and shorts.",
    val handle: String = "",
    val bannerGradient: String = "0xFFFF512F,0xFFDD2476",
    val totalVideos: Int = 48,
    val joinedDate: String = "Joined Jan 2023"
)

@Entity(tableName = "app_owner_stats")
data class AppOwnerStatsEntity(
    @PrimaryKey val id: Int = 1,
    val ownerName: String = "BhartTube Platform Owner",
    val totalRevenueInr: Double = 14250.00,
    val totalAdViews: Long = 8400L,
    val adRevenueInr: Double = 10500.00,
    val subscriptionRevenueInr: Double = 3750.00,
    val totalSubscribersCount: Int = 38,
    val isUserPremiumActive: Boolean = false,
    val premiumActivatedAt: Long = 0L,
    val premiumExpiresAt: Long = 0L,
    val selectedLanguage: String = "en",
    val ownerPin: String = "8400",
    val adMobPublisherId: String = "ca-app-pub-3940256099942544~3347511713",
    val adMobBannerAdUnitId: String = "ca-app-pub-3940256099942544/6300978111",
    val adMobVideoAdUnitId: String = "ca-app-pub-3940256099942544/5224354917",
    val preRollAdsEnabled: Boolean = true,
    val bannerAdsEnabled: Boolean = true
)
