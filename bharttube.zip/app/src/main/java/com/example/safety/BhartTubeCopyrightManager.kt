package com.example.safety

import com.example.data.model.VideoEntity

data class CopyrightCertificate(
    val contentId: String,
    val ownerName: String,
    val title: String,
    val licenseType: String = "BhartTube Standard Digital Rights & Creator License (BTL-2026)",
    val status: String = "100% Original & Verified (स्वतः कॉपीराइट सुरक्षित)",
    val protectionTier: String = "Automatic Content ID & Fair Use Shield",
    val digitalFingerprint: String
)

object BhartTubeCopyrightManager {

    fun generateContentId(videoId: String): String {
        val hash = (videoId.hashCode().toLong() and 0xFFFFFFFFL).toString(16).uppercase().padStart(8, '0')
        return "BT-CID-$hash"
    }

    fun getCopyrightNotice(channelName: String): String {
        return "© 2026 $channelName • BhartTube Content ID: Verified Copyright Protected (स्वचालित कॉपीराइट लाइसेंस)"
    }

    fun getCertificate(video: VideoEntity): CopyrightCertificate {
        return CopyrightCertificate(
            contentId = generateContentId(video.id),
            ownerName = video.channelName,
            title = video.title,
            digitalFingerprint = "SHA256:${(video.id + video.channelName).hashCode().toString(16).uppercase()}-BT-AUDIO-VISUAL"
        )
    }
}
