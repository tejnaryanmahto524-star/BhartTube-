package com.example.safety

import java.util.UUID

enum class ViolationCategory(
    val hindiTitle: String,
    val englishTitle: String,
    val descriptionHindi: String
) {
    ADULT_PORN_XXX(
        hindiTitle = "पोर्न / XXX / 18+ एडल्ट व गंदा वीडियो",
        englishTitle = "Adult / Pornographic / XXX Content",
        descriptionHindi = "पोर्न, xxx, नग्नता व कामुक वीडियो BhartTube पर सख्त वर्जित हैं। यह सामग्री ऑटोमैटिक डिलीट कर दी गई है।"
    ),
    EXTREME_VIOLENCE_BLOOD(
        hindiTitle = "खून-खराबा / अत्यधिक हिंसा व मारकाट",
        englishTitle = "Blood, Gore & Extreme Violence",
        descriptionHindi = "खून-खराबा, हत्या, यातना व भीषण हिंसा वाले वीडियो BhartTube पर सख्त वर्जित हैं। यह सामग्री ऑटोमैटिक डिलीट कर दी गई है।"
    ),
    GRAPHIC_ACCIDENT(
        hindiTitle = "भयानक एक्सीडेंट / दर्दनाक दुर्घटना व क्रैश",
        englishTitle = "Graphic Fatal Accidents & Horrific Crashes",
        descriptionHindi = "दर्दनाक एक्सीडेंट, कार/ट्रेन क्रैश व भीषण दुर्घटनाओं के विचलित करने वाले वीडियो BhartTube पर वर्जित हैं। यह सामग्री ऑटोमैटिक डिलीट कर दी गई है।"
    )
}

data class SafetyScanResult(
    val isViolation: Boolean,
    val category: ViolationCategory? = null,
    val matchedKeyword: String = "",
    val reasonHindi: String = "",
    val reasonEnglish: String = ""
)

data class DeletedVideoLog(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val category: ViolationCategory,
    val matchedWord: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionTaken: String = "ऑटोमैटिक डिलीट किया गया (Permanently Deleted)"
)

object BhartTubeSafetyShield {

    // 1. Adult, Porn, XXX, Nudity Keywords (Hindi, Hinglish & English)
    private val adultKeywords = listOf(
        "porn", "xxx", "pornography", "adult 18+", "18+ adult", "nsfw",
        "nude", "nudity", "naked", "sex video", "sexy hot", "erotic",
        "bhabhi sex", "chudai", "blue film", "mms leak", "onlyfans",
        "ganda video", "gandi video", "vulgar sex", "boobs", "vagina",
        "intercourse", "hardcore porn", "soft porn", "xxx video",
        "porn clip", "adult clip", "nude leak", "leaked sex", "stripper"
    )

    // 2. Extreme Violence, Blood, Khoon-Kharaba, Murder Keywords
    private val violenceKeywords = listOf(
        "blood", "gore", "khoon", "khoon kharaba", "khoon-kharaba",
        "murder", "brutal killing", "behead", "beheading", "throat cut",
        "mutilation", "slaughter", "dead body", "torture", "suicide",
        "killing video", "gala kaat", "massacre", "lynching", "brutal death",
        "execution video", "stabbing death", "blood gore", "jaanleva hamla",
        "khoonkhar", "qatil", "qatl", "maar peet blood"
    )

    // 3. Graphic Accidents, Horrific Crashes, Fatal Trauma Keywords
    private val accidentKeywords = listOf(
        "accident", "car crash", "bus accident", "train accident",
        "train crash", "deadly crash", "fatal collision", "horrific accident",
        "spot death accident", "crushed under truck", "crushed to death",
        "bike accident death", "highway accident blood", "dardnak hadsa",
        "bhayankar accident", "accident dead bodies", "fatal crash",
        "plane crash dead", "truck accident death", "road accident death"
    )

    /**
     * Scans title, description and category for prohibited content.
     * Returns a SafetyScanResult indicating whether it violated community policy.
     */
    fun scanContent(
        title: String,
        description: String = "",
        category: String = ""
    ): SafetyScanResult {
        val combinedText = "$title $description $category".lowercase().trim()

        // 1. Check Adult / Porn / XXX
        for (keyword in adultKeywords) {
            if (containsWord(combinedText, keyword)) {
                return SafetyScanResult(
                    isViolation = true,
                    category = ViolationCategory.ADULT_PORN_XXX,
                    matchedKeyword = keyword,
                    reasonHindi = "गंदा वीडियो (पोर्न / XXX / 18+ एडल्ट कंटेंट) पाए जाने के कारण यह वीडियो ऑटोमैटिक डिलीट कर दिया गया है।",
                    reasonEnglish = "Prohibited Adult/Pornographic/XXX content detected. Automatically deleted permanently."
                )
            }
        }

        // 2. Check Blood & Extreme Violence (खून-खराबा)
        for (keyword in violenceKeywords) {
            if (containsWord(combinedText, keyword)) {
                return SafetyScanResult(
                    isViolation = true,
                    category = ViolationCategory.EXTREME_VIOLENCE_BLOOD,
                    matchedKeyword = keyword,
                    reasonHindi = "खून-खराबा, हत्या व अत्यधिक हिंसा पाए जाने के कारण यह वीडियो ऑटोमैटिक डिलीट कर दिया गया है।",
                    reasonEnglish = "Prohibited Graphic Blood/Violence/Gore detected. Automatically deleted permanently."
                )
            }
        }

        // 3. Check Graphic Fatal Accidents & Crashes
        for (keyword in accidentKeywords) {
            if (containsWord(combinedText, keyword)) {
                return SafetyScanResult(
                    isViolation = true,
                    category = ViolationCategory.GRAPHIC_ACCIDENT,
                    matchedKeyword = keyword,
                    reasonHindi = "भयानक एक्सीडेंट, क्रैश व दर्दनाक दुर्घटना पाए जाने के कारण यह वीडियो ऑटोमैटिक डिलीट कर दिया गया है।",
                    reasonEnglish = "Prohibited Graphic Fatal Accident/Horrific Crash content detected. Automatically deleted permanently."
                )
            }
        }

        return SafetyScanResult(isViolation = false)
    }

    private fun containsWord(text: String, keyword: String): Boolean {
        // Direct substring check or word boundary
        if (text.contains(keyword)) {
            return true
        }
        // Normalize spaces and hyphens
        val normalized = text.replace("-", " ").replace("_", " ")
        return normalized.contains(keyword)
    }
}
