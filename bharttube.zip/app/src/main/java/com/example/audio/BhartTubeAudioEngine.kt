package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

object BhartTubeAudioEngine {
    private const val TAG = "BhartTubeAudioEngine"
    private const val SAMPLE_RATE = 44100

    private var audioTrack: AudioTrack? = null
    private var playbackJob: Job? = null
    private val audioScope = CoroutineScope(Dispatchers.Default)

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isAudioPlaying = MutableStateFlow(false)
    val isAudioPlaying: StateFlow<Boolean> = _isAudioPlaying.asStateFlow()

    private var currentCategory: String = "All"
    private var currentVideoSeed: Long = 0L

    @Synchronized
    private fun initAudioTrack(): AudioTrack? {
        if (audioTrack != null && audioTrack?.state == AudioTrack.STATE_INITIALIZED) {
            return audioTrack
        }
        return try {
            val minBufferSize = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(SAMPLE_RATE / 4)

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBufferSize * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            track.play()
            audioTrack = track
            track
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize AudioTrack", e)
            null
        }
    }

    /**
     * Plays the signature BhartTube opening fanfare chime
     * Warm cinematic Indian-inspired chime: D4 -> F#4 -> A4 -> D5 crescendo
     */
    fun playStartupChime() {
        audioScope.launch {
            try {
                val track = initAudioTrack() ?: return@launch
                val durationSec = 1.4
                val totalSamples = (SAMPLE_RATE * durationSec).toInt()
                val buffer = ShortArray(totalSamples)

                val notes = doubleArrayOf(293.66, 369.99, 440.0, 587.33, 880.0) // D4, F#4, A4, D5, A5
                val delays = doubleArrayOf(0.0, 0.12, 0.24, 0.36, 0.48)

                for (i in 0 until totalSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    var sampleVal = 0.0

                    for (n in notes.indices) {
                        val noteStart = delays[n]
                        if (t >= noteStart) {
                            val dt = t - noteStart
                            val envelope = exp(-3.2 * dt)
                            // Fundamental + rich harmonics (tanpura/chime sheen)
                            val osc = sin(2.0 * PI * notes[n] * dt) * 0.6 +
                                    sin(4.0 * PI * notes[n] * dt) * 0.25 +
                                    sin(6.0 * PI * notes[n] * dt) * 0.15
                            sampleVal += osc * envelope
                        }
                    }

                    // Master volume & smooth limiter
                    sampleVal *= 0.35
                    sampleVal = sampleVal.coerceIn(-0.95, 0.95)
                    buffer[i] = (sampleVal * 32767.0).toInt().toShort()
                }

                track.write(buffer, 0, buffer.size)
            } catch (e: Exception) {
                Log.e(TAG, "Error playing startup chime", e)
            }
        }
    }

    /**
     * Starts background soundtrack tailored to the video's genre
     */
    fun startVideoAudio(category: String, videoTitle: String, isShort: Boolean = false) {
        currentCategory = category
        currentVideoSeed = (videoTitle.hashCode() and 0x7FFFFFFF).toLong()

        playbackJob?.cancel()
        _isAudioPlaying.value = true

        playbackJob = audioScope.launch {
            try {
                val track = initAudioTrack() ?: return@launch
                val chunkSize = SAMPLE_RATE / 10 // 100ms chunks for responsive pause/stop
                val buffer = ShortArray(chunkSize)

                var globalSample = 0L

                // Scale notes based on genre
                val scale = getScaleForCategory(category, isShort)
                val tempoBpm = if (isShort) 128 else 96
                val secondsPerBeat = 60.0 / tempoBpm
                val samplesPerBeat = (SAMPLE_RATE * secondsPerBeat).toInt()

                while (isActive && _isAudioPlaying.value) {
                    if (_isMuted.value) {
                        buffer.fill(0)
                        track.write(buffer, 0, chunkSize)
                        globalSample += chunkSize
                        continue
                    }

                    for (i in 0 until chunkSize) {
                        val currentSampleIndex = globalSample + i
                        val t = currentSampleIndex.toDouble() / SAMPLE_RATE

                        val beatIndex = (currentSampleIndex / samplesPerBeat).toInt()
                        val sampleInBeat = (currentSampleIndex % samplesPerBeat).toDouble() / samplesPerBeat

                        // Melody note selection
                        val noteIndex = (beatIndex + (currentVideoSeed % 5)) % scale.size
                        val freq = scale[noteIndex.toInt()]

                        // Lead Instrument (Harmonic plucked tone with soft decay)
                        val leadEnvelope = (1.0 - sampleInBeat).coerceAtLeast(0.0)
                        val leadTone = sin(2.0 * PI * freq * t) * 0.5 +
                                sin(4.0 * PI * freq * t) * 0.25 +
                                sin(6.0 * PI * freq * t) * 0.1

                        // Soft Bass Drone / Pad
                        val bassFreq = scale[0] / 2.0
                        val bassTone = sin(2.0 * PI * bassFreq * t) * 0.35 +
                                sin(4.0 * PI * bassFreq * t) * 0.15

                        // Subtle rhythmic percussion beat
                        val isKick = (beatIndex % 2 == 0) && (sampleInBeat < 0.18)
                        val kickTone = if (isKick) {
                            val kickEnv = (1.0 - (sampleInBeat / 0.18))
                            sin(2.0 * PI * 65.0 * sampleInBeat) * kickEnv * 0.4
                        } else 0.0

                        val isHiHat = (sampleInBeat > 0.45 && sampleInBeat < 0.55)
                        val hatTone = if (isHiHat) {
                            (Math.random() * 2.0 - 1.0) * 0.08
                        } else 0.0

                        var mixed = (leadTone * leadEnvelope * 0.3) + (bassTone * 0.25) + kickTone + hatTone
                        mixed *= 0.75 // Overall comfortable level
                        mixed = mixed.coerceIn(-0.95, 0.95)

                        buffer[i] = (mixed * 32767.0).toInt().toShort()
                    }

                    track.write(buffer, 0, chunkSize)
                    globalSample += chunkSize
                }
            } catch (e: Exception) {
                Log.e(TAG, "Audio synthesis error", e)
            }
        }
    }

    private fun getScaleForCategory(category: String, isShort: Boolean): DoubleArray {
        if (isShort) {
            // Energetic dance / pop scale (C major pentatonic upbeat)
            return doubleArrayOf(261.63, 293.66, 329.63, 392.00, 440.00, 523.25)
        }
        return when (category.lowercase()) {
            "tech", "science & tech", "science" ->
                // Futuristic Synthwave scale (A minor pentatonic)
                doubleArrayOf(220.00, 261.63, 293.66, 329.63, 392.00, 440.00)

            "food", "food & cooking", "desi food" ->
                // Traditional joyful Indian folk scale (Kafi / Bilawal)
                doubleArrayOf(261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88)

            "music", "sangeet" ->
                // Classical Indian raga harmonic notes (Yaman / Bhairavi flavor)
                doubleArrayOf(246.94, 277.18, 311.13, 369.99, 415.30, 493.88)

            "comedy", "entertainment" ->
                // Bouncy playful groove scale
                doubleArrayOf(261.63, 311.13, 349.23, 392.00, 466.16, 523.25)

            "cricket", "sports" ->
                // High energy driving sports anthem scale
                doubleArrayOf(196.00, 220.00, 261.63, 293.66, 329.63, 392.00)

            "travel", "wanderlust" ->
                // Peaceful serene acoustic scale (E major pentatonic)
                doubleArrayOf(164.81, 220.00, 246.94, 329.63, 369.99, 440.00)

            else ->
                // Warm ambient default
                doubleArrayOf(220.00, 261.63, 293.66, 329.63, 392.00, 440.00)
        }
    }

    fun pauseAudio() {
        _isAudioPlaying.value = false
        playbackJob?.cancel()
    }

    fun resumeAudio() {
        if (!_isAudioPlaying.value && currentCategory.isNotEmpty()) {
            startVideoAudio(currentCategory, "Video$currentVideoSeed")
        }
    }

    fun stopAudio() {
        _isAudioPlaying.value = false
        playbackJob?.cancel()
    }

    fun toggleMute(): Boolean {
        _isMuted.value = !_isMuted.value
        return _isMuted.value
    }

    fun setMuted(muted: Boolean) {
        _isMuted.value = muted
    }
}
