package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BhartTubeRed

@Composable
fun BhartTubeTopBar(
    onSearchClick: () -> Unit,
    onNotificationsClick: () -> Unit,
    onProfileClick: () -> Unit,
    onShareClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // YouTube-like Logo with BhartTube branding
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clickable { /* Reset to top */ }
                .testTag("app_logo_row")
        ) {
            // YouTube Red Play Button badge
            Box(
                modifier = Modifier
                    .size(width = 34.dp, height = 24.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(BhartTubeRed),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Logo Text "Bhart" + "Tube"
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Bhart",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Tube",
                    color = BhartTubeRed,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = (-0.5).sp
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Right Action Icons (YouTube style: Cast, Notification, Search, Avatar)
        IconButton(
            onClick = { /* Cast to TV / Screen */ },
            modifier = Modifier.testTag("cast_button")
        ) {
            Icon(
                imageVector = Icons.Default.Cast,
                contentDescription = "Cast",
                tint = MaterialTheme.colorScheme.onBackground
            )
        }

        IconButton(
            onClick = onNotificationsClick,
            modifier = Modifier.testTag("notifications_button")
        ) {
            BadgedBox(
                badge = {
                    Badge(
                        containerColor = BhartTubeRed,
                        modifier = Modifier.size(8.dp)
                    )
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Notifications",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }
        }

        IconButton(
            onClick = onSearchClick,
            modifier = Modifier.testTag("search_button")
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = MaterialTheme.colorScheme.onBackground
            )
        }

        IconButton(
            onClick = onShareClick,
            modifier = Modifier.testTag("share_app_top_button")
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "Share BhartTube / शेयर करें",
                tint = MaterialTheme.colorScheme.onBackground
            )
        }

        // User Avatar
        Box(
            modifier = Modifier
                .padding(start = 4.dp)
                .size(32.dp)
                .clip(CircleShape)
                .background(BhartTubeRed)
                .clickable { onProfileClick() }
                .testTag("profile_avatar_top"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "B",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
