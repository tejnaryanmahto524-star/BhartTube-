package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.parseGradients
import com.example.ui.theme.BhartTubeRed
import com.example.ui.viewmodel.BhartTubeViewModel
import com.example.ui.viewmodel.ScreenDestination

data class GradientPreset(
    val name: String,
    val value: String
)

val ThumbnailPresets = listOf(
    GradientPreset("Sunset Glow", "0xFFFF512F,0xFFDD2476"),
    GradientPreset("Ocean Deep", "0xFF0052D4,0xFF4364F7"),
    GradientPreset("Neon Cyber", "0xFF8E2DE2,0xFF4A00E0"),
    GradientPreset("Emerald Tech", "0xFF00B09B,0xFF96C93D"),
    GradientPreset("Desi Saffron", "0xFFFF9933,0xFFD32F2F")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadVideoScreen(
    viewModel: BhartTubeViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isShort by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tech") }
    var selectedGradient by remember { mutableStateOf(ThumbnailPresets[0].value) }
    var durationMinutes by remember { mutableIntStateOf(8) }
    var durationSecondsShort by remember { mutableIntStateOf(30) }
    var isMonetizationEnabled by remember { mutableStateOf(true) }
    var isAutoCopyrightEnabled by remember { mutableStateOf(true) }
    var visibility by remember { mutableStateOf("Public") }

    val isUploading by viewModel.isUploading.collectAsStateWithLifecycle()
    val uploadProgress by viewModel.uploadProgress.collectAsStateWithLifecycle()
    val safetyAlert by viewModel.safetyViolationAlert.collectAsStateWithLifecycle()

    val currentSafetyCheck = remember(title, description, selectedCategory) {
        com.example.safety.BhartTubeSafetyShield.scanContent(title, description, selectedCategory)
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = if (isShort) "Create Short" else "Upload Video",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
                titleContentColor = MaterialTheme.colorScheme.onBackground
            )
        )

        if (isUploading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(
                        color = BhartTubeRed,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "Uploading to BhartTube...",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${(uploadProgress * 100).toInt()}% completed",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    LinearProgressIndicator(
                        progress = { uploadProgress },
                        color = BhartTubeRed,
                        modifier = Modifier
                            .fillMaxWidth(0.8f)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )
                }
            }
            return
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Mode Selector: Video vs Short
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (!isShort) BhartTubeRed else Color.Transparent)
                        .clickable { isShort = false }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Upload Video",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isShort) BhartTubeRed else Color.Transparent)
                        .clickable { isShort = true }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Create Short",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Live Thumbnail / Preview Card
            Text(
                text = "Preview & Thumbnail Style",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(if (isShort) 9f / 10f else 16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(parseGradients(selectedGradient)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Icon(
                        imageVector = if (isShort) Icons.Default.Videocam else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = title.ifBlank { "Video Title Preview" },
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 2
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isShort) "${durationSecondsShort}s • $selectedCategory" else "${durationMinutes}:00 • $selectedCategory",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Thumbnail Gradient Presets
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(ThumbnailPresets) { preset ->
                    val isSelected = selectedGradient == preset.value
                    Box(
                        modifier = Modifier
                            .size(width = 90.dp, height = 44.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(parseGradients(preset.value))
                            .border(
                                width = if (isSelected) 2.5.dp else 0.dp,
                                color = if (isSelected) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedGradient = preset.value }
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = preset.name,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Title Field
            OutlinedTextField(
                value = title,
                onValueChange = { if (it.length <= 100) title = it },
                label = { Text("Title (required)") },
                placeholder = { Text("e.g. My Amazing Vlog on BhartTube") },
                supportingText = { Text("${title.length}/100") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("upload_title_input"),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BhartTubeRed,
                    focusedLabelColor = BhartTubeRed
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Description Field
            OutlinedTextField(
                value = description,
                onValueChange = { if (it.length <= 500) description = it },
                label = { Text("Description") },
                placeholder = { Text("Tell viewers about your video...") },
                supportingText = { Text("${description.length}/500") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("upload_description_input"),
                minLines = 3,
                maxLines = 5,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BhartTubeRed,
                    focusedLabelColor = BhartTubeRed
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Real-Time BhartTube AI Content Safety Guard Banner
            if (currentSafetyCheck.isViolation) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = BhartTubeRed.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, BhartTubeRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = BhartTubeRed,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "🚨 गंदा / आपत्तिजनक वीडियो डिटेक्टेड!",
                                fontWeight = FontWeight.Bold,
                                color = BhartTubeRed,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "कारण: ${currentSafetyCheck.category?.hindiTitle} (पहचाना गया शब्द: '${currentSafetyCheck.matchedKeyword}')। BhartTube सुरक्षा नीति के तहत यह वीडियो अपलोड होते ही ऑटोमैटिक डिलीट कर दिया जाएगा।",
                                color = MaterialTheme.colorScheme.onBackground,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = com.example.ui.theme.YouTubeGreen.copy(alpha = 0.1f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = com.example.ui.theme.YouTubeGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "🛡️ BhartTube AI Safety Shield: सुरक्षित सामग्री (Clean Content)",
                            color = com.example.ui.theme.YouTubeGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Category Picker
            Text(
                text = "Category",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Tech", "Cooking", "Education", "Vlogs", "Comedy", "Music", "Gaming")) { cat ->
                    val isCatSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isCatSelected) BhartTubeRed else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = cat,
                            color = if (isCatSelected) Color.White else MaterialTheme.colorScheme.onBackground,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Video Duration Selector
            Text(
                text = if (isShort) "Short Duration" else "Video Duration",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isShort) {
                    listOf(15, 30, 60).forEach { sec ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (durationSecondsShort == sec) BhartTubeRed else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { durationSecondsShort = sec }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "${sec}s",
                                color = if (durationSecondsShort == sec) Color.White else MaterialTheme.colorScheme.onBackground,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    listOf(5, 10, 15, 25).forEach { mins ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (durationMinutes == mins) BhartTubeRed else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { durationMinutes = mins }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "${mins} mins",
                                color = if (durationMinutes == mins) Color.White else MaterialTheme.colorScheme.onBackground,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Monetization Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.MonetizationOn,
                    contentDescription = null,
                    tint = BhartTubeRed,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Monetize This Video",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Earn money from Watch Page ads & Shorts Feed ads",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = isMonetizationEnabled,
                    onCheckedChange = { isMonetizationEnabled = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = BhartTubeRed
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Visibility Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Public,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Visibility",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Anyone can search for and view ($visibility)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Automatic Copyright Protection Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(
                        width = 1.dp,
                        color = if (isAutoCopyrightEnabled) BhartTubeRed.copy(alpha = 0.5f) else Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Automatic Copyright",
                        tint = BhartTubeRed,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Automatic Copyright Protection (स्वतः कॉपीराइट सुरक्षा)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "BhartTube Content ID द्वारा डिजिटल कॉपीराइट सुरक्षित",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isAutoCopyrightEnabled,
                        onCheckedChange = { isAutoCopyrightEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = BhartTubeRed
                        )
                    )
                }

                if (isAutoCopyrightEnabled) {
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                        thickness = 0.5.dp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = com.example.ui.theme.YouTubeGreen,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Content ID Scan: 100% Original Content (मूल सामग्री)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = com.example.ui.theme.YouTubeGreen
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = com.example.ui.theme.YouTubeGreen,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "कॉपीराइट स्ट्राइक जांच: 0 दावे • पूर्ण स्वामित्व सुरक्षित",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = BhartTubeRed,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "लाइसेंस: BhartTube Standard Creator Rights (All Rights Reserved)",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Publish Button
            Button(
                onClick = {
                    val finalTitle = title.ifBlank { if (isShort) "Trending Short on BhartTube #Shorts" else "Awesome Video on BhartTube" }
                    val finalDesc = description.ifBlank { "Uploaded with BhartTube Video Studio." }
                    val finalDuration = if (isShort) durationSecondsShort else durationMinutes * 60

                    viewModel.uploadVideo(
                        title = finalTitle,
                        description = finalDesc,
                        category = selectedCategory,
                        isShort = isShort,
                        durationSeconds = finalDuration,
                        thumbnailGradient = selectedGradient
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("publish_video_button"),
                colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isShort) "Publish Short" else "Upload & Publish Video",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(40.dp))
        }

        // Prohibited Content Auto-Delete Interception Dialog
        safetyAlert?.let { alert ->
            AlertDialog(
                onDismissRequest = { viewModel.dismissSafetyViolationAlert() },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = BhartTubeRed,
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        text = "वीडियो स्वतः डिलीट कर दिया गया! 🚨",
                        fontWeight = FontWeight.Bold,
                        color = BhartTubeRed,
                        fontSize = 16.sp
                    )
                },
                text = {
                    Column {
                        Text(
                            text = "BhartTube AI Content Moderation Shield",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "आपकी सामग्री में '${alert.matchedKeyword}' पाया गया, जो कि BhartTube सुरक्षा नीति के अंतर्गत '${alert.category?.hindiTitle}' की श्रेणी में आता है।",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "नियम: गंदा वीडियो (पोर्न xxx), खून-खराबा या भयानक एक्सीडेंट वाले वीडियो स्वचालित रूप से सिस्टम द्वारा निरस्त और तुरंत डिलीट कर दिए जाते हैं।",
                            fontSize = 11.sp,
                            color = BhartTubeRed
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.dismissSafetyViolationAlert() },
                        colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed)
                    ) {
                        Text("समझ गया (Understood)")
                    }
                }
            )
        }
    }
}
