package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.safety.BhartTubeSafetyShield
import com.example.safety.ViolationCategory
import com.example.ui.theme.BhartTubeRed
import com.example.ui.theme.YouTubeBlue
import com.example.ui.theme.YouTubeGreen
import com.example.ui.viewmodel.BhartTubeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafetyCenterScreen(
    viewModel: BhartTubeViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val deletedLogs by viewModel.deletedViolationLogs.collectAsStateWithLifecycle()
    var testTitleInput by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "BhartTube AI Safety Guard (सुरक्षा शील्ड)",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
                titleContentColor = MaterialTheme.colorScheme.onBackground
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Active Shield Status Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = YouTubeGreen.copy(alpha = 0.12f)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, YouTubeGreen),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(YouTubeGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AI Content Safety Filter: 24/7 ACTIVE",
                                color = YouTubeGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Text(
                            text = "पोर्न, xxx, खून-खराबा व एक्सीडेंट वाले वीडियो ऑटोमैटिक डिलीट कर दिए जाते हैं।",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "प्रतिबंधित श्रेणियां (Strict Prohibited Policies)",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 3 Prohibited Categories
            SafetyPolicyCard(
                icon = Icons.Default.Block,
                title = "1. पोर्न, XXX व 18+ गंदा वीडियो (Pornography & NSFW)",
                description = "पोर्न, xxx, नग्नता व अश्लील सामग्री का तुरंत पता लगाकर सिस्टम से ऑटोमैटिक स्थायी रूप से डिलीट कर दिया जाता है।",
                accentColor = BhartTubeRed
            )

            Spacer(modifier = Modifier.height(8.dp))

            SafetyPolicyCard(
                icon = Icons.Default.Warning,
                title = "2. खून-खराबा व अत्यधिक हिंसा (Blood, Murder & Gore)",
                description = "खून-खराबा, किसी की हत्या, यातना, गला काटना या हिंसक मारकाट की क्लिप्स ऑटोमैटिक पकड़ी जाकर डिलीट हो जाती हैं।",
                accentColor = Color(0xFFD32F2F)
            )

            Spacer(modifier = Modifier.height(8.dp))

            SafetyPolicyCard(
                icon = Icons.Default.ReportProblem,
                title = "3. दर्दनाक एक्सीडेंट व दुर्घटना (Graphic Crashes)",
                description = "घातक रोड एक्सीडेंट, लाशें, भीषण ट्रेन/कार क्रैश के विचलित करने वाले वीडियो सिस्टम द्वारा स्वतः ब्लॉक व डिलीट होते हैं।",
                accentColor = Color(0xFFE65100)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Test Safety Filter Section
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = BhartTubeRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Test Automatic Deletion (लाइव टेस्ट करें)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    Text(
                        text = "किसी भी प्रतिबंधित शब्द का उपयोग करके टेस्ट करें कि कैसे यह सिस्टम तुरंत वीडियो को ऑटोमैटिक डिलीट करता है:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )

                    OutlinedTextField(
                        value = testTitleInput,
                        onValueChange = { testTitleInput = it },
                        placeholder = { Text("उदा. Bhabhi sex mms xxx या highway accident dead body", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { testTitleInput = "Desi Bhabhi Sex MMS xxx leaked" },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Test Porn XXX", fontSize = 10.sp)
                        }

                        OutlinedButton(
                            onClick = { testTitleInput = "Brutal murder blood gore khoon kharaba" },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Test Khoon", fontSize = 10.sp)
                        }

                        OutlinedButton(
                            onClick = { testTitleInput = "Fatal bus accident spot death crash" },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Test Crash", fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (testTitleInput.isNotBlank()) {
                                viewModel.testSafetyAutoDelete(testTitleInput)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_safety_scan_btn")
                    ) {
                        Icon(Icons.Default.DeleteForever, null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Scan & Auto-Delete Test Video")
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Real-time Deleted Videos History
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "स्वतः डिलीट किए गए वीडियो (Auto-Deleted Logs)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${deletedLogs.size} पकड़े गए",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (deletedLogs.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.CheckCircle, null, tint = YouTubeGreen, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("BhartTube पूरी तरह सुरक्षित है!", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            text = "कोई भी गंदा वीडियो, खून-खराबा या एक्सीडेंट वीडियो अपलोड करने की कोशिश करते ही तुरंत ऑटोमैटिक डिलीट हो जाएगा।",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    deletedLogs.forEach { log ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = BhartTubeRed.copy(alpha = 0.1f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BhartTubeRed.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.DeleteForever, null, tint = BhartTubeRed, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = log.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    Text(
                                        text = "उल्लंघन: ${log.category.hindiTitle} (शब्द: '${log.matchedWord}')",
                                        fontSize = 11.sp,
                                        color = BhartTubeRed
                                    )
                                    Text(
                                        text = "स्थिति: ${log.actionTaken}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun SafetyPolicyCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    accentColor: Color
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier
                    .size(24.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }
        }
    }
}
