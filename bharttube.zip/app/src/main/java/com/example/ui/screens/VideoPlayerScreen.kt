package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.CommentEntity
import com.example.data.model.VideoEntity
import com.example.ui.components.VideoCard
import com.example.ui.components.formatViewsCount
import com.example.ui.components.parseGradients
import com.example.ui.theme.BhartTubeRed
import com.example.ui.theme.YouTubeBlue
import com.example.ui.theme.YouTubeGreen
import com.example.ui.viewmodel.BhartTubeViewModel

fun formatSecondsToTime(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format("%02d:%02d", m, s)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoPlayerScreen(
    video: VideoEntity,
    viewModel: BhartTubeViewModel,
    onClose: () -> Unit,
    onShare: (VideoEntity) -> Unit,
    onChannelClick: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val isAudioMuted by viewModel.isAudioMuted.collectAsStateWithLifecycle()
    val currentSeconds by viewModel.currentPlaybackSeconds.collectAsStateWithLifecycle()
    val playbackSpeed by viewModel.playbackSpeed.collectAsStateWithLifecycle()
    val playbackQuality by viewModel.playbackQuality.collectAsStateWithLifecycle()
    val comments by viewModel.commentsForActiveVideo.collectAsStateWithLifecycle()
    val recommendedVideos by viewModel.videos.collectAsStateWithLifecycle()

    val isAdPlaying by viewModel.isAdPlaying.collectAsStateWithLifecycle()
    val adCountdownSeconds by viewModel.adCountdownSeconds.collectAsStateWithLifecycle()
    val canSkipAd by viewModel.canSkipAd.collectAsStateWithLifecycle()
    val activeAdCreative by viewModel.activeAdCreative.collectAsStateWithLifecycle()
    val isUserPremium by viewModel.isUserPremium.collectAsStateWithLifecycle()
    val showPremiumDialog by viewModel.showPremiumDialog.collectAsStateWithLifecycle()

    val commentsSortByTop by viewModel.commentsSortByTop.collectAsStateWithLifecycle()

    var isDescriptionExpanded by remember { mutableStateOf(false) }
    var showCommentsSheet by remember { mutableStateOf(false) }
    var isSubscribed by remember { mutableStateOf(video.isSubscribed) }
    var showSpeedMenu by remember { mutableStateOf(false) }
    var showQualityMenu by remember { mutableStateOf(false) }
    var newCommentText by remember { mutableStateOf("") }
    var showSuperChatDialog by remember { mutableStateOf(false) }
    var showSuperChatLockedDialog by remember { mutableStateOf(false) }
    var showCopyrightDialog by remember { mutableStateOf(false) }
    val creatorStats by viewModel.creatorStats.collectAsStateWithLifecycle()

    var selectedViewTab by remember { mutableStateOf(0) } // 0 = Discussion & Comments, 1 = Up Next Videos
    var replyingToCommentId by remember { mutableStateOf<Long?>(null) }
    var replyText by remember { mutableStateOf("") }
    var expandedRepliesSet by remember { mutableStateOf(setOf<Long>()) }
    val quickEmojis = remember { listOf("🔥", "👏", "❤️", "🇮🇳", "🙌", "😂", "👌", "💯", "🚀", "👍") }
    var commentValidationError by remember { mutableStateOf<String?>(null) }

    val otherVideos = remember(recommendedVideos, video.id) {
        recommendedVideos.filter { it.id != video.id }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Player Video View Port
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .background(Color.Black)
        ) {
            // Video Thumbnail / Screen
            if (video.thumbnailUrl.isNotBlank()) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(parseGradients(video.videoGradientColors)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Playing: ${video.title.take(30)}...",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 14.sp
                    )
                }
            }

            // Dark Scrim over player for controls
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
            )

            // Top Bar of Player (Close, Quality, Speed)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .align(Alignment.TopCenter),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.testTag("player_close_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close player",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Audio Mute/Unmute toggle
                IconButton(
                    onClick = { viewModel.toggleAudioMute() },
                    modifier = Modifier.testTag("player_mute_btn")
                ) {
                    Icon(
                        imageVector = if (isAudioMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = if (isAudioMuted) "Unmute Audio" else "Mute Audio",
                        tint = if (isAudioMuted) Color(0xFFFF5252) else Color.White
                    )
                }

                // Speed Selector
                Box {
                    IconButton(onClick = { showSpeedMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = "Playback speed",
                            tint = Color.White
                        )
                    }
                    DropdownMenu(
                        expanded = showSpeedMenu,
                        onDismissRequest = { showSpeedMenu = false }
                    ) {
                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                            DropdownMenuItem(
                                text = { Text("${speed}x") },
                                onClick = {
                                    viewModel.setPlaybackSpeed(speed)
                                    showSpeedMenu = false
                                }
                            )
                        }
                    }
                }

                // Quality Selector
                Box {
                    Text(
                        text = playbackQuality,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { showQualityMenu = true }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                    DropdownMenu(
                        expanded = showQualityMenu,
                        onDismissRequest = { showQualityMenu = false }
                    ) {
                        listOf("1080p Full HD", "720p HD", "480p", "360p", "144p").forEach { quality ->
                            DropdownMenuItem(
                                text = { Text(quality) },
                                onClick = {
                                    viewModel.setPlaybackQuality(quality.split(" ")[0])
                                    showQualityMenu = false
                                }
                            )
                        }
                    }
                }
            }

            // Center Player Controls (Rewind 10s, Play/Pause, Forward 10s)
            Row(
                modifier = Modifier.align(Alignment.Center),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                IconButton(
                    onClick = { viewModel.seekTo(currentSeconds - 10) },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Replay10,
                        contentDescription = "Rewind 10s",
                        tint = Color.White,
                        modifier = Modifier.size(34.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                        .clickable { viewModel.togglePlayPause() }
                        .testTag("player_play_pause_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                IconButton(
                    onClick = { viewModel.seekTo(currentSeconds + 10) },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Forward10,
                        contentDescription = "Forward 10s",
                        tint = Color.White,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }

            // Bottom Scrubber Bar & Time
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 12.dp, vertical = 2.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${formatSecondsToTime(currentSeconds)} / ${video.durationText}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Icon(
                        imageVector = Icons.Default.Fullscreen,
                        contentDescription = "Fullscreen",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Slider(
                    value = currentSeconds.toFloat(),
                    onValueChange = { viewModel.seekTo(it.toInt()) },
                    valueRange = 0f..video.durationSeconds.toFloat().coerceAtLeast(1f),
                    colors = SliderDefaults.colors(
                        thumbColor = BhartTubeRed,
                        activeTrackColor = BhartTubeRed,
                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                )
            }

            // Pre-Roll Ad Player Viewport (Runs before video playback for free users)
            if (isAdPlaying) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF101010))
                ) {
                    // Ad Sponsor vibrant visual background
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(parseGradients(activeAdCreative.bannerGradient))
                    )

                    // Scrim gradient
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                androidx.compose.ui.graphics.Brush.verticalGradient(
                                    listOf(Color.Black.copy(alpha = 0.75f), Color.Transparent, Color.Black.copy(alpha = 0.9f))
                                )
                            )
                    )

                    // Top Bar of Ad: Status pill + Category + Close
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .align(Alignment.TopCenter),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFFFD700))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ad 1 of 1",
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = "Sponsored • ${activeAdCreative.category}",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.weight(1f))

                        IconButton(
                            onClick = onClose,
                            modifier = Modifier.size(32.dp).testTag("ad_close_player_btn")
                        ) {
                            Icon(Icons.Default.Close, "Close", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }

                    // Center Content: Sponsor info + App Owner Earning Pill
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(horizontal = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stars,
                                contentDescription = null,
                                tint = BhartTubeRed,
                                modifier = Modifier.size(30.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = activeAdCreative.sponsor,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = activeAdCreative.tagline,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            maxLines = 2
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // App Owner Earning Pill
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF2E7D32).copy(alpha = 0.92f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CurrencyRupee, null, tint = Color.White, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "App Owner Revenue: +₹1.25",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Bottom Row: Ad-Free ₹99 Button + Skip Ad Countdown
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .align(Alignment.BottomCenter),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Subscribe for ₹99 Button
                        Surface(
                            onClick = { viewModel.openPremiumDialog() },
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF1E1E1E).copy(alpha = 0.95f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFD700)),
                            modifier = Modifier.testTag("ad_open_premium_btn")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Stars, null, tint = Color(0xFFFFD700), modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("No Ads: ₹99/mo 👑", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Skip Ad Button / Countdown
                        if (canSkipAd || adCountdownSeconds <= 0) {
                            Button(
                                onClick = { viewModel.skipAd() },
                                colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(36.dp).testTag("skip_ad_button")
                            ) {
                                Text("Skip Ad ⏩", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.8f))
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = "Skip in ${adCountdownSeconds}s",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            } else if (isUserPremium) {
                // Sleek golden badge showing Ad-free playback for premium members
                Box(
                    modifier = Modifier
                        .padding(top = 10.dp, start = 48.dp)
                        .align(Alignment.TopStart)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFFFD700))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Stars, null, tint = Color.Black, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("BhartTube Premium • Ad-Free", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }

        // Scrollable Video Details & Recommendations
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            item {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Video Title
                    Text(
                        text = video.title,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Views & Upload Date & Description Expander
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isDescriptionExpanded = !isDescriptionExpanded }
                    ) {
                        Text(
                            text = "${formatViewsCount(video.views)} • ${video.uploadDateText}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isDescriptionExpanded) "Show less" else "...more",
                            color = MaterialTheme.colorScheme.onBackground,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (isDescriptionExpanded) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = video.description,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Channel Row with Subscribe & Join
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onChannelClick(video.channelName) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (video.channelAvatarUrl.isNotBlank()) {
                                AsyncImage(
                                    model = video.channelAvatarUrl,
                                    contentDescription = video.channelName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(BhartTubeRed),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = video.channelName.take(1).uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = video.channelName,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = video.subscriberCount,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        // Join Button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { /* Join Channel */ }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "Join",
                                color = YouTubeBlue,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Subscribe Button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (isSubscribed) MaterialTheme.colorScheme.surfaceVariant else Color.White)
                                .clickable {
                                    val newStatus = !isSubscribed
                                    isSubscribed = newStatus
                                    viewModel.toggleSubscription(
                                        channelName = video.channelName,
                                        currentSubscribed = !newStatus,
                                        avatarUrl = video.channelAvatarUrl,
                                        subscriberCount = video.subscriberCount
                                    )
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                .testTag("player_subscribe_btn")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (isSubscribed) {
                                    Icon(
                                        imageVector = Icons.Default.NotificationsActive,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onBackground,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                Text(
                                    text = if (isSubscribed) "Subscribed" else "Subscribe",
                                    color = if (isSubscribed) MaterialTheme.colorScheme.onBackground else Color.Black,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // YouTube Action Pills (Like/Dislike, Share, Super Chat, Download, Save)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Like / Dislike Combined Pill
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.height(36.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clickable { viewModel.toggleLikeActiveVideo() }
                                        .padding(horizontal = 4.dp)
                                        .testTag("player_like_btn")
                                    ) {
                                    Icon(
                                        imageVector = if (video.isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                                        contentDescription = "Like",
                                        tint = if (video.isLiked) BhartTubeRed else MaterialTheme.colorScheme.onBackground,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = formatViewsCount(video.likes),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }

                                VerticalDivider(
                                    modifier = Modifier
                                        .height(18.dp)
                                        .padding(horizontal = 6.dp),
                                    color = MaterialTheme.colorScheme.outline
                                )

                                IconButton(
                                    onClick = { viewModel.dislikeActiveVideo() },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = if (video.isDisliked) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
                                        contentDescription = "Dislike",
                                        tint = MaterialTheme.colorScheme.onBackground,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        // Share Pill
                        ActionPill(
                            icon = Icons.Default.Share,
                            label = "Share / शेयर",
                            onClick = { onShare(video) }
                        )

                        // Super Chat & Thanks Pill (Requires 500 Subscribers)
                        ActionPill(
                            icon = Icons.Default.CurrencyRupee,
                            label = "Super Chat",
                            tint = YouTubeGreen,
                            onClick = {
                                val subs = creatorStats?.subscribers ?: 860
                                if (subs >= 500) {
                                    showSuperChatDialog = true
                                } else {
                                    showSuperChatLockedDialog = true
                                }
                            }
                        )

                        // Download Pill
                        ActionPill(
                            icon = if (video.isDownloaded) Icons.Default.DownloadDone else Icons.Default.Download,
                            label = if (video.isDownloaded) "Downloaded" else "Download",
                            tint = if (video.isDownloaded) BhartTubeRed else MaterialTheme.colorScheme.onBackground,
                            onClick = { viewModel.toggleDownload(video) }
                        )

                        // Save Pill
                        ActionPill(
                            icon = if (video.isSavedWatchLater) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            label = "Save",
                            tint = if (video.isSavedWatchLater) BhartTubeRed else MaterialTheme.colorScheme.onBackground,
                            onClick = { viewModel.toggleSaveWatchLater(video) }
                        )

                        // Ad-Free Subscription Pill (₹99 / 1 Month)
                        ActionPill(
                            icon = Icons.Default.Stars,
                            label = if (isUserPremium) "👑 Premium" else "Ad-Free ₹99",
                            tint = if (isUserPremium) Color(0xFFFFD700) else BhartTubeRed,
                            onClick = { viewModel.openPremiumDialog() }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Automatic Copyright & Content ID Badge (Auto Copyright)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showCopyrightDialog = true }
                            .testTag("automatic_copyright_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Automatic Copyright",
                                tint = BhartTubeRed,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "© BhartTube Content ID: Verified Copyright Protected • ${video.channelName}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "जांचें (Verify) 📜",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = YouTubeBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Discussion & Up Next Segment Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Comments Pill
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (selectedViewTab == 0) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .clickable { selectedViewTab = 0 }
                                .testTag("tab_comments")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChatBubbleOutline,
                                    contentDescription = null,
                                    tint = if (selectedViewTab == 0) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Comments (${comments.size})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedViewTab == 0) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }

                        // Up Next Pill
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (selectedViewTab == 1) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .clickable { selectedViewTab = 1 }
                                .testTag("tab_up_next")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Up Next (${otherVideos.size})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedViewTab == 1) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }

                    // Comments Header & Inline Composer when Comments tab is active
                    if (selectedViewTab == 0) {
                        Spacer(modifier = Modifier.height(10.dp))

                        // Comments Header Row with Sort Toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Comments",
                                color = MaterialTheme.colorScheme.onBackground,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${comments.size}",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.weight(1f))

                            // Sort Button
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { viewModel.toggleCommentSort() }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                    .testTag("comment_sort_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sort,
                                    contentDescription = "Sort comments",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (commentsSortByTop) "Top comments" else "Newest first",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Inline Comment Input Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .padding(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(YouTubeBlue),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "YOU",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                OutlinedTextField(
                                    value = newCommentText,
                                    onValueChange = {
                                        newCommentText = it
                                        commentValidationError = null
                                    },
                                    placeholder = { Text("Add a comment on BhartTube...", fontSize = 12.sp) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("comment_input_field"),
                                    shape = RoundedCornerShape(16.dp),
                                    singleLine = false,
                                    maxLines = 3
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                // Quick reaction emojis
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    quickEmojis.forEach { emoji ->
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(MaterialTheme.colorScheme.surface)
                                                .clickable { newCommentText = (newCommentText + emoji).trim() }
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(text = emoji, fontSize = 14.sp)
                                        }
                                    }
                                }

                                if (commentValidationError != null) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = commentValidationError ?: "",
                                        color = BhartTubeRed,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                if (newCommentText.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            onClick = {
                                                newCommentText = ""
                                                commentValidationError = null
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color.Transparent,
                                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                            ),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Text("Cancel", fontSize = 12.sp)
                                        }

                                        Spacer(modifier = Modifier.width(6.dp))

                                        Button(
                                            onClick = {
                                                val scan = com.example.safety.BhartTubeSafetyShield.scanContent(newCommentText, "", "Comments")
                                                if (scan.isViolation) {
                                                    commentValidationError = "⚠️ टिप्पणी में वर्जित शब्द हैं! कृपया सम्मानजनक भाषा लिखें।"
                                                } else {
                                                    viewModel.addCommentToActiveVideo(newCommentText)
                                                    newCommentText = ""
                                                    commentValidationError = null
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed),
                                            shape = RoundedCornerShape(16.dp),
                                            modifier = Modifier
                                                .height(32.dp)
                                                .testTag("post_comment_button")
                                        ) {
                                            Text("Comment", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                    thickness = 0.5.dp
                )

                Spacer(modifier = Modifier.height(6.dp))
            }

            // Body based on active tab
            if (selectedViewTab == 0) {
                // Comments Stream
                if (comments.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No comments yet. Be the first to share your thoughts!",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    items(comments, key = { it.id }) { comment ->
                        InteractiveCommentRow(
                            comment = comment,
                            channelName = video.channelName,
                            viewModel = viewModel,
                            isReplying = replyingToCommentId == comment.id,
                            onStartReply = {
                                replyingToCommentId = if (replyingToCommentId == comment.id) null else comment.id
                                replyText = ""
                            },
                            replyText = replyText,
                            onReplyTextChange = { replyText = it },
                            onSubmitReply = {
                                if (replyText.isNotBlank()) {
                                    val scan = com.example.safety.BhartTubeSafetyShield.scanContent(replyText, "", "Comments")
                                    if (scan.isViolation) {
                                        commentValidationError = "⚠️ उत्तर में वर्जित शब्द हैं!"
                                    } else {
                                        viewModel.addCommentToActiveVideo(replyText, parentId = comment.id)
                                        replyText = ""
                                        replyingToCommentId = null
                                        expandedRepliesSet = expandedRepliesSet + comment.id
                                    }
                                }
                            },
                            onCancelReply = {
                                replyingToCommentId = null
                                replyText = ""
                            },
                            isRepliesExpanded = expandedRepliesSet.contains(comment.id),
                            onToggleReplies = {
                                expandedRepliesSet = if (expandedRepliesSet.contains(comment.id)) {
                                    expandedRepliesSet - comment.id
                                } else {
                                    expandedRepliesSet + comment.id
                                }
                            }
                        )
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                            thickness = 0.5.dp,
                            modifier = Modifier.padding(horizontal = 14.dp)
                        )
                    }
                }
            } else {
                // Up Next / Recommended Videos with Comment Preview Card
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { selectedViewTab = 0 }
                            .padding(12.dp)
                            .testTag("comments_preview_card")
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Comments",
                                    color = MaterialTheme.colorScheme.onBackground,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${comments.size}",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = "View discussion →",
                                    color = YouTubeBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            if (comments.isNotEmpty()) {
                                val top = comments.first()
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(BhartTubeRed),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = top.authorName.take(1),
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = top.text,
                                        color = MaterialTheme.colorScheme.onBackground,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }

                items(otherVideos) { recommended ->
                    VideoCard(
                        video = recommended,
                        onClick = { viewModel.playVideo(recommended) },
                        onSaveWatchLater = { viewModel.toggleSaveWatchLater(it) },
                        onDownload = { viewModel.toggleDownload(it) },
                        onShare = onShare
                    )
                }
            }
        }

        // Full Comments Bottom Sheet
        if (showCommentsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showCommentsSheet = false },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Comments (${comments.size})",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        IconButton(onClick = { viewModel.toggleCommentSort() }) {
                            Icon(
                                imageVector = Icons.Default.Sort,
                                contentDescription = "Sort",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Input Box in Modal
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newCommentText,
                            onValueChange = { newCommentText = it },
                            placeholder = { Text("Add a comment...", fontSize = 13.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(20.dp),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (newCommentText.isNotBlank()) {
                                    val scan = com.example.safety.BhartTubeSafetyShield.scanContent(newCommentText, "", "Comments")
                                    if (!scan.isViolation) {
                                        viewModel.addCommentToActiveVideo(newCommentText)
                                        newCommentText = ""
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send",
                                tint = BhartTubeRed
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp)
                    ) {
                        items(comments, key = { it.id }) { comment ->
                            InteractiveCommentRow(
                                comment = comment,
                                channelName = video.channelName,
                                viewModel = viewModel,
                                isReplying = replyingToCommentId == comment.id,
                                onStartReply = {
                                    replyingToCommentId = if (replyingToCommentId == comment.id) null else comment.id
                                    replyText = ""
                                },
                                replyText = replyText,
                                onReplyTextChange = { replyText = it },
                                onSubmitReply = {
                                    if (replyText.isNotBlank()) {
                                        viewModel.addCommentToActiveVideo(replyText, parentId = comment.id)
                                        replyText = ""
                                        replyingToCommentId = null
                                        expandedRepliesSet = expandedRepliesSet + comment.id
                                    }
                                },
                                onCancelReply = {
                                    replyingToCommentId = null
                                    replyText = ""
                                },
                                isRepliesExpanded = expandedRepliesSet.contains(comment.id),
                                onToggleReplies = {
                                    expandedRepliesSet = if (expandedRepliesSet.contains(comment.id)) {
                                        expandedRepliesSet - comment.id
                                    } else {
                                        expandedRepliesSet + comment.id
                                    }
                                }
                            )
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                                thickness = 0.5.dp,
                                modifier = Modifier.padding(horizontal = 14.dp)
                            )
                        }
                    }
                }
            }
        }

        // Super Chat Locked Dialog (if subs < 500)
        if (showSuperChatLockedDialog) {
            val subs = creatorStats?.subscribers ?: 0
            AlertDialog(
                onDismissRequest = { showSuperChatLockedDialog = false },
                title = { Text("Super Chat Locked 🔒") },
                text = {
                    Column {
                        Text(
                            text = "500 Subscribers Required for Super Chat",
                            fontWeight = FontWeight.Bold,
                            color = BhartTubeRed,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "BhartTube पर 500 subscriber पूरा होने के बाद ही Super Chat अनलॉक होता है। वर्तमान में चैनल के पास $subs सब्सक्राइबर हैं।",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showSuperChatLockedDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed)
                    ) {
                        Text("OK")
                    }
                }
            )
        }

        // Super Chat Sending Dialog (if subs >= 500)
        if (showSuperChatDialog) {
            var selectedAmount by remember { mutableStateOf(100.0) }
            var superChatMessage by remember { mutableStateOf("Great video! Keep it up! 🌟") }

            AlertDialog(
                onDismissRequest = { showSuperChatDialog = false },
                title = { Text("Send Super Chat to Creator") },
                text = {
                    Column {
                        Text("500+ Subscribers Milestone Unlocked! ✨", color = YouTubeGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Select Super Chat Amount:", fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(20.0, 50.0, 100.0, 200.0, 500.0).forEach { amt ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (selectedAmount == amt) YouTubeGreen else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { selectedAmount = amt }
                                        .padding(vertical = 8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxWidth(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "₹${amt.toInt()}",
                                            color = if (selectedAmount == amt) Color.White else MaterialTheme.colorScheme.onBackground,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = superChatMessage,
                            onValueChange = { superChatMessage = it },
                            label = { Text("Personal Message") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.sendSuperChat(selectedAmount, superChatMessage, "Fan Supporter")
                            showSuperChatDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = YouTubeGreen)
                    ) {
                        Text("Send ₹${selectedAmount.toInt()} Super Chat")
                    }
                },
                dismissButton = {
                    androidx.compose.material3.TextButton(onClick = { showSuperChatDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Automatic Copyright Certificate Dialog
        if (showCopyrightDialog) {
            val cert = com.example.safety.BhartTubeCopyrightManager.getCertificate(video)
            val context = androidx.compose.ui.platform.LocalContext.current

            AlertDialog(
                onDismissRequest = { showCopyrightDialog = false },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Copyright Shield",
                        tint = BhartTubeRed,
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        text = "स्वचालित कॉपीराइट एवं डिजिटल लाइसेंस",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = "Automatic Copyright Protection (Content ID)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BhartTubeRed
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Content ID: ${cert.contentId}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "स्वामित्व (Owner): ${cert.ownerName}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "स्थिति: ${cert.status}",
                                    fontSize = 11.sp,
                                    color = com.example.ui.theme.YouTubeGreen,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "डिजिटल फिंगरप्रिंट:\n${cert.digitalFingerprint}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "सुरक्षा नीति: यह वीडियो BhartTube Content ID प्रणाली द्वारा स्वतः सुरक्षित है। निर्माता '${video.channelName}' को इसके समस्त प्रसारण, मोनेटाइजेशन और ऑडियो-विजुअल अधिकार प्राप्त हैं।",
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val sendIntent = android.content.Intent().apply {
                                action = android.content.Intent.ACTION_SEND
                                putExtra(
                                    android.content.Intent.EXTRA_TEXT,
                                    "BhartTube Copyright Protection Certificate:\nVideo: ${video.title}\nOwner: ${video.channelName}\nContent ID: ${cert.contentId}\nStatus: Verified Original Work\nWatch: https://bharttube.app/watch?v=${video.id}"
                                )
                                type = "text/plain"
                            }
                            val shareIntent = android.content.Intent.createChooser(sendIntent, "Share Copyright Certificate / शेयर करें")
                            context.startActivity(shareIntent)
                            showCopyrightDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("शेयर करें (Share)")
                    }
                },
                dismissButton = {
                    androidx.compose.material3.TextButton(onClick = { showCopyrightDialog = false }) {
                        Text("बंद करें (Close)")
                    }
                }
            )
        }

        if (showPremiumDialog) {
            val sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = true)
            com.example.ui.components.BhartTubePremiumSheet(
                onDismiss = { viewModel.closePremiumDialog() },
                onSubscribe = { paymentMethod ->
                    viewModel.subscribeToMonthlyPremium(paymentMethod)
                },
                sheetState = sheetState,
                isAlreadyPremium = isUserPremium
            )
        }
    }
}

@Composable
fun ActionPill(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    tint: Color = MaterialTheme.colorScheme.onBackground
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.height(36.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clickable(onClick = onClick)
                .padding(horizontal = 12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = tint
            )
        }
    }
}

@Composable
fun InteractiveCommentRow(
    comment: CommentEntity,
    channelName: String,
    viewModel: BhartTubeViewModel,
    isReplying: Boolean,
    onStartReply: () -> Unit,
    replyText: String,
    onReplyTextChange: (String) -> Unit,
    onSubmitReply: () -> Unit,
    onCancelReply: () -> Unit,
    isRepliesExpanded: Boolean,
    onToggleReplies: () -> Unit
) {
    val isCreator = comment.authorName == channelName
    val isUser = comment.authorName.contains("You")
    val context = androidx.compose.ui.platform.LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("comment_item_${comment.id}")
    ) {
        // Pinned Banner if pinned
        if (comment.isPinned) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 42.dp, bottom = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PushPin,
                    contentDescription = "Pinned",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Pinned by $channelName",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(
                        if (isUser) YouTubeBlue
                        else if (isCreator) BhartTubeRed
                        else MaterialTheme.colorScheme.primary
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isUser) "YOU" else comment.authorName.take(1).uppercase(),
                    color = Color.White,
                    fontSize = if (isUser) 10.sp else 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                // Author Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = comment.authorName,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    if (isCreator) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(BhartTubeRed)
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "CREATOR",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    } else if (isUser) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(YouTubeBlue.copy(alpha = 0.2f))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "YOU",
                                color = YouTubeBlue,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = comment.timeAgo,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    // Delete button if posted by You
                    if (isUser) {
                        IconButton(
                            onClick = { viewModel.deleteComment(comment.id) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Delete comment",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                // Comment Content
                Text(
                    text = comment.text,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Actions: Like, Dislike, Heart, Reply
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Like Action
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { viewModel.toggleLikeComment(comment) }
                            .padding(vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = if (comment.isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                            contentDescription = "Like comment",
                            tint = if (comment.isLiked) BhartTubeRed else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(15.dp)
                        )
                        if (comment.likes > 0) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = formatViewsCount(comment.likes.toLong()),
                                fontSize = 11.sp,
                                color = if (comment.isLiked) BhartTubeRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Dislike Action
                    Icon(
                        imageVector = Icons.Outlined.ThumbDown,
                        contentDescription = "Dislike comment",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .size(15.dp)
                            .clickable { /* dislike action */ }
                    )

                    // Creator Heart
                    if (comment.isHeartedByCreator) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(BhartTubeRed),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = channelName.take(1).uppercase(),
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(3.dp))
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "Hearted by creator",
                                tint = Color.Red,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }

                    // Reply Button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { onStartReply() }
                            .padding(vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Reply,
                            contentDescription = "Reply",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Reply",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Share Comment Button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable {
                                val sendIntent = android.content.Intent().apply {
                                    action = android.content.Intent.ACTION_SEND
                                    putExtra(
                                        android.content.Intent.EXTRA_TEXT,
                                        "${comment.authorName} on BhartTube: \"${comment.text}\" https://bharttube.app/watch?v=${comment.videoId}"
                                    )
                                    type = "text/plain"
                                }
                                val shareIntent = android.content.Intent.createChooser(sendIntent, "Share comment / शेयर")
                                context.startActivity(shareIntent)
                            }
                            .padding(vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share comment / शेयर",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Share",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Inline Reply Composer
                if (isReplying) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "Replying to @${comment.authorName}",
                            fontSize = 11.sp,
                            color = BhartTubeRed,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = replyText,
                            onValueChange = onReplyTextChange,
                            placeholder = { Text("Add a reply...", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = onCancelReply,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.Transparent,
                                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("Cancel", fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Button(
                                onClick = onSubmitReply,
                                enabled = replyText.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed),
                                modifier = Modifier.height(32.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text("Reply", fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Threaded Replies Toggle & Nested List
                if (comment.replyCount > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { onToggleReplies() }
                            .padding(vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = if (isRepliesExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            tint = YouTubeBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isRepliesExpanded) "Hide replies" else "View ${comment.replyCount} replies",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = YouTubeBlue
                        )
                    }

                    if (isRepliesExpanded) {
                        val replies by viewModel.getRepliesForComment(comment.id).collectAsStateWithLifecycle(emptyList<CommentEntity>())
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 12.dp, top = 6.dp)
                        ) {
                            for (childReply in replies) {
                                ReplyRowItem(
                                    reply = childReply,
                                    channelName = channelName,
                                    viewModel = viewModel
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReplyRowItem(
    reply: CommentEntity,
    channelName: String,
    viewModel: BhartTubeViewModel
) {
    val isCreator = reply.authorName == channelName
    val isUser = reply.authorName.contains("You")

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(if (isUser) YouTubeBlue else if (isCreator) BhartTubeRed else MaterialTheme.colorScheme.secondary),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (isUser) "YOU" else reply.authorName.take(1).uppercase(),
                color = Color.White,
                fontSize = if (isUser) 7.sp else 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = reply.authorName,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                if (isCreator) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(BhartTubeRed)
                            .padding(horizontal = 4.dp, vertical = 0.5.dp)
                    ) {
                        Text("CREATOR", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = reply.timeAgo,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = reply.text,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (reply.isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                    contentDescription = "Like reply",
                    tint = if (reply.isLiked) BhartTubeRed else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .size(12.dp)
                        .clickable { viewModel.toggleLikeComment(reply) }
                )
                if (reply.likes > 0) {
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${reply.likes}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (isUser) {
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Delete",
                        fontSize = 10.sp,
                        color = BhartTubeRed,
                        modifier = Modifier.clickable { viewModel.deleteComment(reply.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun CommentRow(comment: CommentEntity) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(BhartTubeRed),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = comment.authorName.take(1).uppercase(),
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = comment.authorName,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = comment.timeAgo,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = comment.text,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 13.sp
            )
        }
    }
}
