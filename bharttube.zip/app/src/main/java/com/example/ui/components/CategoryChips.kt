package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SentimentVerySatisfied
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BhartTubeRed
import kotlinx.coroutines.launch

/**
 * Model representing a Category for navigation and feed filtering.
 */
data class CategoryItem(
    val id: String,
    val titleEn: String,
    val titleHi: String,
    val icon: ImageVector,
    val emoji: String,
    val description: String
)

val AllCategories = listOf(
    CategoryItem(
        id = "All",
        titleEn = "All",
        titleHi = "सभी",
        icon = Icons.Default.AllInclusive,
        emoji = "✨",
        description = "All recommended videos and trending content"
    ),
    CategoryItem(
        id = "Gaming",
        titleEn = "Gaming",
        titleHi = "गेमिंग",
        icon = Icons.Default.SportsEsports,
        emoji = "🎮",
        description = "Esports, live streams, BGMI, GTA 6 & walkthroughs"
    ),
    CategoryItem(
        id = "Music",
        titleEn = "Music",
        titleHi = "म्यूजिक",
        icon = Icons.Default.MusicNote,
        emoji = "🎵",
        description = "Bollywood, classical ragas, lo-fi beats & songs"
    ),
    CategoryItem(
        id = "Tech",
        titleEn = "Tech",
        titleHi = "टेक",
        icon = Icons.Default.Computer,
        emoji = "💻",
        description = "Gadgets, smartphones, AI, programming & ISRO space"
    ),
    CategoryItem(
        id = "Cooking",
        titleEn = "Cooking",
        titleHi = "कुकिंग",
        icon = Icons.Default.Restaurant,
        emoji = "🍳",
        description = "Street food tours, quick recipes & Indian dishes"
    ),
    CategoryItem(
        id = "Education",
        titleEn = "Education",
        titleHi = "शिक्षा",
        icon = Icons.Default.School,
        emoji = "📚",
        description = "App development, science lessons & tutorials"
    ),
    CategoryItem(
        id = "Comedy",
        titleEn = "Comedy",
        titleHi = "कॉमेडी",
        icon = Icons.Default.SentimentVerySatisfied,
        emoji = "😂",
        description = "Standup comedy, desi vines, sketches & humor"
    ),
    CategoryItem(
        id = "Vlogs",
        titleEn = "Vlogs",
        titleHi = "व्लॉग्स",
        icon = Icons.Default.Videocam,
        emoji = "📹",
        description = "Himalayan travel adventures, road trips & life"
    ),
    CategoryItem(
        id = "Trending",
        titleEn = "Trending",
        titleHi = "ट्रेंडिंग",
        icon = Icons.Default.LocalFireDepartment,
        emoji = "🔥",
        description = "Most watched viral videos right now across Bharat"
    ),
    CategoryItem(
        id = "News",
        titleEn = "News",
        titleHi = "समाचार",
        icon = Icons.Default.Newspaper,
        emoji = "📰",
        description = "Daily headlines, tech news & nation updates"
    )
)

/**
 * High-performance, YouTube-style Category Navigation Bar at the top of the feed.
 * Allows users to easily switch and filter video feeds (Gaming, Music, Tech, etc.).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryNavigationBar(
    categories: List<CategoryItem> = AllCategories,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var showExploreSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()
    val scope = rememberCoroutineScope()

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("category_navigation_bar"),
        color = MaterialTheme.colorScheme.background,
        shadowElevation = 0.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Leading Explore Button (Compass Icon)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                    border = androidx.compose.foundation.BorderStroke(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier
                        .height(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showExploreSheet = true }
                        .testTag("category_explore_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Explore,
                            contentDescription = "Explore Categories",
                            tint = BhartTubeRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Explore 🧭",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Vertical Divider between Explore & Category Chips
                Box(
                    modifier = Modifier
                        .height(20.dp)
                        .width(1.dp)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Category Chips (Gaming, Music, Tech, Cooking, etc.)
                categories.forEach { category ->
                    val isSelected = category.id.equals(selectedCategory, ignoreCase = true)

                    val backgroundColor by animateColorAsState(
                        targetValue = if (isSelected) {
                            MaterialTheme.colorScheme.onBackground
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)
                        },
                        label = "chip_bg"
                    )

                    val contentColor by animateColorAsState(
                        targetValue = if (isSelected) {
                            MaterialTheme.colorScheme.background
                        } else {
                            MaterialTheme.colorScheme.onSurface
                        },
                        label = "chip_content"
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = backgroundColor,
                        border = if (!isSelected) {
                            androidx.compose.foundation.BorderStroke(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                            )
                        } else null,
                        modifier = Modifier
                            .height(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                if (isSelected && category.id != "All") {
                                    // Toggle back to All when tapping active filter
                                    onCategorySelected("All")
                                } else {
                                    onCategorySelected(category.id)
                                }
                            }
                            .testTag("category_chip_${category.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = category.icon,
                                contentDescription = null,
                                tint = contentColor,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${category.titleEn} / ${category.titleHi}",
                                color = contentColor,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1
                            )

                            // Quick Reset "✕" indicator on selected chip
                            if (isSelected && category.id != "All") {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(contentColor.copy(alpha = 0.2f))
                                        .clickable { onCategorySelected("All") },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear filter",
                                        tint = contentColor,
                                        modifier = Modifier.size(10.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))
                }
            }

            // Subtle divider below category navigation bar
            HorizontalDivider(
                modifier = Modifier.fillMaxWidth(),
                thickness = 0.5.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)
            )
        }
    }

    // Explore Categories Bottom Sheet
    if (showExploreSheet) {
        ModalBottomSheet(
            onDismissRequest = { showExploreSheet = false },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Explore,
                            contentDescription = null,
                            tint = BhartTubeRed,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "एक्सप्लोर श्रेणियां (Explore Categories)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable {
                                scope.launch {
                                    sheetState.hide()
                                    showExploreSheet = false
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Select a category to filter videos and shorts feed:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { category ->
                        val isSelected = category.id.equals(selectedCategory, ignoreCase = true)
                        Card(
                            onClick = {
                                onCategorySelected(category.id)
                                scope.launch {
                                    sheetState.hide()
                                    showExploreSheet = false
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                }
                            ),
                            border = if (isSelected) {
                                androidx.compose.foundation.BorderStroke(2.dp, BhartTubeRed)
                            } else {
                                androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = category.icon,
                                        contentDescription = null,
                                        tint = if (isSelected) BhartTubeRed else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Text(
                                        text = category.emoji,
                                        fontSize = 18.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "${category.titleEn} (${category.titleHi})",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = category.description,
                                    fontSize = 11.sp,
                                    lineHeight = 14.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Backward-compatible wrapper for existing CategoryChips invocations.
 */
@Composable
fun CategoryChips(
    categories: List<String>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    // Map string categories to CategoryItems
    val categoryItems = categories.map { catName ->
        AllCategories.find { it.id.equals(catName, ignoreCase = true) }
            ?: CategoryItem(
                id = catName,
                titleEn = catName,
                titleHi = catName,
                icon = Icons.Default.AllInclusive,
                emoji = "🏷️",
                description = "Videos in $catName"
            )
    }

    CategoryNavigationBar(
        categories = categoryItems,
        selectedCategory = selectedCategory,
        onCategorySelected = onCategorySelected,
        modifier = modifier
    )
}
