package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.SubscriptionEntity
import com.example.data.model.VideoEntity
import com.example.ui.components.ShortCard
import com.example.ui.components.ShortsShelf
import com.example.ui.components.VideoCard
import com.example.ui.components.parseGradients
import com.example.ui.theme.BhartTubeRed
import com.example.ui.theme.YouTubeBlue
import com.example.ui.viewmodel.BhartTubeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelPageScreen(
    channelName: String,
    viewModel: BhartTubeViewModel,
    onBack: () -> Unit,
    onVideoClick: (VideoEntity) -> Unit,
    onShare: (VideoEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val subscription by viewModel.selectedChannelSubscription.collectAsStateWithLifecycle()
    val allChannelVideos by viewModel.selectedChannelVideos.collectAsStateWithLifecycle()
    val channelLongVideos by viewModel.selectedChannelLongVideos.collectAsStateWithLifecycle()
    val channelShorts by viewModel.selectedChannelShorts.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showBellMenu by remember { mutableStateOf(false) }
    var showUnsubscribeDialog by remember { mutableStateOf(false) }
    var showAboutSheet by remember { mutableStateOf(false) }

    // Fallback info if not already in DB
    val firstVideo = allChannelVideos.firstOrNull()
    val avatarUrl = subscription?.channelAvatarUrl ?: firstVideo?.channelAvatarUrl ?: ""
    val subCount = subscription?.subscriberCount ?: firstVideo?.subscriberCount ?: "1.2M subscribers"
    val isSubscribed = subscription?.isSubscribed ?: (firstVideo?.isSubscribed == true)
    val hasBell = subscription?.hasBellNotification ?: true
    val handle = subscription?.handle?.ifBlank { "@${channelName.lowercase().replace(" ", "_")}" } ?: "@${channelName.lowercase().replace(" ", "_")}"
    val description = subscription?.channelDescription?.ifBlank {
        "Welcome to the official $channelName on BhartTube! Watch videos, shorts, and stay updated."
    } ?: "Welcome to the official $channelName on BhartTube! Watch videos, shorts, and stay updated."
    val bannerGradient = subscription?.bannerGradient ?: "0xFFFF512F,0xFFDD2476"
    val totalVideos = subscription?.totalVideos ?: (allChannelVideos.size.coerceAtLeast(12))
    val joinedDate = subscription?.joinedDate ?: "Joined 2022"

    val tabs = listOf("Home", "Videos", "Shorts", "About")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Channel TopAppBar
        TopAppBar(
            title = {
                Text(
                    text = channelName,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            },
            actions = {
                IconButton(onClick = { /* Search in channel */ }) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search channel",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                IconButton(onClick = { /* More options */ }) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "More options",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
                titleContentColor = MaterialTheme.colorScheme.onBackground
            )
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            item {
                // Channel Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .background(parseGradients(bannerGradient)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = channelName.uppercase(),
                        color = Color.White.copy(alpha = 0.25f),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                }

                // Channel Header Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Large Avatar
                        if (avatarUrl.isNotBlank()) {
                            AsyncImage(
                                model = avatarUrl,
                                contentDescription = channelName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, MaterialTheme.colorScheme.background, CircleShape)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(BhartTubeRed),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = channelName.take(1).uppercase(),
                                    color = Color.White,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Channel metadata
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = channelName,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = "Verified",
                                    tint = YouTubeBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = "$handle • $subCount • $totalVideos videos",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 16.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Description snippet with "...more" link
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable { showAboutSheet = true }
                            ) {
                                Text(
                                    text = description,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.ChevronRight,
                                    contentDescription = "More info",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // SUBSCRIBE & JOIN BUTTON ROW
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Subscribe Button
                        if (!isSubscribed) {
                            Button(
                                onClick = {
                                    viewModel.toggleSubscription(
                                        channelName = channelName,
                                        currentSubscribed = false,
                                        avatarUrl = avatarUrl,
                                        subscriberCount = subCount,
                                        description = description,
                                        handle = handle
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("channel_subscribe_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text(
                                    text = "Subscribe",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        } else {
                            // Subscribed Button with Bell notification dropdown
                            Box(modifier = Modifier.weight(1f)) {
                                Button(
                                    onClick = { showBellMenu = true },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(38.dp)
                                        .testTag("channel_subscribed_button"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = MaterialTheme.colorScheme.onBackground
                                    ),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Icon(
                                        imageVector = if (hasBell) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                                        contentDescription = "Notification Bell",
                                        tint = MaterialTheme.colorScheme.onBackground,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Subscribed",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }

                                DropdownMenu(
                                    expanded = showBellMenu,
                                    onDismissRequest = { showBellMenu = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("All notifications") },
                                        leadingIcon = {
                                            Icon(Icons.Default.NotificationsActive, null, tint = YouTubeBlue)
                                        },
                                        onClick = {
                                            showBellMenu = false
                                            viewModel.updateBellNotification(channelName, true)
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Personalized") },
                                        leadingIcon = {
                                            Icon(Icons.Default.Notifications, null)
                                        },
                                        onClick = {
                                            showBellMenu = false
                                            viewModel.updateBellNotification(channelName, true)
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("None") },
                                        leadingIcon = {
                                            Icon(Icons.Default.NotificationsOff, null)
                                        },
                                        onClick = {
                                            showBellMenu = false
                                            viewModel.updateBellNotification(channelName, false)
                                        }
                                    )
                                    HorizontalDivider()
                                    DropdownMenuItem(
                                        text = { Text("Unsubscribe", color = BhartTubeRed) },
                                        onClick = {
                                            showBellMenu = false
                                            showUnsubscribeDialog = true
                                        }
                                    )
                                }
                            }
                        }

                        // Join Channel Button
                        Button(
                            onClick = { /* Channel Perks */ },
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = YouTubeBlue
                            ),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                text = "Join",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }

                // Channel Tabs (Home, Videos, Shorts, About)
                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.background,
                    contentColor = MaterialTheme.colorScheme.onBackground,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = BhartTubeRed,
                            height = 2.dp
                        )
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = { selectedTabIndex = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 14.sp,
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        )
                    }
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                // Home Tab: Featured video + Shorts + Recent
                0 -> {
                    if (channelLongVideos.isNotEmpty()) {
                        item {
                            Text(
                                text = "Featured Video",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp)
                            )
                        }
                        item {
                            VideoCard(
                                video = channelLongVideos.first(),
                                onClick = { onVideoClick(channelLongVideos.first()) },
                                onSaveWatchLater = { viewModel.toggleSaveWatchLater(it) },
                                onDownload = { viewModel.toggleDownload(it) },
                                onShare = onShare
                            )
                        }
                    }

                    if (channelShorts.isNotEmpty()) {
                        item {
                            ShortsShelf(
                                shorts = channelShorts,
                                onShortClick = onVideoClick
                            )
                        }
                    }

                    if (channelLongVideos.size > 1) {
                        item {
                            Text(
                                text = "Recent Uploads",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 4.dp)
                            )
                        }
                        items(channelLongVideos.drop(1)) { v ->
                            VideoCard(
                                video = v,
                                onClick = { onVideoClick(v) },
                                onSaveWatchLater = { viewModel.toggleSaveWatchLater(it) },
                                onDownload = { viewModel.toggleDownload(it) },
                                onShare = onShare
                            )
                        }
                    }

                    if (allChannelVideos.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "This channel hasn't uploaded any videos yet.",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Videos Tab: All long videos
                1 -> {
                    if (channelLongVideos.isNotEmpty()) {
                        items(channelLongVideos) { v ->
                            VideoCard(
                                video = v,
                                onClick = { onVideoClick(v) },
                                onSaveWatchLater = { viewModel.toggleSaveWatchLater(it) },
                                onDownload = { viewModel.toggleDownload(it) },
                                onShare = onShare
                            )
                        }
                    } else {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No long videos available on this channel.",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Shorts Tab: Grid of shorts
                2 -> {
                    if (channelShorts.isNotEmpty()) {
                        item {
                            Column(modifier = Modifier.padding(16.dp)) {
                                channelShorts.chunked(2).forEach { rowShorts ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        rowShorts.forEach { s ->
                                            ShortCard(
                                                short = s,
                                                onClick = { onVideoClick(s) },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                        if (rowShorts.size == 1) {
                                            Spacer(modifier = Modifier.weight(1f))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                }
                            }
                        }
                    } else {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No Shorts available on this channel.",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // About Tab
                3 -> {
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Description",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = description,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            Text(
                                text = "Channel Stats",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Language, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Location: India", color = MaterialTheme.colorScheme.onBackground, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CalendarMonth, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(joinedDate, color = MaterialTheme.colorScheme.onBackground, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Videocam, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("$totalVideos videos uploaded", color = MaterialTheme.colorScheme.onBackground, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("https://bharttube.app/$handle", color = YouTubeBlue, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        // Unsubscribe Confirmation Dialog
        if (showUnsubscribeDialog) {
            AlertDialog(
                onDismissRequest = { showUnsubscribeDialog = false },
                title = { Text("Unsubscribe from $channelName?") },
                text = { Text("You won't receive updates and notifications from this channel anymore.") },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.toggleSubscription(
                                channelName = channelName,
                                currentSubscribed = true,
                                avatarUrl = avatarUrl,
                                subscriberCount = subCount,
                                description = description,
                                handle = handle
                            )
                            showUnsubscribeDialog = false
                        }
                    ) {
                        Text("Unsubscribe", color = BhartTubeRed)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showUnsubscribeDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // About Channel Modal Bottom Sheet
        if (showAboutSheet) {
            ModalBottomSheet(
                onDismissRequest = { showAboutSheet = false },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "About this channel",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = description,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "More info",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "🌐 https://bharttube.app/$handle", color = YouTubeBlue, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "📍 India", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "📅 $joinedDate", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "👥 $subCount", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}
