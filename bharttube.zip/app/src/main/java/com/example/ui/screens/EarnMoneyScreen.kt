package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.BhartTubeRed
import com.example.ui.theme.YouTubeBlue
import com.example.ui.theme.YouTubeGreen
import com.example.ui.viewmodel.BhartTubeViewModel
import com.example.ui.viewmodel.ScreenDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EarnMoneyScreen(
    viewModel: BhartTubeViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.creatorStats.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    var showBankDialog by remember { mutableStateOf(false) }
    var bankHolder by remember { mutableStateOf(stats?.bankAccountHolder ?: "Tinku Kumar") }
    var bankAccNumber by remember { mutableStateOf(stats?.bankAccountNumber ?: "123456789012") }
    var bankIfsc by remember { mutableStateOf(stats?.ifscCode ?: "SBIN0001234") }

    val subscribers = stats?.subscribers ?: 860
    val targetSubs = stats?.targetSubscribers ?: 1000
    val watchHours = stats?.watchHours ?: 1140.0
    val targetHours = stats?.targetWatchHours ?: 1500.0
    val shortsViews = stats?.shortsViews ?: 3850000L
    val targetShortsViews = stats?.targetShortsViews ?: 5000000L // 5 Million
    val isMonetized = stats?.isMonetized ?: false
    val hasApplied = stats?.hasApplied ?: false

    // Check if criteria are met
    val subsMet = subscribers >= targetSubs
    val hoursMet = watchHours >= targetHours
    val shortsMet = shortsViews >= targetShortsViews
    val isEligible = subsMet && hoursMet && shortsMet

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "Earn on BhartTube",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
                titleContentColor = MaterialTheme.colorScheme.onBackground
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(BhartTubeRed),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "BhartTube Partner Program",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = if (isMonetized) "Active Partner • Monetization Enabled" else if (hasApplied) "Application Under Review" else "Monetization Hub & Eligibility",
                                fontSize = 12.sp,
                                color = if (isMonetized) YouTubeGreen else if (hasApplied) YouTubeBlue else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (isMonetized) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(14.dp))

                        // Estimated Revenue Summary
                        Text(
                            text = "Estimated Creator Earnings (This Month)",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CurrencyRupee,
                                contentDescription = null,
                                tint = YouTubeGreen,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = String.format("%,.2f", stats?.estimatedRevenueInr ?: 28400.0),
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Watch Page Ads: ₹${(stats?.adWatchPageRevenueInr ?: 18200.0).toInt()}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Shorts Feed Ads: ₹${(stats?.shortsFeedRevenueInr ?: 4150.0).toInt()}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Super Thanks: ₹${(stats?.superThanksInr ?: 2500.0).toInt()}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // CRITICAL SECTION: Exact Monetization Criteria Required by User:
            // 1. 1000 Subscriber
            // 2. 1500 Ghanta Watching Time
            // 3. 5 Milon Shorts View
            Text(
                text = "Monetization Eligibility Criteria",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Complete the following targets to join the BhartTube Partner Program and start earning money.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Criteria 1: 1,000 Subscribers
            EligibilityProgressCard(
                icon = Icons.Default.People,
                title = "1,000 Subscribers",
                hindiLabel = "1000 सब्सक्राइबर",
                currentValue = subscribers.toLong(),
                targetValue = targetSubs.toLong(),
                currentText = "$subscribers",
                targetText = "$targetSubs",
                isMet = subsMet,
                progress = (subscribers.toFloat() / targetSubs).coerceIn(0f, 1f)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Criteria 2: 1,500 Watch Hours (1500 घंटा वाचिंग टाइम)
            EligibilityProgressCard(
                icon = Icons.Default.HourglassTop,
                title = "1,500 Public Watch Hours",
                hindiLabel = "1500 घंटा वाचिंग टाइम",
                currentValue = watchHours.toLong(),
                targetValue = targetHours.toLong(),
                currentText = "${watchHours.toInt()} hrs",
                targetText = "${targetHours.toInt()} hrs",
                isMet = hoursMet,
                progress = (watchHours.toFloat() / targetHours.toFloat()).coerceIn(0f, 1f)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Criteria 3: 5 Million Shorts Views (5 milon shorts view)
            EligibilityProgressCard(
                icon = Icons.Default.Visibility,
                title = "5.0 Million Shorts Views",
                hindiLabel = "5 Million शॉर्ट्स व्यू",
                currentValue = shortsViews,
                targetValue = targetShortsViews,
                currentText = String.format("%.2fM", shortsViews / 1000000.0),
                targetText = "5.0M",
                isMet = shortsMet,
                progress = (shortsViews.toFloat() / targetShortsViews.toFloat()).coerceIn(0f, 1f)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Apply Button or Approved Banner
            if (isMonetized) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = YouTubeGreen.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, YouTubeGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = YouTubeGreen,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "BhartTube Partner Program Active! 🎉",
                                fontWeight = FontWeight.Bold,
                                color = YouTubeGreen,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "All ads, Super Thanks, and Memberships are earning revenue.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            } else if (hasApplied) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = YouTubeBlue.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = YouTubeBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Application Submitted!",
                                fontWeight = FontWeight.Bold,
                                color = YouTubeBlue,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "BhartTube team is reviewing your channel. Click Approve to finalize.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        Button(
                            onClick = { viewModel.approveMonetization() },
                            colors = ButtonDefaults.buttonColors(containerColor = YouTubeGreen)
                        ) {
                            Text("Approve")
                        }
                    }
                }
            } else {
                Button(
                    onClick = {
                        if (isEligible) {
                            viewModel.applyForMonetization()
                        } else {
                            viewModel.simulateGrowth(200, 400.0, 1500000L)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("apply_partner_program_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isEligible) BhartTubeRed else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (isEligible) Icons.Default.CheckCircle else Icons.Default.Stars,
                        contentDescription = null,
                        tint = if (isEligible) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isEligible) "Apply for BhartTube Partner Program" else "Reach Criteria to Apply (or Simulate Below)",
                        color = if (isEligible) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Creator Fast-Track Testing & Simulator Box
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = BhartTubeRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Channel Growth Simulator (Test Criteria)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    Text(
                        text = "Instantly test adding Subscribers, Watch Hours, and Shorts Views to reach targets:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.simulateGrowth(100, 0.0, 0L) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+100 Subs", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.simulateGrowth(0, 200.0, 0L) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+200 Hours", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.simulateGrowth(0, 0.0, 1000000L) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+1M Views", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Button(
                        onClick = {
                            viewModel.simulateGrowth(300, 500.0, 2000000L)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Instant Unlock All Targets (1000 Subs, 1500h, 5M Views)")
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Milestone Feature Unlocks Section (Live Stream at 50, Superchat at 500)
            Text(
                text = "फीचर अनलॉक व सब्सक्राइबर माइलस्टोन (Feature Milestones)",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 1. Live Stream Unlock Card (50 Subscribers)
            val canLive = subscribers >= 50
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = if (canLive) androidx.compose.foundation.BorderStroke(1.dp, YouTubeGreen) else null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (canLive) YouTubeGreen else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Live Stream (लाइव स्ट्रीमिंग)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (canLive) YouTubeGreen else BhartTubeRed.copy(alpha = 0.8f)
                            ) {
                                Text(
                                    text = if (canLive) "UNLOCKED (अनलॉक)" else "50 SUBS REQUIRED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = if (canLive) "आप 50 सब्सक्राइबर पूरे कर चुके हैं! लाइव स्ट्रीम कर सकते हैं।" else "50 सब्सक्राइबर पूरे होने के बाद Live Stream शुरू कर सकेंगे। वर्तमान: $subscribers/50",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (canLive) {
                        Button(
                            onClick = { viewModel.navigateTo(ScreenDestination.LiveStream) },
                            colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("Go Live", fontSize = 11.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 2. Super Chat Unlock Card (500 Subscribers)
            val canSuperChat = subscribers >= 500
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = if (canSuperChat) androidx.compose.foundation.BorderStroke(1.dp, YouTubeGreen) else null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (canSuperChat) YouTubeGreen else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stars,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Super Chat & Super Thanks",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (canSuperChat) YouTubeGreen else BhartTubeRed.copy(alpha = 0.8f)
                            ) {
                                Text(
                                    text = if (canSuperChat) "UNLOCKED (अनलॉक)" else "500 SUBS REQUIRED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = if (canSuperChat) "500 सब्सक्राइबर पूरे होने पर सुपरचैट अनलॉक है! दर्शक लाइव व वीडियो पर सुपरचैट भेज सकते हैं।" else "500 सब्सक्राइबर पूरा होने के बाद Superchat अनलॉक होगा। वर्तमान: $subscribers/500",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // AI Safety Guard Link Banner
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = BhartTubeRed.copy(alpha = 0.1f),
                border = androidx.compose.foundation.BorderStroke(1.dp, BhartTubeRed.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo(ScreenDestination.SafetyCenter) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = BhartTubeRed,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🛡️ BhartTube AI Content Safety Guard",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "गंदा वीडियो (पोर्न xxx), खून-खराबा व भयानक एक्सीडेंट वीडियो 100% स्वतः डिलीट होते हैं।",
                            fontSize = 11.sp,
                            color = BhartTubeRed
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Partner Program Ways to Earn
            Text(
                text = "Ways to Earn on BhartTube",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(10.dp))

            WaysToEarnCard(
                icon = Icons.Default.Videocam,
                title = "Watch Page Ads",
                description = "Earn from advertisements and BhartTube Premium views on your long-form videos."
            )

            Spacer(modifier = Modifier.height(8.dp))

            WaysToEarnCard(
                icon = Icons.Default.Speed,
                title = "Shorts Feed Ads",
                description = "Earn shared revenue from commercials between shorts in the BhartTube Shorts Feed."
            )

            Spacer(modifier = Modifier.height(8.dp))

            WaysToEarnCard(
                icon = Icons.Default.CardMembership,
                title = "Channel Memberships",
                description = "Offer monthly badges, custom emojis, and exclusive member-only videos to fans."
            )

            Spacer(modifier = Modifier.height(8.dp))

            WaysToEarnCard(
                icon = Icons.Default.Stars,
                title = "Supers & Super Thanks",
                description = "Let viewers highlight their comments and tip you with Super Thanks and Super Chat."
            )

            Spacer(modifier = Modifier.height(8.dp))

            WaysToEarnCard(
                icon = Icons.Default.ShoppingBag,
                title = "BhartTube Shopping",
                description = "Showcase your branded merchandise and products under your video player."
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Payout / Bank Account Settings (Strictly Locked until Partner Program Application/Approval)
            val canLinkBank = isMonetized || hasApplied
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (canLinkBank) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AccountBalance,
                            contentDescription = null,
                            tint = if (canLinkBank) BhartTubeRed else Color.Gray,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Payout Account (Bank Transfer)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                if (!canLinkBank) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "🔒 LOCKED",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BhartTubeRed
                                    )
                                }
                            }
                            Text(
                                text = if (!canLinkBank) {
                                    "1000 Subs, 1500h और 5M Views पूरा करके अप्लाई करने पर ही बैंक अकाउंट खुलेगा। उस से पहले कोई earning नहीं होगी।"
                                } else if (stats?.bankAccountLinked == true) {
                                    "${stats?.bankName ?: "Bank"} • ${stats?.bankAccountHolder ?: "Creator"} • ${stats?.bankAccountNumber?.ifBlank { "**** **** 4892" } ?: "**** **** 4892"}"
                                } else {
                                    "BhartTube Partner Program अप्रूव्ड! मासिक भुगतान के लिए बैंक अकाउंट जोड़ें।"
                                },
                                fontSize = 11.sp,
                                color = if (!canLinkBank) BhartTubeRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 15.sp
                            )
                        }

                        if (canLinkBank) {
                            TextButton(
                                onClick = { showBankDialog = true },
                                modifier = Modifier.testTag("link_bank_button")
                            ) {
                                Text(
                                    text = if (stats?.bankAccountLinked == true) "Edit" else "Add Bank",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Text(
                                    text = "Locked",
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }

        // Link Bank Dialog
        if (showBankDialog) {
            var bankNameInput by remember { mutableStateOf(stats?.bankName ?: "State Bank of India") }
            var upiInput by remember { mutableStateOf(stats?.upiId ?: "creator@upi") }

            AlertDialog(
                onDismissRequest = { showBankDialog = false },
                title = { Text("Link Bank for BhartTube Payouts") },
                text = {
                    Column {
                        OutlinedTextField(
                            value = bankHolder,
                            onValueChange = { bankHolder = it },
                            label = { Text("Account Holder Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = bankNameInput,
                            onValueChange = { bankNameInput = it },
                            label = { Text("Bank Name (e.g. State Bank of India, HDFC)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = bankAccNumber,
                            onValueChange = { bankAccNumber = it },
                            label = { Text("Bank Account Number") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = bankIfsc,
                            onValueChange = { bankIfsc = it },
                            label = { Text("IFSC Code (e.g. SBIN0001234)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = upiInput,
                            onValueChange = { upiInput = it },
                            label = { Text("UPI ID (Optional for Instant Payout)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.linkBankAccountFull(bankHolder, bankAccNumber, bankIfsc, bankNameInput, upiInput)
                            showBankDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed)
                    ) {
                        Text("Save & Link Bank")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showBankDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun EligibilityProgressCard(
    icon: ImageVector,
    title: String,
    hindiLabel: String,
    currentValue: Long,
    targetValue: Long,
    currentText: String,
    targetText: String,
    isMet: Boolean,
    progress: Float
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isMet) YouTubeGreen.copy(alpha = 0.2f) else BhartTubeRed.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isMet) Icons.Default.CheckCircle else icon,
                        contentDescription = null,
                        tint = if (isMet) YouTubeGreen else BhartTubeRed,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = hindiLabel,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = "$currentText / $targetText",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = if (isMet) YouTubeGreen else MaterialTheme.colorScheme.onBackground
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = if (isMet) YouTubeGreen else BhartTubeRed,
                trackColor = MaterialTheme.colorScheme.background
            )
        }
    }
}

@Composable
fun WaysToEarnCard(
    icon: ImageVector,
    title: String,
    description: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = BhartTubeRed,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
