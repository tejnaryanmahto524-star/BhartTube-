package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.BhartTubeRed
import com.example.ui.theme.YouTubeBlue
import com.example.ui.theme.YouTubeGreen
import com.example.ui.viewmodel.BhartTubeViewModel
import kotlinx.coroutines.delay

data class LiveChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String,
    val text: String,
    val isSuperChat: Boolean = false,
    val superChatAmount: Int = 0,
    val badgeColor: Color = Color.Gray
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveStreamScreen(
    viewModel: BhartTubeViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.creatorStats.collectAsStateWithLifecycle()
    val subscribers = stats?.subscribers ?: 860
    val canLiveStream = subscribers >= 50
    val canSuperChat = subscribers >= 500

    var isLiveActive by remember { mutableStateOf(false) }
    var streamTitle by remember { mutableStateOf("🔴 Sunday Special Live Q&A • BhartTube Community!") }
    var streamCategory by remember { mutableStateOf("Live Chat") }
    var isMicMuted by remember { mutableStateOf(false) }
    var viewerCount by remember { mutableIntStateOf(1420) }
    var streamSeconds by remember { mutableIntStateOf(0) }
    var inputMessage by remember { mutableStateOf("") }
    var showSuperChatDialog by remember { mutableStateOf(false) }

    val liveChatMessages = remember {
        mutableStateListOf(
            LiveChatMessage(sender = "Rahul Verma", text = "Jai Hind dosto! Looking forward to this stream 🇮🇳", badgeColor = YouTubeBlue),
            LiveChatMessage(sender = "Priya Sharma", text = "Namaste! Picture and audio quality is crystal clear! ✨", badgeColor = BhartTubeRed),
            LiveChatMessage(sender = "Amit Kumar", text = "Super proud of Indian Creator community on BhartTube!", badgeColor = YouTubeGreen)
        )
    }

    // Timer & Simulated Live Chat inflow while streaming
    LaunchedEffect(isLiveActive) {
        if (isLiveActive) {
            val sampleComments = listOf(
                "Great stream brother! Keep going! 🔥",
                "Hello from Mumbai! 🙏",
                "Love the BhartTube platform, super fast!",
                "Can you answer my question about coding?",
                "Sending love from Delhi! ❤️",
                "Best creator in India!",
                "Amazing live video quality!"
            )
            val senders = listOf("Vikas", "Sunita", "Deepak", "Aakash", "Neha", "Manoj", "Karan")

            while (isLiveActive) {
                delay(1000)
                streamSeconds++
                if (streamSeconds % 4 == 0) {
                    viewerCount += (-5..12).random()
                    val randomSender = senders.random()
                    val randomComment = sampleComments.random()
                    liveChatMessages.add(
                        LiveChatMessage(
                            sender = randomSender,
                            text = randomComment,
                            badgeColor = Color(
                                red = (100..220).random(),
                                green = (80..200).random(),
                                blue = (150..255).random()
                            )
                        )
                    )
                    if (liveChatMessages.size > 25) {
                        liveChatMessages.removeAt(0)
                    }
                }
            }
        }
    }

    // Pulse animation for LIVE badge
    val transition = rememberInfiniteTransition(label = "pulse")
    val alphaAnim by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "live_pulse"
    )

    // Locked Gate Check: If subscribers < 50, show requirement
    if (!canLiveStream) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(BhartTubeRed.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = BhartTubeRed,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Live Streaming Locked 🔒",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "50 Subscribers Needed to Go Live",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = BhartTubeRed
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "BhartTube requires a minimum of 50 subscribers to unlock Live Streaming. Keep posting great videos and shorts to reach this milestone!",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Progress bar
                    val progress = (subscribers.toFloat() / 50f).coerceIn(0f, 1f)
                    androidx.compose.material3.LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = BhartTubeRed,
                        trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Your Subscribers: $subscribers / 50 (${(50 - subscribers).coerceAtLeast(0)} more needed)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onBack,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Back to Home", color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
        return
    }

    // UNLOCKED: Live Stream Studio Screen
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Camera / Studio Preview Simulated Background
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = if (isLiveActive) listOf(
                            Color(0xFF0F2027),
                            Color(0xFF203A43),
                            Color(0xFF2C5364)
                        ) else listOf(
                            Color(0xFF141E30),
                            Color(0xFF243B55)
                        )
                    )
                )
        )

        // Overlay: Top Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, start = 12.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    if (isLiveActive) isLiveActive = false
                    onBack()
                },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Exit", tint = Color.White)
            }

            Spacer(modifier = Modifier.width(10.dp))

            if (isLiveActive) {
                // Animated LIVE Badge
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = BhartTubeRed,
                    modifier = Modifier.alpha(alphaAnim)
                ) {
                    Text(
                        text = "LIVE",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Viewer Counter
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.Black.copy(alpha = 0.6f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = String.format("%,d", viewerCount),
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Live Duration
                val mins = streamSeconds / 60
                val secs = streamSeconds % 60
                Text(
                    text = String.format("%02d:%02d", mins, secs),
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Camera switch / mic controls
            IconButton(
                onClick = { isMicMuted = !isMicMuted },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
            ) {
                Icon(
                    imageVector = if (isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Mute",
                    tint = if (isMicMuted) BhartTubeRed else Color.White
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = { /* Switch front/back camera */ },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
            ) {
                Icon(Icons.Default.Cameraswitch, contentDescription = "Camera Flip", tint = Color.White)
            }
        }

        // Live Chat Feed (Bottom)
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            if (isLiveActive) {
                // Stream Title Card
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Black.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = streamTitle,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = streamCategory,
                            color = YouTubeGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Real-time Chat message list
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(liveChatMessages, key = { it.id }) { msg ->
                        if (msg.isSuperChat) {
                            // Super Chat Banner
                            Card(
                                colors = CardDefaults.cardColors(containerColor = YouTubeGreen),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CurrencyRupee,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "₹${msg.superChatAmount} Super Chat from ${msg.sender}: ${msg.text}",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black.copy(alpha = 0.45f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = msg.sender,
                                    color = msg.badgeColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = msg.text,
                                    color = Color.White,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom Input Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputMessage,
                        onValueChange = { inputMessage = it },
                        placeholder = { Text("Chat as ${stats?.channelName ?: "Creator"}...", color = Color.LightGray, fontSize = 12.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BhartTubeRed,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Super Chat Button (Unlocked at 500 Subs!)
                    IconButton(
                        onClick = {
                            if (canSuperChat) {
                                showSuperChatDialog = true
                            } else {
                                viewModel.setFeedback("🔒 Super Chat unlocks at 500 subscribers! Current: $subscribers/500")
                            }
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (canSuperChat) YouTubeGreen else Color.DarkGray)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CurrencyRupee,
                            contentDescription = "Super Chat",
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (inputMessage.isNotBlank()) {
                                liveChatMessages.add(
                                    LiveChatMessage(
                                        sender = stats?.channelName ?: "Host",
                                        text = inputMessage.trim(),
                                        badgeColor = BhartTubeRed
                                    )
                                )
                                inputMessage = ""
                            }
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(BhartTubeRed)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // End Stream Button
                Button(
                    onClick = {
                        isLiveActive = false
                        viewModel.setFeedback("Live Stream ended! Total Viewers: ${String.format("%,d", viewerCount)}")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("End Live Stream", fontWeight = FontWeight.Bold)
                }
            } else {
                // Stream Setup Screen before going live
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.75f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = YouTubeGreen
                            ) {
                                Text(
                                    text = "50+ SUBS UNLOCKED",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "BhartTube Live Studio",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = streamTitle,
                            onValueChange = { streamTitle = it },
                            label = { Text("Stream Title", color = Color.LightGray) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BhartTubeRed,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Category: $streamCategory • Camera: Front HD 1080p",
                            color = Color.LightGray,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                isLiveActive = true
                                streamSeconds = 0
                                viewModel.setFeedback("🔴 You are now LIVE on BhartTube!")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("start_live_stream_btn")
                        ) {
                            Icon(Icons.Default.Videocam, null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("GO LIVE (लाइव शुरू करें)", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Super Chat Dialog for Live Stream
    if (showSuperChatDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showSuperChatDialog = false },
            title = { Text("Send Super Chat to Creator") },
            text = {
                Column {
                    Text("Select Super Chat amount:", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(20, 50, 100, 500, 1000).forEach { amt ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = YouTubeGreen.copy(alpha = 0.2f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, YouTubeGreen),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        liveChatMessages.add(
                                            LiveChatMessage(
                                                sender = "Supporter",
                                                text = "Keep up the great work! ✨",
                                                isSuperChat = true,
                                                superChatAmount = amt
                                            )
                                        )
                                        viewModel.sendSuperChat(amt.toDouble(), "Super Chat during Live Stream", "Supporter")
                                        showSuperChatDialog = false
                                    }
                                    .padding(vertical = 8.dp)
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "₹$amt",
                                        color = YouTubeGreen,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { showSuperChatDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
