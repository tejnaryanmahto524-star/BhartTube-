package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BhartTubeRed = Color(0xFFFF0000)
val BhartTubeDarkRed = Color(0xFFCC0000)
val YouTubeBlue = Color(0xFF3EA6FF)
val YouTubeGreen = Color(0xFF2BA640)

// Dark Theme Colors (YouTube AMOLED / Dark)
val DarkBackground = Color(0xFF0F0F0F)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSurfaceVariant = Color(0xFF282828)
val DarkBorder = Color(0xFF383838)
val DarkTextPrimary = Color(0xFFFFFFFF)
val DarkTextSecondary = Color(0xFFAAAAAA)

// Light Theme Colors
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF2F2F2)
val LightSurfaceVariant = Color(0xFFE5E5E5)
val LightBorder = Color(0xFFCCCCCC)
val LightTextPrimary = Color(0xFF0F0F0F)
val LightTextSecondary = Color(0xFF606060)
