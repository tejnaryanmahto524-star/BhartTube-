package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Comment
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.VideoEntity
import com.example.ui.components.formatViewsCount
import com.example.ui.components.parseGradients
import com.example.ui.theme.BhartTubeRed
import com.example.ui.viewmodel.BhartTubeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShortsScreen(
    viewModel: BhartTubeViewModel,
    onShare: (VideoEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val shorts by viewModel.shorts.collectAsStateWithLifecycle()
    val isAudioMuted by viewModel.isAudioMuted.collectAsStateWithLifecycle()
    var showCommentSheet by remember { mutableStateOf(false) }
    var selectedShortForComments by remember { mutableStateOf<VideoEntity?>(null) }
    var newCommentText by remember { mutableStateOf("") }
    val commentsSheetState = rememberModalBottomSheetState()

    if (shorts.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Text("No Shorts available yet", color = Color.White)
        }
        return
    }

    val pagerState = rememberPagerState(pageCount = { shorts.size })

    // When page changes, register watch count and play short's audio soundtrack
    LaunchedEffect(pagerState.currentPage, shorts) {
        val currentShort = shorts.getOrNull(pagerState.currentPage)
        if (currentShort != null) {
            viewModel.recordShortWatched(currentShort)
            viewModel.playShortAudio(currentShort)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            viewModel.stopShortAudio()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        VerticalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val short = shorts[page]
            ShortItemView(
                short = short,
                onLikeClick = { viewModel.toggleLikeActiveVideo() },
                onDislikeClick = { viewModel.dislikeActiveVideo() },
                onCommentClick = {
                    selectedShortForComments = short
                    showCommentSheet = true
                },
                onShareClick = { onShare(short) },
                onSaveClick = { viewModel.toggleSaveWatchLater(short) },
                onSubscribeClick = { viewModel.toggleSubscription(short.channelName, short.isSubscribed) }
            )
        }

        // Top Mute / Sound button overlay
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .align(Alignment.TopEnd),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable { viewModel.toggleAudioMute() }
                    .padding(8.dp)
                    .testTag("shorts_mute_btn")
            ) {
                Icon(
                    imageVector = if (isAudioMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                    contentDescription = if (isAudioMuted) "Unmute Shorts Sound" else "Mute Shorts Sound",
                    tint = if (isAudioMuted) Color(0xFFFF5252) else Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Comments Bottom Sheet
        if (showCommentSheet && selectedShortForComments != null) {
            ModalBottomSheet(
                onDismissRequest = { showCommentSheet = false },
                sheetState = commentsSheetState,
                containerColor = Color(0xFF212121),
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Comments",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Awesome Short! Loving BhartTube 🔥",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Rahul Gupta • 2 hours ago",
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newCommentText,
                            onValueChange = { newCommentText = it },
                            placeholder = { Text("Add a comment...", color = Color.Gray) },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (newCommentText.isNotBlank()) {
                                    viewModel.addCommentToActiveVideo(newCommentText)
                                    newCommentText = ""
                                    showCommentSheet = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BhartTubeRed)
                        ) {
                            Text("Post")
                        }
                    }
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
fun ShortItemView(
    short: VideoEntity,
    onLikeClick: () -> Unit,
    onDislikeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onShareClick: () -> Unit,
    onSaveClick: () -> Unit,
    onSubscribeClick: () -> Unit
) {
    var isLiked by remember { mutableStateOf(short.isLiked) }
    var likesCount by remember { mutableStateOf(short.likes) }
    var isSubscribed by remember { mutableStateOf(false) }

    // Sound Disc Rotation Animation
    val infiniteTransition = rememberInfiniteTransition(label = "disc")
    val discRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // Video Preview/Media
        if (short.thumbnailUrl.isNotBlank()) {
            AsyncImage(
                model = short.thumbnailUrl,
                contentDescription = short.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(parseGradients(short.videoGradientColors)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.size(64.dp)
                )
            }
        }

        // Scrim Gradient
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.3f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.85f)
                        )
                    )
                )
        )

        // Bottom Left Metadata (Creator info, title, sound)
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.8f)
                .padding(start = 16.dp, bottom = 24.dp)
        ) {
            // Channel & Subscribe
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (short.channelAvatarUrl.isNotBlank()) {
                    AsyncImage(
                        model = short.channelAvatarUrl,
                        contentDescription = short.channelName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BhartTubeRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = short.channelName.take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = short.channelName,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.width(10.dp))

                // Subscribe Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSubscribed) Color.Gray.copy(alpha = 0.6f) else Color.White)
                        .clickable {
                            isSubscribed = !isSubscribed
                            onSubscribeClick()
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("shorts_subscribe_btn")
                ) {
                    Text(
                        text = if (isSubscribed) "Subscribed" else "Subscribe",
                        color = if (isSubscribed) Color.White else Color.Black,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Short Title
            Text(
                text = short.title,
                color = Color.White,
                fontSize = 14.sp,
                lineHeight = 18.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Sound Track
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Original Audio • ${short.channelName}",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Automatic Copyright Tag for Short
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = BhartTubeRed,
                    modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "© Content ID Protected (स्वतः कॉपीराइट)",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Right Action Rail (Likes, Comments, Share, Remix, Sound Disc)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 12.dp, bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Like
            ShortsActionButton(
                icon = if (isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                label = formatViewsCount(likesCount),
                tint = if (isLiked) BhartTubeRed else Color.White,
                onClick = {
                    if (isLiked) {
                        isLiked = false
                        likesCount = (likesCount - 1).coerceAtLeast(0)
                    } else {
                        isLiked = true
                        likesCount += 1
                    }
                    onLikeClick()
                },
                testTag = "shorts_like_btn"
            )

            // Dislike
            ShortsActionButton(
                icon = if (short.isDisliked) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
                label = "Dislike",
                tint = Color.White,
                onClick = onDislikeClick,
                testTag = "shorts_dislike_btn"
            )

            // Comments
            ShortsActionButton(
                icon = Icons.AutoMirrored.Filled.Comment,
                label = "1.4K",
                tint = Color.White,
                onClick = onCommentClick,
                testTag = "shorts_comment_btn"
            )

            // Share Button with name below
            ShortsActionButton(
                icon = Icons.Default.Share,
                label = "Share / शेयर",
                tint = Color.White,
                onClick = onShareClick,
                testTag = "shorts_share_btn"
            )

            // Save / Bookmark
            ShortsActionButton(
                icon = if (short.isSavedWatchLater) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                label = "Save",
                tint = if (short.isSavedWatchLater) BhartTubeRed else Color.White,
                onClick = onSaveClick,
                testTag = "shorts_save_btn"
            )

            // Rotating Sound Disc (YouTube Shorts signature)
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color.DarkGray)
                    .rotate(discRotation),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                )
            }
        }
    }
}

@Composable
private fun ShortsActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
