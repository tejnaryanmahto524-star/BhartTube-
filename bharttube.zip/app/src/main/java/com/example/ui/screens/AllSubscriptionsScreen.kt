package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.SubscriptionEntity
import com.example.ui.theme.BhartTubeRed
import com.example.ui.theme.YouTubeBlue
import com.example.ui.viewmodel.BhartTubeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AllSubscriptionsScreen(
    viewModel: BhartTubeViewModel,
    onBack: () -> Unit,
    onChannelClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val subscriptions by viewModel.subscriptions.collectAsStateWithLifecycle()
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var sortAscending by remember { mutableStateOf(false) }

    val filteredList = remember(subscriptions, searchQuery, sortAscending) {
        val list = if (searchQuery.isBlank()) {
            subscriptions
        } else {
            subscriptions.filter { it.channelName.contains(searchQuery, ignoreCase = true) }
        }
        if (sortAscending) list.sortedBy { it.channelName } else list
    }

    var selectedChannelForUnsub by remember { mutableStateOf<SubscriptionEntity?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                if (isSearchActive) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search subscriptions...", fontSize = 14.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "All Subscriptions",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "${subscriptions.size}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            },
            actions = {
                IconButton(onClick = { isSearchActive = !isSearchActive }) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                IconButton(onClick = { sortAscending = !sortAscending }) {
                    Icon(
                        imageVector = Icons.Default.Sort,
                        contentDescription = "Sort A-Z",
                        tint = if (sortAscending) BhartTubeRed else MaterialTheme.colorScheme.onBackground
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
                titleContentColor = MaterialTheme.colorScheme.onBackground
            )
        )

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Subscriptions,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "No channels match \"$searchQuery\"" else "No Subscribed Channels",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Subscribe to channels to stay up to date with their latest videos and shorts.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                item {
                    Text(
                        text = if (sortAscending) "Alphabetical Order (A-Z)" else "Channels you are subscribed to:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }

                items(filteredList, key = { it.channelName }) { sub ->
                    SubscribedChannelRow(
                        subscription = sub,
                        onClick = { onChannelClick(sub.channelName) },
                        onBellClick = {
                            viewModel.updateBellNotification(sub.channelName, !sub.hasBellNotification)
                        },
                        onUnsubscribeClick = {
                            selectedChannelForUnsub = sub
                        }
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                        thickness = 0.5.dp
                    )
                }
            }
        }

        // Unsubscribe Dialog
        selectedChannelForUnsub?.let { channel ->
            AlertDialog(
                onDismissRequest = { selectedChannelForUnsub = null },
                title = { Text("Unsubscribe from ${channel.channelName}?") },
                text = { Text("You will no longer see updates from this channel in your subscriptions feed.") },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.toggleSubscription(
                                channelName = channel.channelName,
                                currentSubscribed = true
                            )
                            selectedChannelForUnsub = null
                        }
                    ) {
                        Text("Unsubscribe", color = BhartTubeRed)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedChannelForUnsub = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun SubscribedChannelRow(
    subscription: SubscriptionEntity,
    onClick: () -> Unit,
    onBellClick: () -> Unit,
    onUnsubscribeClick: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("subscribed_channel_row_${subscription.channelName}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar
        Box {
            if (subscription.channelAvatarUrl.isNotBlank()) {
                AsyncImage(
                    model = subscription.channelAvatarUrl,
                    contentDescription = subscription.channelName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(BhartTubeRed),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = subscription.channelName.take(1).uppercase(),
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Small unread active dot
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(YouTubeBlue)
                    .align(Alignment.BottomEnd)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        // Name & Subscribers
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = subscription.channelName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = "Verified",
                    tint = YouTubeBlue,
                    modifier = Modifier.size(14.dp)
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "${subscription.subscriberCount} • ${subscription.handle}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Bell / Subscribed state menu
        Box {
            IconButton(
                onClick = { showMenu = true },
                modifier = Modifier.testTag("channel_bell_btn_${subscription.channelName}")
            ) {
                Icon(
                    imageVector = if (subscription.hasBellNotification) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                    contentDescription = "Notification options",
                    tint = if (subscription.hasBellNotification) YouTubeBlue else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Notifications ON") },
                    leadingIcon = { Icon(Icons.Default.NotificationsActive, null, tint = YouTubeBlue) },
                    onClick = {
                        showMenu = false
                        onBellClick()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Notifications OFF") },
                    leadingIcon = { Icon(Icons.Default.NotificationsOff, null) },
                    onClick = {
                        showMenu = false
                        onBellClick()
                    }
                )
                HorizontalDivider()
                DropdownMenuItem(
                    text = { Text("Unsubscribe", color = BhartTubeRed) },
                    onClick = {
                        showMenu = false
                        onUnsubscribeClick()
                    }
                )
            }
        }

        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
    }
}
