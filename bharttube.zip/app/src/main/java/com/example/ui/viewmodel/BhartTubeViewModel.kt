package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.audio.BhartTubeAudioEngine
import com.example.data.model.CommentEntity
import com.example.data.model.CreatorStatsEntity
import com.example.data.model.SubscriptionEntity
import com.example.data.model.VideoEntity
import com.example.data.repository.BhartTubeRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.example.data.model.AppOwnerStatsEntity
import com.example.util.AppLanguage

sealed class ScreenDestination {
    data object Home : ScreenDestination()
    data object Shorts : ScreenDestination()
    data object Upload : ScreenDestination()
    data object Subscriptions : ScreenDestination()
    data object AllSubscriptions : ScreenDestination()
    data class ChannelPage(val channelName: String) : ScreenDestination()
    data object You : ScreenDestination()
    data object Search : ScreenDestination()
    data object CreatorStudio : ScreenDestination()
    data object Downloads : ScreenDestination()
    data object LikedVideos : ScreenDestination()
    data object WatchLater : ScreenDestination()
    data object WatchHistory : ScreenDestination()
    data object LiveStream : ScreenDestination()
    data object SafetyCenter : ScreenDestination()
    data object Settings : ScreenDestination()
}

data class AdCreative(
    val sponsor: String,
    val tagline: String,
    val ctaText: String,
    val ctaUrl: String,
    val category: String,
    val bannerGradient: String = "0xFFFF512F,0xFFDD2476"
)

class BhartTubeViewModel(private val repository: BhartTubeRepository) : ViewModel() {

    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.Home)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    val videos: StateFlow<List<VideoEntity>> = _selectedCategory.flatMapLatest { category ->
        repository.getVideosByCategory(category)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shorts: StateFlow<List<VideoEntity>> = _selectedCategory.flatMapLatest { category ->
        repository.getShortsByCategory(category)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val creatorStats: StateFlow<CreatorStatsEntity?> = repository.creatorStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val subscriptions: StateFlow<List<SubscriptionEntity>> = repository.subscriptions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val likedVideos: StateFlow<List<VideoEntity>> = repository.likedVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchLaterVideos: StateFlow<List<VideoEntity>> = repository.watchLaterVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadedVideos: StateFlow<List<VideoEntity>> = repository.downloadedVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userUploadedVideos: StateFlow<List<VideoEntity>> = repository.userUploadedVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchHistory: StateFlow<List<VideoEntity>> = repository.watchHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val appOwnerStats: StateFlow<AppOwnerStatsEntity?> = repository.appOwnerStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isUserPremium: StateFlow<Boolean> = appOwnerStats.map { stats ->
        stats != null && stats.isUserPremiumActive && (stats.premiumExpiresAt == 0L || stats.premiumExpiresAt > System.currentTimeMillis())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val currentLanguage: StateFlow<AppLanguage> = appOwnerStats.map { stats ->
        AppLanguage.fromCode(stats?.selectedLanguage ?: "en")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppLanguage.ENGLISH)

    private val sampleAdCreatives = listOf(
        AdCreative("Tata Neu", "Electronics, Groceries & Flights. Get 10% NeuCoins on every order!", "Shop Now", "https://tataneu.com", "Shopping", "0xFF4A00E0,0xFF8E2DE2"),
        AdCreative("Zomato Gold", "Free Delivery at 25,000+ top restaurants + Extra 40% OFF!", "Order Food", "https://zomato.com", "Food", "0xFFE23744,0xFFFF6978"),
        AdCreative("Flipkart Big Billion Days", "Lowest Price Guaranteed on Smartphones & Laptops. Hurry!", "Explore Deals", "https://flipkart.com", "Deals", "0xFF2874F0,0xFF00C6FF"),
        AdCreative("Airtel 5G Plus", "Experience Ultrafast Unlimited 5G Data across India seamlessly", "Upgrade 5G", "https://airtel.in", "Telecom", "0xFFE40000,0xFFFF5252"),
        AdCreative("BharatPe Merchant", "Zero Percent fee QR Payments & Earn up to 12% Interest p.a.", "Get QR Code", "https://bharatpe.com", "Finance", "0xFF00796B,0xFF004D40")
    )

    private val _isAdPlaying = MutableStateFlow(false)
    val isAdPlaying: StateFlow<Boolean> = _isAdPlaying.asStateFlow()

    private val _adCountdownSeconds = MutableStateFlow(5)
    val adCountdownSeconds: StateFlow<Int> = _adCountdownSeconds.asStateFlow()

    private val _canSkipAd = MutableStateFlow(false)
    val canSkipAd: StateFlow<Boolean> = _canSkipAd.asStateFlow()

    private val _activeAdCreative = MutableStateFlow(sampleAdCreatives[0])
    val activeAdCreative: StateFlow<AdCreative> = _activeAdCreative.asStateFlow()

    private val _showPremiumDialog = MutableStateFlow(false)
    val showPremiumDialog: StateFlow<Boolean> = _showPremiumDialog.asStateFlow()

    private var adCountdownJob: Job? = null

    // Channel Page State
    private val _selectedChannelName = MutableStateFlow<String?>(null)
    val selectedChannelName: StateFlow<String?> = _selectedChannelName.asStateFlow()

    val selectedChannelSubscription: StateFlow<SubscriptionEntity?> = _selectedChannelName.flatMapLatest { name ->
        if (name != null) repository.getSubscription(name) else kotlinx.coroutines.flow.flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedChannelVideos: StateFlow<List<VideoEntity>> = _selectedChannelName.flatMapLatest { name ->
        if (name != null) repository.getVideosByChannel(name) else kotlinx.coroutines.flow.flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedChannelLongVideos: StateFlow<List<VideoEntity>> = _selectedChannelName.flatMapLatest { name ->
        if (name != null) repository.getLongVideosByChannel(name) else kotlinx.coroutines.flow.flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedChannelShorts: StateFlow<List<VideoEntity>> = _selectedChannelName.flatMapLatest { name ->
        if (name != null) repository.getShortsByChannel(name) else kotlinx.coroutines.flow.flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Video Player state
    private val _activeVideo = MutableStateFlow<VideoEntity?>(null)
    val activeVideo: StateFlow<VideoEntity?> = _activeVideo.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPlaybackSeconds = MutableStateFlow(0)
    val currentPlaybackSeconds: StateFlow<Int> = _currentPlaybackSeconds.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _playbackQuality = MutableStateFlow("1080p")
    val playbackQuality: StateFlow<String> = _playbackQuality.asStateFlow()

    private val _commentsForActiveVideo = MutableStateFlow<List<CommentEntity>>(emptyList())
    val commentsForActiveVideo: StateFlow<List<CommentEntity>> = _commentsForActiveVideo.asStateFlow()

    private val _commentsSortByTop = MutableStateFlow(true)
    val commentsSortByTop: StateFlow<Boolean> = _commentsSortByTop.asStateFlow()

    private var playbackJob: Job? = null
    private var commentsJob: Job? = null

    fun toggleCommentSort() {
        _commentsSortByTop.value = !_commentsSortByTop.value
        refreshActiveVideoComments()
    }

    fun refreshActiveVideoComments() {
        val video = _activeVideo.value ?: return
        commentsJob?.cancel()
        commentsJob = viewModelScope.launch {
            repository.getCommentsForVideo(video.id, sortByTop = _commentsSortByTop.value).collect {
                _commentsForActiveVideo.value = it
            }
        }
    }

    // Search state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResults: StateFlow<List<VideoEntity>> = _searchQuery.flatMapLatest { query ->
        if (query.isBlank()) {
            repository.allVideos
        } else {
            repository.searchVideos(query)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Upload state
    private val _uploadProgress = MutableStateFlow(0f)
    val uploadProgress: StateFlow<Float> = _uploadProgress.asStateFlow()

    private val _isUploading = MutableStateFlow(false)
    val isUploading: StateFlow<Boolean> = _isUploading.asStateFlow()

    private val _uploadMessage = MutableStateFlow<String?>(null)
    val uploadMessage: StateFlow<String?> = _uploadMessage.asStateFlow()

    // Monetization notification / snackbar
    private val _userFeedback = MutableStateFlow<String?>(null)
    val userFeedback: StateFlow<String?> = _userFeedback.asStateFlow()

    // AI Safety Shield (गंदा वीडियो / पोर्न xxx / खून-खराबा / एक्सीडेंट ऑटोमैटिक डिलीट)
    private val _safetyViolationAlert = MutableStateFlow<com.example.safety.SafetyScanResult?>(null)
    val safetyViolationAlert: StateFlow<com.example.safety.SafetyScanResult?> = _safetyViolationAlert.asStateFlow()

    private val _deletedViolationLogs = MutableStateFlow<List<com.example.safety.DeletedVideoLog>>(emptyList())
    val deletedViolationLogs: StateFlow<List<com.example.safety.DeletedVideoLog>> = _deletedViolationLogs.asStateFlow()

    fun dismissSafetyViolationAlert() {
        _safetyViolationAlert.value = null
    }

    fun setFeedback(msg: String) {
        _userFeedback.value = msg
    }

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    fun navigateTo(destination: ScreenDestination) {
        _currentScreen.value = destination
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    val isAudioMuted: StateFlow<Boolean> = BhartTubeAudioEngine.isMuted

    fun toggleAudioMute() {
        BhartTubeAudioEngine.toggleMute()
    }

    fun playVideo(video: VideoEntity) {
        _activeVideo.value = video
        _isPlaying.value = true
        _currentPlaybackSeconds.value = 0
        refreshActiveVideoComments()

        val isPremium = isUserPremium.value
        if (isPremium) {
            // Premium member: No ads will run on any video!
            _isAdPlaying.value = false
            BhartTubeAudioEngine.startVideoAudio(category = video.category, videoTitle = video.title, isShort = false)
            startPlaybackProgress(video.durationSeconds)
        } else {
            // Free user: Play pre-roll ad to earn revenue for app owner!
            val randomCreative = sampleAdCreatives.random()
            _activeAdCreative.value = randomCreative
            _isAdPlaying.value = true
            _adCountdownSeconds.value = 5
            _canSkipAd.value = false
            BhartTubeAudioEngine.stopAudio()
            startAdCountdown(video)
        }

        // Increment views & record watch
        viewModelScope.launch {
            repository.recordVideoWatch(video.id, 15)
        }
    }

    private fun startAdCountdown(video: VideoEntity) {
        adCountdownJob?.cancel()
        adCountdownJob = viewModelScope.launch {
            for (sec in 5 downTo 1) {
                _adCountdownSeconds.value = sec
                delay(1000)
            }
            _adCountdownSeconds.value = 0
            _canSkipAd.value = true
            delay(1500)
            if (_isAdPlaying.value) {
                completeAdAndStartPlayback(video)
            }
        }
    }

    fun skipAd() {
        val video = _activeVideo.value ?: return
        adCountdownJob?.cancel()
        completeAdAndStartPlayback(video)
    }

    private fun completeAdAndStartPlayback(video: VideoEntity) {
        _isAdPlaying.value = false
        viewModelScope.launch {
            // Revenue earned for app owner on ad impression!
            repository.recordAdImpression(1.25)
        }
        _userFeedback.value = "Ad completed • App Owner earned +₹1.25"
        BhartTubeAudioEngine.startVideoAudio(category = video.category, videoTitle = video.title, isShort = false)
        startPlaybackProgress(video.durationSeconds)
    }

    fun openPremiumDialog() {
        _showPremiumDialog.value = true
    }

    fun closePremiumDialog() {
        _showPremiumDialog.value = false
    }

    fun subscribeToMonthlyPremium(paymentMethod: String = "UPI") {
        viewModelScope.launch {
            repository.activateMonthlySubscription(99.0)
            _showPremiumDialog.value = false
            if (_isAdPlaying.value) {
                adCountdownJob?.cancel()
                _isAdPlaying.value = false
                _activeVideo.value?.let { video ->
                    BhartTubeAudioEngine.startVideoAudio(category = video.category, videoTitle = video.title, isShort = false)
                    startPlaybackProgress(video.durationSeconds)
                }
            }
            _userFeedback.value = "👑 1-Month Premium Active! Ad-free streaming enabled. App Owner earned ₹99"
        }
    }

    fun cancelPremium() {
        viewModelScope.launch {
            repository.cancelPremiumSubscription()
            _userFeedback.value = "Premium subscription cancelled"
        }
    }

    fun setAppLanguage(language: AppLanguage) {
        viewModelScope.launch {
            repository.setAppLanguage(language.code)
            _userFeedback.value = "Language changed: ${language.displayName}"
        }
    }

    fun playShortAudio(shortVideo: VideoEntity) {
        BhartTubeAudioEngine.startVideoAudio(category = shortVideo.category, videoTitle = shortVideo.title, isShort = true)
    }

    fun stopShortAudio() {
        BhartTubeAudioEngine.stopAudio()
    }

    private fun startPlaybackProgress(totalSeconds: Int) {
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_isPlaying.value && !_isAdPlaying.value) {
                    val next = _currentPlaybackSeconds.value + 1
                    if (next >= totalSeconds) {
                        _currentPlaybackSeconds.value = 0
                    } else {
                        _currentPlaybackSeconds.value = next
                    }
                }
            }
        }
    }

    fun togglePlayPause() {
        val nextPlaying = !_isPlaying.value
        _isPlaying.value = nextPlaying
        if (nextPlaying) {
            BhartTubeAudioEngine.resumeAudio()
        } else {
            BhartTubeAudioEngine.pauseAudio()
        }
    }

    fun seekTo(seconds: Int) {
        _currentPlaybackSeconds.value = seconds.coerceAtLeast(0)
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
    }

    fun setPlaybackQuality(quality: String) {
        _playbackQuality.value = quality
    }

    fun closePlayer() {
        adCountdownJob?.cancel()
        _isAdPlaying.value = false
        playbackJob?.cancel()
        BhartTubeAudioEngine.stopAudio()
        _activeVideo.value = null
        _isPlaying.value = false
    }

    fun toggleLikeActiveVideo() {
        val current = _activeVideo.value ?: return
        viewModelScope.launch {
            repository.toggleLike(current.id, current.isLiked)
            _activeVideo.value = current.copy(
                isLiked = !current.isLiked,
                likes = if (current.isLiked) (current.likes - 1).coerceAtLeast(0) else current.likes + 1,
                isDisliked = false
            )
            _userFeedback.value = if (!current.isLiked) "Added to Liked videos" else "Removed from Liked videos"
        }
    }

    fun dislikeActiveVideo() {
        val current = _activeVideo.value ?: return
        viewModelScope.launch {
            repository.dislikeVideo(current.id)
            _activeVideo.value = current.copy(
                isDisliked = true,
                isLiked = false,
                likes = if (current.isLiked) (current.likes - 1).coerceAtLeast(0) else current.likes
            )
            _userFeedback.value = "Disliked"
        }
    }

    fun toggleSaveWatchLater(video: VideoEntity) {
        viewModelScope.launch {
            val newStatus = !video.isSavedWatchLater
            repository.toggleWatchLater(video.id, newStatus)
            if (_activeVideo.value?.id == video.id) {
                _activeVideo.value = _activeVideo.value?.copy(isSavedWatchLater = newStatus)
            }
            _userFeedback.value = if (newStatus) "Saved to Watch Later" else "Removed from Watch Later"
        }
    }

    fun toggleDownload(video: VideoEntity) {
        viewModelScope.launch {
            val newStatus = !video.isDownloaded
            repository.toggleDownload(video.id, newStatus)
            if (_activeVideo.value?.id == video.id) {
                _activeVideo.value = _activeVideo.value?.copy(isDownloaded = newStatus)
            }
            _userFeedback.value = if (newStatus) "Downloaded offline" else "Download removed"
        }
    }

    fun addCommentToActiveVideo(text: String, parentId: Long? = null) {
        val current = _activeVideo.value ?: return
        if (text.isBlank()) return

        // BhartTube Community Safety Shield check on comments
        val scan = com.example.safety.BhartTubeSafetyShield.scanContent(text, "", "Comments")
        if (scan.isViolation) {
            _userFeedback.value = "⚠️ टिप्पणी में आपत्तिजनक शब्द हैं! कृपया सम्मानजनक टिप्पणी लिखें।"
            return
        }

        viewModelScope.launch {
            repository.addComment(
                videoId = current.id,
                author = "You (Viewer)",
                text = text.trim(),
                parentId = parentId
            )
            _userFeedback.value = if (parentId != null) "Reply posted! 💬" else "Comment posted! 💬"
            refreshActiveVideoComments()
        }
    }

    fun toggleLikeComment(comment: CommentEntity) {
        viewModelScope.launch {
            repository.toggleLikeComment(comment.id, comment.isLiked)
            refreshActiveVideoComments()
        }
    }

    fun deleteComment(commentId: Long) {
        viewModelScope.launch {
            repository.deleteComment(commentId)
            _userFeedback.value = "Comment deleted"
            refreshActiveVideoComments()
        }
    }

    fun getRepliesForComment(parentId: Long): Flow<List<CommentEntity>> {
        return repository.getRepliesForComment(parentId)
    }

    fun toggleSubscription(
        channelName: String,
        currentSubscribed: Boolean,
        avatarUrl: String = "",
        subscriberCount: String = "1M subscribers",
        description: String = "",
        handle: String = ""
    ) {
        viewModelScope.launch {
            val newStatus = !currentSubscribed
            repository.toggleSubscription(
                channelName = channelName,
                subscribed = newStatus,
                avatarUrl = avatarUrl,
                subscriberCount = subscriberCount,
                description = description,
                handle = handle
            )
            if (_activeVideo.value?.channelName == channelName) {
                _activeVideo.value = _activeVideo.value?.copy(isSubscribed = newStatus)
            }
            _userFeedback.value = if (newStatus) "Subscribed to $channelName" else "Unsubscribed from $channelName"
        }
    }

    fun updateBellNotification(channelName: String, hasBell: Boolean) {
        viewModelScope.launch {
            repository.updateBellNotification(channelName, hasBell)
            _userFeedback.value = if (hasBell) "Notifications turned ON for $channelName" else "Notifications turned OFF for $channelName"
        }
    }

    fun openChannelPage(channelName: String) {
        _selectedChannelName.value = channelName
        _currentScreen.value = ScreenDestination.ChannelPage(channelName)
    }

    fun openAllSubscriptions() {
        _currentScreen.value = ScreenDestination.AllSubscriptions
    }

    fun recordShortWatched(short: VideoEntity) {
        viewModelScope.launch {
            repository.recordShortsWatch(short.id)
        }
    }

    fun uploadVideo(
        title: String,
        description: String,
        category: String,
        isShort: Boolean,
        durationSeconds: Int,
        thumbnailGradient: String
    ) {
        viewModelScope.launch {
            // STEP 1: BhartTube AI Content Safety Guard Scan
            // Automatically deletes and intercepts: Porn/XXX ("गंदा वीडियो"), Extreme violence/blood ("खून खराब"), Fatal crashes ("एक्सीडेंट")
            val scanResult = com.example.safety.BhartTubeSafetyShield.scanContent(title, description, category)
            if (scanResult.isViolation) {
                val log = com.example.safety.DeletedVideoLog(
                    title = title,
                    category = scanResult.category!!,
                    matchedWord = scanResult.matchedKeyword
                )
                _deletedViolationLogs.value = listOf(log) + _deletedViolationLogs.value
                _safetyViolationAlert.value = scanResult
                _userFeedback.value = "🚨 वीडियो ऑटोमैटिक डिलीट! कारण: ${scanResult.category.hindiTitle}"
                _isUploading.value = false
                _uploadProgress.value = 0f
                return@launch
            }

            // STEP 2: Proceed with standard safe upload
            _isUploading.value = true
            _uploadProgress.value = 0f
            for (i in 1..10) {
                delay(120)
                _uploadProgress.value = i / 10f
            }
            repository.uploadVideo(
                title = title,
                description = description,
                category = category,
                isShort = isShort,
                durationSeconds = durationSeconds,
                thumbnailGradient = thumbnailGradient
            )
            _isUploading.value = false
            _uploadProgress.value = 0f
            _uploadMessage.value = if (isShort) "Short published to BhartTube!" else "Video uploaded successfully to BhartTube!"
            _currentScreen.value = ScreenDestination.Home
        }
    }

    fun testSafetyAutoDelete(sampleTitle: String) {
        viewModelScope.launch {
            val scanResult = com.example.safety.BhartTubeSafetyShield.scanContent(sampleTitle, "User test upload", "General")
            if (scanResult.isViolation) {
                val log = com.example.safety.DeletedVideoLog(
                    title = sampleTitle,
                    category = scanResult.category!!,
                    matchedWord = scanResult.matchedKeyword
                )
                _deletedViolationLogs.value = listOf(log) + _deletedViolationLogs.value
                _safetyViolationAlert.value = scanResult
                _userFeedback.value = "🚨 यह वीडियो तुरंत ऑटोमैटिक डिलीट कर दिया गया! (${scanResult.category.hindiTitle})"
            } else {
                _userFeedback.value = "✅ सामग्री सुरक्षित है (No policy violations detected)"
            }
        }
    }

    fun tryOpenLiveStream() {
        val currentSubs = creatorStats.value?.subscribers ?: 0
        if (currentSubs >= 50) {
            _currentScreen.value = ScreenDestination.LiveStream
        } else {
            _userFeedback.value = "🔒 Live Stream 50 subscriber पूरा होने के बाद unlock होगा! वर्तमान: $currentSubs/50"
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Monetization actions (Requirements: 1000 subs, 1500 watch hours, 5M shorts views)
    fun applyForMonetization() {
        viewModelScope.launch {
            val stats = creatorStats.value
            val subs = stats?.subscribers ?: 0
            val hours = stats?.watchHours ?: 0.0
            val views = stats?.shortsViews ?: 0L

            val isEligible = subs >= 1000 && hours >= 1500.0 && views >= 5000000L
            if (isEligible) {
                repository.applyForMonetization()
                _userFeedback.value = "Application submitted for BhartTube Partner Program! Bank linking is now unlocked."
            } else {
                _userFeedback.value = "पात्रता अपूर्ण: 1,000 सब्सक्राइबर, 1,500 घंटे और 5M शॉर्ट्स व्यूज पूरा होने पर ही अप्लाई कर सकते हैं!"
            }
        }
    }

    fun approveMonetization() {
        viewModelScope.launch {
            repository.approveMonetization()
            _userFeedback.value = "Congratulations! BhartTube Partner Program Approved! 🎉 You can now link your Bank Account and earn!"
        }
    }

    fun linkBankAccount(holder: String, acc: String, ifsc: String) {
        linkBankAccountFull(holder, acc, ifsc, "State Bank of India", "$holder@upi")
    }

    fun linkBankAccountFull(holder: String, acc: String, ifsc: String, bankName: String, upiId: String) {
        viewModelScope.launch {
            val stats = creatorStats.value
            val isEligibleOrApplied = (stats?.hasApplied == true) || (stats?.isMonetized == true)

            if (!isEligibleOrApplied) {
                _userFeedback.value = "मॉनेटाइजेशन अप्लाई/स्वीकृत होने से पहले बैंक अकाउंट लिंक नहीं किया जा सकता है और कोई कमाई नहीं होगी!"
                return@launch
            }

            repository.linkBankAccountFull(holder, acc, ifsc, bankName, upiId)
            _userFeedback.value = "Bank Account ($bankName - $holder) linked successfully for payouts! 🏦"
        }
    }

    // Super Chat (Unlocked at 500 subscribers)
    fun sendSuperChat(amount: Double, message: String, donorName: String) {
        viewModelScope.launch {
            val stats = creatorStats.value
            val currentSubs = stats?.subscribers ?: 0

            if (currentSubs < 500) {
                _userFeedback.value = "🔒 Super Chat 500 subscribers पूरा होने के बाद unlock होगा! वर्तमान: $currentSubs/500"
                return@launch
            }

            val targetVideo = _activeVideo.value
            if (targetVideo != null) {
                repository.addComment(
                    videoId = targetVideo.id,
                    author = "$donorName (₹${amount.toInt()} Super Chat 🌟)",
                    text = message
                )
            }
            repository.addSuperChatEarnings(amount)
            _userFeedback.value = "Super Chat of ₹${amount.toInt()} sent successfully! 🎉"
        }
    }

    fun simulateGrowth(subs: Int, hours: Double, shortsViews: Long) {
        viewModelScope.launch {
            repository.simulateTrafficGrowth(subs, hours, shortsViews)
            _userFeedback.value = "Simulated: +$subs Subscribers, +${hours.toInt()}h Watch Time, +${shortsViews / 1000}K Shorts Views"
        }
    }

    private val _isHistoryPaused = MutableStateFlow(false)
    val isHistoryPaused: StateFlow<Boolean> = _isHistoryPaused.asStateFlow()

    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    private val _historyFilterType = MutableStateFlow("All") // "All", "Videos", "Shorts"
    val historyFilterType: StateFlow<String> = _historyFilterType.asStateFlow()

    fun setHistorySearchQuery(query: String) {
        _historySearchQuery.value = query
    }

    fun setHistoryFilterType(type: String) {
        _historyFilterType.value = type
    }

    fun togglePauseHistory() {
        val newState = !_isHistoryPaused.value
        _isHistoryPaused.value = newState
        repository.isWatchHistoryPaused = newState
        _userFeedback.value = if (newState) "Watch history paused (इतिहास रोका गया)" else "Watch history resumed (इतिहास पुनः चालू)"
    }

    fun removeFromHistory(videoId: String) {
        viewModelScope.launch {
            repository.removeFromWatchHistory(videoId)
            _userFeedback.value = "Removed from watch history"
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearWatchHistory()
            _userFeedback.value = "Watch history cleared"
        }
    }

    fun clearFeedback() {
        _userFeedback.value = null
        _uploadMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        BhartTubeAudioEngine.stopAudio()
    }
}

class BhartTubeViewModelFactory(private val repository: BhartTubeRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BhartTubeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return BhartTubeViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
